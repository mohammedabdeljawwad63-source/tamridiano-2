#!/usr/bin/env bash
# Tamridiano — keep the site up on a dev box or a bare VM.
#
#   ./dev.sh              # foreground supervisor (Ctrl+C to stop)
#   ./dev.sh --daemon     # detached, survives the shell closing
#
# It restores missing Python packages (a container reset wipes them), then runs
# the server under a restart loop so a crash is a blip rather than an outage.
# On a managed platform (Render / Fly / docker compose) use those instead — they
# already supervise the process.

set -uo pipefail
cd "$(dirname "$0")"

PORT="${PORT:-12000}"
# Log under data/ rather than /tmp: a container reset wipes /tmp, which is
# exactly when the log matters most. Override with LOG=... if needed.
LOG="${LOG:-$(pwd)/data/tamridiano.log}"
BACKOFF_MIN=2
BACKOFF_MAX=30

log() { printf '%s %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$*"; }

ensure_deps() {
  if python3 -c "import fastapi, uvicorn, sqlalchemy, aiosqlite" 2>/dev/null; then
    return 0
  fi
  log "dependencies missing — installing from requirements.txt"
  pip install --user -q -r requirements.txt || {
    log "pip install failed; retrying in 10s"
    sleep 10
    pip install --user -q -r requirements.txt || return 1
  }
  log "dependencies installed"
}

# The supervisor loop. `exec` inside means signals reach uvicorn directly, so
# the restart below is only ever triggered by a real exit, not by Ctrl+C.
supervise() {
  local backoff=$BACKOFF_MIN
  while true; do
    ensure_deps || { log "cannot install dependencies"; sleep "$backoff"; continue; }
    log "starting server on port $PORT"
    ./run.sh >>"$LOG" 2>&1
    local code=$?
    if [ "$code" -eq 130 ] || [ "$code" -eq 143 ]; then
      log "stopped on signal (exit $code)"
      return 0
    fi
    log "server exited with code $code — restarting in ${backoff}s"
    sleep "$backoff"
    backoff=$(( backoff * 2 ))
    [ "$backoff" -gt "$BACKOFF_MAX" ] && backoff=$BACKOFF_MAX
  done
}

if [ "${1:-}" = "--daemon" ]; then
  if pgrep -f "uvicorn app.main:app" >/dev/null 2>&1; then
    log "server already running — nothing to do"
    exit 0
  fi
  setsid nohup "$0" >>"$LOG" 2>&1 </dev/null &
  disown 2>/dev/null || true
  log "daemon started (log: $LOG)"
  sleep 3
  if curl -fsS -m 5 "http://127.0.0.1:$PORT/api/health" >/dev/null 2>&1; then
    log "health check passed"
  else
    log "not healthy yet — check $LOG"
  fi
else
  supervise
fi
