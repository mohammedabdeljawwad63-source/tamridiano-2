"""Authentication: Google Sign-In for students, plus the legacy admin passcode.

Google's ID token is a JWT signed by Google. It is verified locally against
Google's published JWKS (cached), which means sign-in keeps working without a
network round-trip per request and needs no client secret.
"""

import hashlib
import hmac
import json
import logging
import secrets
import threading
import time
import urllib.request

import jwt
from fastapi import Cookie, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .config import (
    ADMIN_EMAILS,
    ADMIN_PASSCODE,
    GOOGLE_ALLOWED_DOMAIN,
    GOOGLE_CLIENT_ID,
    GOOGLE_ISSUERS,
    GOOGLE_JWKS_URL,
    SESSION_SECRET,
    SESSION_TTL_HOURS,
    USER_COOKIE,
    USER_SESSION_TTL_HOURS,
)
from .db import get_db

log = logging.getLogger("tamridiano.auth")

ADMIN_COOKIE = "tmr_admin"


class AuthError(RuntimeError):
    pass


# --------------------------------------------------------------------------- #
# JWKS cache
# --------------------------------------------------------------------------- #

_jwks_lock = threading.Lock()
_jwks_cache: dict = {"keys": None, "fetched_at": 0.0}
_JWKS_TTL = 3600.0


def _fetch_jwks(force: bool = False) -> dict:
    now = time.time()
    with _jwks_lock:
        fresh = _jwks_cache["keys"] and (now - _jwks_cache["fetched_at"]) < _JWKS_TTL
        if fresh and not force:
            return _jwks_cache["keys"]
        try:
            with urllib.request.urlopen(GOOGLE_JWKS_URL, timeout=10) as resp:
                keys = json.loads(resp.read())
        except Exception as exc:  # noqa: BLE001 - any network/parse failure is the same to the caller
            if _jwks_cache["keys"]:
                log.warning("JWKS refresh failed, using cached keys: %s", exc)
                return _jwks_cache["keys"]
            raise AuthError("تعذّر الاتصال بخدمة تحقق جوجل، حاول مرة أخرى.") from exc
        _jwks_cache["keys"] = keys
        _jwks_cache["fetched_at"] = now
        return keys


def _signing_key(token: str):
    headers = jwt.get_unverified_header(token)
    kid = headers.get("kid")
    for attempt in (False, True):
        for key in _fetch_jwks(force=attempt).get("keys", []):
            if key.get("kid") == kid:
                return jwt.algorithms.RSAAlgorithm.from_jwk(json.dumps(key))
    raise AuthError("تعذّر التحقق من هوية جوجل (مفتاح غير معروف).")


def verify_google_token(credential: str) -> dict:
    """Validate a Google ID token and return its claims."""
    if not GOOGLE_CLIENT_ID:
        raise AuthError("تسجيل الدخول بجوجل غير مهيّأ على الخادم.")
    if not credential:
        raise AuthError("لم يصل رمز الدخول من جوجل.")

    try:
        claims = jwt.decode(
            credential,
            _signing_key(credential),
            algorithms=["RS256"],
            audience=GOOGLE_CLIENT_ID,
            options={"require": ["exp", "iat", "aud", "iss"]},
        )
    except AuthError:
        raise
    except jwt.ExpiredSignatureError as exc:
        raise AuthError("انتهت صلاحية جلسة جوجل، أعد المحاولة.") from exc
    except jwt.InvalidTokenError as exc:
        raise AuthError(f"رمز جوجل غير صالح: {exc}") from exc

    if claims.get("iss") not in GOOGLE_ISSUERS:
        raise AuthError("جهة إصدار الرمز غير معتمدة.")
    if not claims.get("email_verified", False):
        raise AuthError("بريد جوجل غير مُوثَّق.")
    email = (claims.get("email") or "").lower()
    if not email:
        raise AuthError("لم يُرجع حساب جوجل بريدًا إلكترونيًا.")
    if GOOGLE_ALLOWED_DOMAIN and not email.endswith("@" + GOOGLE_ALLOWED_DOMAIN):
        raise AuthError(f"الدخول متاح فقط لبريد النطاق @{GOOGLE_ALLOWED_DOMAIN}.")
    return claims


# --------------------------------------------------------------------------- #
# Sessions
# --------------------------------------------------------------------------- #

def _sign(payload: str) -> str:
    return hmac.new(SESSION_SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()


def create_admin_token() -> str:
    expires = int(time.time()) + SESSION_TTL_HOURS * 3600
    nonce = secrets.token_urlsafe(12)
    payload = f"{expires}.{nonce}"
    return f"{payload}.{_sign(payload)}"


def verify_admin_token(token: str | None) -> bool:
    if not token:
        return False
    try:
        expires_s, nonce, signature = token.split(".", 2)
        expires = int(expires_s)
    except (ValueError, AttributeError):
        return False
    if expires < int(time.time()):
        return False
    return hmac.compare_digest(_sign(f"{expires_s}.{nonce}"), signature)


def check_passcode(passcode: str) -> bool:
    return hmac.compare_digest(passcode or "", ADMIN_PASSCODE)


def is_admin_email(email: str | None) -> bool:
    return bool(email) and email.lower() in ADMIN_EMAILS


def create_user_token(
    email: str,
    name: str,
    picture: str | None,
    admin: bool,
    student_number: str | None = None,
    student_account_id: int | None = None,
) -> str:
    """Stateless signed user session.

    The claims are base64url-encoded JSON inside the signed payload, so a session
    survives restarts and multiple workers without shared server state.

    An email session and a student-account session share this token. A student
    account carries `student_account_id`, which is what results are keyed on;
    email sessions leave it unset and are matched on the address instead.
    """
    expires = int(time.time()) + USER_SESSION_TTL_HOURS * 3600
    claims = json.dumps(
        {
            "email": email,
            "name": name,
            "picture": picture,
            "admin": bool(admin),
            "student_number": student_number,
            "student_account_id": student_account_id,
        },
        separators=(",", ":"),
        ensure_ascii=False,
    )
    payload = f"{expires}.{_b64(claims)}"
    return f"{payload}.{_sign(payload)}"


def _b64(text: str) -> str:
    import base64

    return base64.urlsafe_b64encode(text.encode()).decode().rstrip("=")


def _unb64(text: str) -> str:
    import base64

    padding = "=" * (-len(text) % 4)
    return base64.urlsafe_b64decode(text + padding).decode()


def verify_user_token(token: str | None) -> dict | None:
    """Return the user claims, or None when the token is absent/invalid/expired."""
    if not token:
        return None
    try:
        expires_s, claims_b64, signature = token.split(".", 2)
        expires = int(expires_s)
    except (ValueError, AttributeError):
        return None
    if expires < int(time.time()):
        return None
    if not hmac.compare_digest(_sign(f"{expires_s}.{claims_b64}"), signature):
        return None
    try:
        claims = json.loads(_unb64(claims_b64))
    except Exception:  # noqa: BLE001 - malformed payload means an invalid session
        return None
    if not isinstance(claims, dict):
        return None
    # A session is valid if it identifies either a verified address (email or
    # Google sign-in) or a self-registered student account.
    if not claims.get("email") and not claims.get("student_account_id"):
        return None
    # Admin rights are re-derived from config on every request so revoking an
    # address takes effect immediately instead of at session expiry.
    claims["admin"] = is_admin_email(claims.get("email")) or bool(claims.get("passcode_admin"))
    return claims


# --------------------------------------------------------------------------- #
# FastAPI dependencies
# --------------------------------------------------------------------------- #

async def require_admin(
    tmr_admin: str | None = Cookie(default=None),
    tmr_user: str | None = Cookie(default=None),
) -> str:
    if verify_admin_token(tmr_admin):
        return "passcode"
    user = verify_user_token(tmr_user)
    if user and user.get("admin"):
        return user["email"]
    raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Admin authentication required")


async def _account_still_exists(db: AsyncSession, user: dict | None) -> dict | None:
    """Drop a student session whose account row is gone.

    Sessions are stateless, so deleting an account does not invalidate tokens
    already handed out. Left alone, such a token would pass every check and then
    fail on the `attempts.student_account_id` foreign key, turning a routine
    account deletion into 500s for that student. Resolve it to a signed-out
    visitor instead.
    """
    if not user or not user.get("student_account_id"):
        return user
    from .models import Student

    exists = await db.scalar(select(Student.id).where(Student.id == user["student_account_id"]))
    return user if exists is not None else None


async def optional_user(
    tmr_user: str | None = Cookie(default=None),
    db: AsyncSession = Depends(get_db),
) -> dict | None:
    return await _account_still_exists(db, verify_user_token(tmr_user))


async def require_user(
    tmr_user: str | None = Cookie(default=None),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Any signed-in student. Used for student-facing endpoints."""
    user = await _account_still_exists(db, verify_user_token(tmr_user))
    if user:
        return user
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="سجّل الدخول أولًا لعرض هذا الملف.",
    )


async def require_identity(
    tmr_admin: str | None = Cookie(default=None),
    tmr_user: str | None = Cookie(default=None),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """A signed-in student *or* an admin using the passcode.

    Curriculum files are readable by students, but an admin signed in with only
    the passcode has no student session and would otherwise be locked out of the
    originals in the library.
    """
    user = await _account_still_exists(db, verify_user_token(tmr_user))
    if user:
        return user
    if verify_admin_token(tmr_admin):
        return {"email": "", "name": "مشرف", "picture": None, "admin": True}
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="سجّل الدخول أولًا لعرض هذا الملف.",
    )


__all__ = [
    "ADMIN_COOKIE",
    "USER_COOKIE",
    "AuthError",
    "check_passcode",
    "create_admin_token",
    "create_user_token",
    "is_admin_email",
    "optional_user",
    "require_admin",
    "require_identity",
    "require_user",
    "verify_admin_token",
    "verify_google_token",
    "verify_user_token",
]
