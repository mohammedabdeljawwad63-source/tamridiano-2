"""Delivery of sign-in codes by email.

Resend and Brevo expose a plain HTTP API, so they need no SMTP library and no
extra dependency — `httpx` is already used for the LLM calls. Gmail needs SMTP,
which the standard library provides. The `console` provider writes the code to
the server log, which is what local development uses; it must not be selected in
production.
"""

import asyncio
import logging
import re
import smtplib
from email.message import EmailMessage

import httpx

from .config import (
    EMAIL_API_KEY,
    EMAIL_FROM,
    EMAIL_FROM_NAME,
    EMAIL_PROVIDER,
    EMAIL_TIMEOUT,
    SMTP_HOST,
    SMTP_PASSWORD,
    SMTP_PORT,
    SMTP_USER,
)

log = logging.getLogger("tamridiano.mailer")

RESEND_URL = "https://api.resend.com/emails"
BREVO_URL = "https://api.brevo.com/v3/smtp/email"

_SUPPORTED = {"resend", "brevo", "gmail", "console"}

_ADDRESS_RE = re.compile(r"<([^>]+)>")


class MailError(RuntimeError):
    """Raised when a code could not be handed to the provider."""


def email_ready() -> bool:
    """Whether sign-in codes can actually be delivered.

    `console` counts as ready so a developer can sign in locally, but the
    front-end is told separately that delivery is only simulated.
    """
    if EMAIL_PROVIDER == "console":
        return True
    if EMAIL_PROVIDER == "gmail":
        return bool(SMTP_USER and SMTP_PASSWORD)
    return bool(EMAIL_API_KEY)


def provider_is_live() -> bool:
    """True only for a provider that really delivers to a mailbox."""
    if EMAIL_PROVIDER == "gmail":
        return bool(SMTP_USER and SMTP_PASSWORD)
    return EMAIL_PROVIDER in {"resend", "brevo"} and bool(EMAIL_API_KEY)


def _from_address() -> str:
    """The bare address, for providers that want name and address separately."""
    match = _ADDRESS_RE.search(EMAIL_FROM)
    return (match.group(1) if match else EMAIL_FROM).strip()


def _from_name() -> str:
    """The display name, preferring an explicit EMAIL_FROM_NAME."""
    if EMAIL_FROM_NAME:
        return EMAIL_FROM_NAME
    match = re.match(r"^\s*([^<]+?)\s*<", EMAIL_FROM)
    return match.group(1).strip() if match else "Tamridiano"


def _code_email(code: str, ttl_minutes: int) -> tuple[str, str, str]:
    """Subject, plain-text body, and HTML body for a sign-in code.

    The code is wrapped in a left-to-right isolate (U+2066) so it stays in place
    and reads in the right order inside an otherwise RTL Arabic line.
    """
    isolated = f"\u2066{code}\u2069"
    subject = f"كود الدخول إلى تمريضيانو: {isolated}"
    text = (
        f"كود الدخول الخاص بك هو: {isolated}\n\n"
        f"الكود صالح لمدة {ttl_minutes} دقائق ويُستخدم مرة واحدة.\n"
        "إذا لم تطلب هذا الكود، تجاهل هذه الرسالة.\n"
    )
    html = f"""\
<div dir="rtl" style="font-family:system-ui,Segoe UI,Tahoma,sans-serif;line-height:1.9;color:#0f172a">
  <h2 style="margin:0 0 12px">تمريضيانو</h2>
  <p style="margin:0 0 8px">كود الدخول الخاص بك هو:</p>
  <p style="margin:0 0 12px">
    <span dir="ltr" style="display:inline-block;font-size:30px;font-weight:800;letter-spacing:8px;
                 padding:10px 18px;border-radius:12px;background:#eef2ff;color:#1e293b">{code}</span>
  </p>
  <p style="margin:0 0 8px;color:#475569">
    الكود صالح لمدة {ttl_minutes} دقائق ويُستخدم مرة واحدة.
  </p>
  <p style="margin:0;color:#94a3b8;font-size:13px">
    إذا لم تطلب هذا الكود، تجاهل هذه الرسالة.
  </p>
</div>"""
    return subject, text, html


async def _send_smtp(to_email: str, subject: str, text: str, html: str) -> None:
    """Send over Gmail SMTP.

    smtplib is blocking, so it runs in a worker thread to keep the event loop
    free while the provider is contacted.
    """
    if not (SMTP_USER and SMTP_PASSWORD):
        raise MailError("لم يتم ضبط بيانات SMTP على الخادم، تعذّر إرسال الكود.")

    message = EmailMessage()
    # Gmail rewrites the From header to the authenticated account unless the
    # address is an alias on it, so the sender is the SMTP user by default.
    message["From"] = f"{_from_name()} <{SMTP_USER}>"
    message["To"] = to_email
    message["Subject"] = subject
    message.set_content(text)
    message.add_alternative(html, subtype="html")

    def _deliver() -> None:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=EMAIL_TIMEOUT) as server:
            server.starttls()
            try:
                server.login(SMTP_USER, SMTP_PASSWORD)
            except smtplib.SMTPAuthenticationError as exc:
                raise MailError(
                    "خدمة البريد ترفض بيانات الدخول، تأكّد من SMTP_USER وكلمة مرور التطبيق."
                ) from exc
            except smtplib.SMTPServerDisconnected as exc:
                # Gmail drops the connection rather than answering 535 when it
                # dislikes the credentials, so treat a disconnect here as an
                # auth failure instead of reporting a network problem.
                raise MailError(
                    "خدمة البريد رفضت تسجيل الدخول، تأكّد من SMTP_USER وكلمة مرور التطبيق."
                ) from exc
            server.send_message(message)

    try:
        await asyncio.to_thread(_deliver)
    except MailError:
        raise
    except smtplib.SMTPException as exc:
        log.error("smtp send failed: %s", exc)
        raise MailError("تعذّر الاتصال بخدمة البريد، حاول مرة أخرى.") from exc
    except OSError as exc:
        log.error("smtp connection failed: %s", exc)
        raise MailError("تعذّر الاتصال بخدمة البريد، حاول مرة أخرى.") from exc


async def send_login_code(to_email: str, code: str, ttl_minutes: int) -> None:
    """Deliver a sign-in code, raising MailError with an Arabic message on failure."""
    if EMAIL_PROVIDER not in _SUPPORTED:
        raise MailError(
            f"مزوّد البريد «{EMAIL_PROVIDER}» غير مدعوم. "
            "استخدم resend أو brevo أو gmail أو console."
        )

    subject, text, html = _code_email(code, ttl_minutes)

    if EMAIL_PROVIDER == "console":
        # Deliberately logged at WARNING so it stands out in a dev terminal.
        log.warning("رمز الدخول لـ %s هو %s (مزوّد console — للتطوير فقط)", to_email, code)
        return

    if EMAIL_PROVIDER == "gmail":
        await _send_smtp(to_email, subject, text, html)
        return

    if not EMAIL_API_KEY:
        raise MailError("لم يتم ضبط EMAIL_API_KEY على الخادم، تعذّر إرسال الكود.")

    if EMAIL_PROVIDER == "resend":
        payload = {"from": EMAIL_FROM, "to": [to_email], "subject": subject, "text": text, "html": html}
        headers = {"Authorization": f"Bearer {EMAIL_API_KEY}"}
        url = RESEND_URL
    else:  # brevo
        payload = {
            "sender": {"email": _from_address(), "name": _from_name()},
            "to": [{"email": to_email}],
            "subject": subject,
            "textContent": text,
            "htmlContent": html,
        }
        headers = {"api-key": EMAIL_API_KEY, "accept": "application/json"}
        url = BREVO_URL

    try:
        async with httpx.AsyncClient(timeout=EMAIL_TIMEOUT) as client:
            resp = await client.post(url, json=payload, headers=headers)
    except httpx.HTTPError as exc:
        log.error("email provider unreachable: %s", exc)
        raise MailError("تعذّر الاتصال بخدمة البريد، حاول مرة أخرى.") from exc

    if resp.status_code >= 400:
        # Log the provider's own words, but do not leak them to the student.
        log.error("email provider rejected the send: %s %s", resp.status_code, resp.text[:400])
        if resp.status_code in (401, 403):
            raise MailError("خدمة البريد ترفض المفتاح الحالي، تحقّق من إعدادات الخادم.")
        if resp.status_code == 429:
            raise MailError("تم إرسال عدد كبير من الرسائل، حاول بعد قليل.")
        raise MailError("تعذّر إرسال الكود الآن، حاول مرة أخرى بعد قليل.")
