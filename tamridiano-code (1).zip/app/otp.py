"""Issue and verify emailed one-time sign-in codes.

Security properties this module is responsible for:

* The code is never stored, only its HMAC. A database leak yields no usable code.
* Codes are single-use and time-limited.
* Comparison is constant-time, so response timing does not reveal the code.
* A code is burned after a few wrong guesses, so a 6-digit code cannot be
  brute-forced within its lifetime.
* Requests are rate-limited per address and per client IP, which is what stops
  the endpoint from being used to bomb someone's inbox.

The rate-limit counters are read from the `login_codes` table rather than held in
process memory, so they stay correct across the multiple workers a real
deployment runs.
"""

import hashlib
import hmac
import logging
import re
import secrets
from datetime import timedelta

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from .config import (
    ALLOWED_EMAIL_DOMAINS,
    OTP_LENGTH,
    OTP_MAX_ATTEMPTS,
    OTP_MAX_PER_HOUR,
    OTP_MAX_PER_IP_HOUR,
    OTP_RESEND_SECONDS,
    OTP_SECRET,
    OTP_TTL_MINUTES,
)
from .models import LoginCode, utcnow

log = logging.getLogger("tamridiano.otp")

# Deliberately permissive: the code is what proves ownership, so a stricter
# pattern would only reject valid addresses. The domain check is separate.
_EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s.]+(\.[^@\s.]+)+$")


class OtpError(RuntimeError):
    """Carries an Arabic message safe to show the student."""


def normalise_email(raw: str | None) -> str:
    """Lower-case and validate an address, raising OtpError when unusable."""
    email = (raw or "").strip().lower()
    if not email or not _EMAIL_RE.match(email) or len(email) > 320:
        raise OtpError("اكتب بريدًا إلكترونيًا صحيحًا.")
    if ALLOWED_EMAIL_DOMAINS:
        domain = email.rsplit("@", 1)[1]
        if domain not in ALLOWED_EMAIL_DOMAINS:
            allowed = "، ".join("@" + d for d in sorted(ALLOWED_EMAIL_DOMAINS))
            raise OtpError(f"الدخول متاح فقط لبريد من: {allowed}")
    return email


def _hash(email: str, code: str) -> str:
    """Key the digest with the email so a hash cannot be replayed to another address."""
    return hmac.new(OTP_SECRET.encode(), f"{email}:{code}".encode(), hashlib.sha256).hexdigest()


def _new_code() -> str:
    """A uniformly random decimal code, zero-padded to the configured length.

    `secrets.randbelow` avoids the modulo bias of `randint`-style sampling.
    """
    upper = 10 ** OTP_LENGTH
    return str(secrets.randbelow(upper)).zfill(OTP_LENGTH)


async def _count_recent(db: AsyncSession, *, since, email: str | None = None, ip: str | None = None) -> int:
    stmt = select(func.count()).select_from(LoginCode).where(LoginCode.created_at >= since)
    if email is not None:
        stmt = stmt.where(LoginCode.email == email)
    if ip is not None:
        stmt = stmt.where(LoginCode.request_ip == ip)
    return int((await db.scalar(stmt)) or 0)


async def issue_code(db: AsyncSession, email: str, request_ip: str | None) -> str:
    """Create and persist a code for `email`, returning the plaintext to send.

    Raises OtpError when a rate limit applies.
    """
    now = utcnow()

    latest = await db.scalar(
        select(LoginCode.created_at)
        .where(LoginCode.email == email)
        .order_by(LoginCode.created_at.desc())
        .limit(1)
    )
    if latest is not None:
        elapsed = (now - latest).total_seconds()
        if elapsed < OTP_RESEND_SECONDS:
            wait = max(1, int(OTP_RESEND_SECONDS - elapsed))
            raise OtpError(f"تم إرسال كود بالفعل. انتظر {wait} ثانية قبل طلب كود جديد.")

    if await _count_recent(db, since=now - timedelta(hours=1), email=email) >= OTP_MAX_PER_HOUR:
        raise OtpError("طلبت عددًا كبيرًا من الأكواد. حاول بعد ساعة.")

    if request_ip:
        per_ip = await _count_recent(db, since=now - timedelta(hours=1), ip=request_ip)
        if per_ip >= OTP_MAX_PER_IP_HOUR:
            raise OtpError("عدد كبير من الطلبات من هذا الجهاز. حاول بعد ساعة.")

    code = _new_code()
    # Supersede any code still outstanding for this address, so only the newest
    # one is ever valid and an old email cannot be replayed later.
    stale = (
        await db.scalars(
            select(LoginCode).where(LoginCode.email == email, LoginCode.consumed_at.is_(None))
        )
    ).all()
    for row in stale:
        row.consumed_at = now

    db.add(
        LoginCode(
            email=email,
            code_hash=_hash(email, code),
            created_at=now,
            expires_at=now + timedelta(minutes=OTP_TTL_MINUTES),
            request_ip=request_ip,
        )
    )
    await db.commit()
    return code


async def verify_code(db: AsyncSession, email: str, code: str) -> None:
    """Consume a code, raising OtpError when it is wrong, expired, or used up."""
    supplied = (code or "").strip().replace(" ", "").replace("-", "")
    if not supplied.isdigit():
        raise OtpError("اكتب الكود المكوّن من أرقام فقط.")

    row = await db.scalar(
        select(LoginCode)
        .where(LoginCode.email == email, LoginCode.consumed_at.is_(None))
        .order_by(LoginCode.created_at.desc())
        .limit(1)
    )
    if row is None:
        raise OtpError("اطلب كودًا جديدًا أولًا.")

    now = utcnow()
    if row.expires_at < now:
        raise OtpError("انتهت صلاحية الكود. اطلب كودًا جديدًا.")

    if row.attempts >= OTP_MAX_ATTEMPTS:
        # Burn it rather than leaving it open to unlimited guessing.
        row.consumed_at = now
        await db.commit()
        raise OtpError("تم استنفاد محاولات هذا الكود. اطلب كودًا جديدًا.")

    # Count the attempt before comparing, so a crash mid-verify cannot lose a guess.
    row.attempts += 1

    if not hmac.compare_digest(row.code_hash, _hash(email, supplied)):
        remaining = OTP_MAX_ATTEMPTS - row.attempts
        if remaining <= 0:
            row.consumed_at = now
            await db.commit()
            raise OtpError("الكود غير صحيح. اطلب كودًا جديدًا.")
        await db.commit()
        raise OtpError(f"الكود غير صحيح. المحاولات المتبقية: {remaining}")

    row.consumed_at = now
    await db.commit()


async def purge_expired(db: AsyncSession) -> int:
    """Delete rows that are long dead so the table does not grow without bound."""
    cutoff = utcnow() - timedelta(days=7)
    rows = (
        await db.scalars(select(LoginCode).where(LoginCode.created_at < cutoff))
    ).all()
    for row in rows:
        await db.delete(row)
    if rows:
        await db.commit()
    return len(rows)
