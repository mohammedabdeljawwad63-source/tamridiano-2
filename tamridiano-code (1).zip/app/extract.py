"""Turn uploaded curriculum files into plain text.

Handles the two ways Arabic source material usually arrives: PDFs, and plain-text
files written by Windows editors that save in a single-byte Arabic code page
rather than UTF-8.
"""

import io
import logging
from pathlib import Path

from .llm import pdf_to_text

log = logging.getLogger("tamridiano.extract")

TEXT_SUFFIXES = {".txt", ".md", ".csv"}
OFFICE_SUFFIXES = {".docx", ".pptx"}
SUPPORTED_SUFFIXES = TEXT_SUFFIXES | OFFICE_SUFFIXES | {".pdf"}

ACCEPT_ATTR = ",".join(sorted(SUPPORTED_SUFFIXES))

REPLACEMENT = "\ufffd"

# Arabic-capable single-byte code pages. cp1256 is the Windows Arabic ANSI code
# page and by far the most common source of mojibake in Arabic .txt files.
LEGACY_ENCODINGS = ("cp1256", "iso-8859-6", "cp720", "cp864", "cp1252", "latin-1")

_BOMS = ((b"\xef\xbb\xbf", "utf-8-sig"), (b"\xff\xfe", "utf-16"), (b"\xfe\xff", "utf-16"))


def _damage_ratio(text: str) -> float:
    """Fraction of characters that signal a bad decode or a broken PDF font map."""
    if not text:
        return 1.0
    bad = 0
    for ch in text:
        if ch == REPLACEMENT:
            bad += 1
        elif ord(ch) < 32 and ch not in "\t\n\r":
            bad += 1
        elif 0xE000 <= ord(ch) <= 0xF8FF:  # private use area
            bad += 1
    return bad / len(text)


def _readable_ratio(text: str) -> float:
    stripped = text.strip()
    if not stripped:
        return 0.0
    return sum(1 for ch in stripped if ch.isalnum()) / len(stripped)


def decode_text(data: bytes) -> tuple[str, str | None]:
    """Decode bytes to text, returning the text and an optional encoding warning."""
    for bom, encoding in _BOMS:
        if data.startswith(bom):
            return data.decode(encoding, errors="replace"), None

    try:
        return data.decode("utf-8"), None
    except UnicodeDecodeError:
        pass

    candidates: list[tuple[str, str]] = []
    try:
        from charset_normalizer import from_bytes

        match = from_bytes(data).best()
        if match is not None:
            candidates.append((str(match), match.encoding))
    except Exception:  # noqa: BLE001 - detection is best-effort
        log.debug("charset-normalizer unavailable; probing code pages only")

    for encoding in LEGACY_ENCODINGS:
        try:
            candidates.append((data.decode(encoding), encoding))
        except (UnicodeDecodeError, LookupError):
            continue

    if not candidates:
        return data.decode("utf-8", errors="replace"), "تعذّر تحديد ترميز الملف."

    text, encoding = min(candidates, key=lambda c: (_damage_ratio(c[0]), -_readable_ratio(c[0])))
    normalized = encoding.lower().replace("_", "-")
    warning = None if normalized in {"utf-8", "ascii"} else f"تم قراءة الملف بترميز {encoding}."
    return text, warning


def check_text(text: str) -> str | None:
    """Return an Arabic explanation of why `text` is unusable, or None when it is fine."""
    stripped = text.strip()
    if not stripped:
        return "الملف لا يحتوي على نص قابل للقراءة."
    if len(stripped) >= 60 and _readable_ratio(stripped) < 0.35:
        return (
            "تعذّر قراءة نص واضح من الملف — يبدو أنه صورة ممسوحة (Scanned) أو أن خطوطه "
            "غير قابلة للاستخراج. ارفع ملف PDF نصيًا أو ملف TXT، أو الصق نص الشرح يدويًا."
        )
    if _damage_ratio(stripped) > 0.05:
        return "نص الملف تالف أو بترميز غير مدعوم. أعد حفظ الملف بترميز UTF-8 ثم ارفعه من جديد."
    return None


def _docx_text(data: bytes) -> str:
    """Paragraphs and table cells from a .docx, in document order."""
    from docx import Document

    try:
        doc = Document(io.BytesIO(data))
    except Exception as exc:  # noqa: BLE001 - python-docx raises assorted errors
        raise ValueError("تعذّر قراءة ملف Word — تأكد أن الملف بصيغة docx وسليم.") from exc

    blocks = [p.text for p in doc.paragraphs]
    for table in doc.tables:
        for row in table.rows:
            cells = [c.text.strip() for c in row.cells]
            if any(cells):
                blocks.append(" | ".join(cells))
    return "\n".join(b for b in blocks if b.strip())


def _pptx_text(data: bytes) -> str:
    """Text frames from every slide of a .pptx."""
    from pptx import Presentation

    try:
        prs = Presentation(io.BytesIO(data))
    except Exception as exc:  # noqa: BLE001 - python-pptx raises assorted errors
        raise ValueError("تعذّر قراءة ملف العرض — تأكد أن الملف بصيغة pptx وسليم.") from exc

    slides: list[str] = []
    for idx, slide in enumerate(prs.slides, start=1):
        lines: list[str] = []
        for shape in slide.shapes:
            if getattr(shape, "has_text_frame", False) and shape.text_frame.text.strip():
                lines.append(shape.text_frame.text.strip())
            if getattr(shape, "has_table", False):
                for row in shape.table.rows:
                    cells = [c.text.strip() for c in row.cells]
                    if any(cells):
                        lines.append(" | ".join(cells))
        if lines:
            slides.append(f"[Slide {idx}]\n" + "\n".join(lines))
    return "\n\n".join(slides)


def extract_text(data: bytes, filename: str) -> tuple[str, str | None]:
    """Extract text from an uploaded file. Raises ValueError when nothing usable is found."""
    suffix = Path(filename).suffix.lower()
    warning: str | None = None

    if suffix == ".pdf":
        text = pdf_to_text(data)
    elif suffix == ".docx":
        text = _docx_text(data)
    elif suffix == ".pptx":
        text = _pptx_text(data)
    elif suffix in TEXT_SUFFIXES:
        text, warning = decode_text(data)
    else:
        raise ValueError(
            "الملفات المدعومة: PDF أو DOCX أو PPTX أو TXT أو MD أو CSV. "
            "إن كان ملفك بصيغة قديمة (doc أو ppt) احفظه بصيغة docx أو pdf أولًا."
        )

    problem = check_text(text)
    if problem:
        raise ValueError(problem)
    return text, warning
