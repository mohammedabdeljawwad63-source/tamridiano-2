"""Self-ping keep-alive for free hosts that spin down when idle.

A free web service (Render, Koyeb) is suspended after ~15 minutes without
inbound traffic, and the next visitor then waits about a minute for a cold
start. A timer inside the app removes that wait: it requests the app's own
public health endpoint every few minutes, and the platform counts the request
as inbound traffic.

Two limits are worth knowing before relying on this:

* It only *prevents* a spin-down. A service that is already asleep cannot ping
  itself awake, because this code is not running — waking a sleeping service
  needs an external pinger (cron-job.org, UptimeRobot) or a real visitor.
* With several workers, each process would run its own timer and send duplicate
  requests. A file lock elects a single worker to run it.
"""

import asyncio
import fcntl
import logging

import httpx

from .config import DATA_DIR, KEEP_ALIVE, KEEP_ALIVE_INTERVAL_MINUTES, KEEP_ALIVE_URL

log = logging.getLogger("tamridiano.keepalive")

_lock_handle = None


def _elect_worker() -> bool:
    """Return True in exactly one worker process.

    The lock is held for the lifetime of the process, so the first worker to
    start keeps the timer and the rest skip it. If locking is unavailable we
    return True: a duplicate ping is harmless, a missing one is not.
    """
    global _lock_handle
    try:
        handle = open(DATA_DIR / ".keepalive.lock", "w")
        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        return False
    _lock_handle = handle
    return True


async def _ping_loop(url: str, interval_seconds: float) -> None:
    # Wait a full interval before the first ping: the service was just started
    # by a deploy or a real request, so it is already awake and spending a
    # request now would only delay the first real one.
    await asyncio.sleep(interval_seconds)
    async with httpx.AsyncClient(timeout=30.0, follow_redirects=True) as client:
        while True:
            try:
                response = await client.get(url)
                log.info("keep-alive ping %s -> %s", url, response.status_code)
            except Exception as exc:  # noqa: BLE001 - a failed ping must not kill the loop
                log.warning("keep-alive ping %s failed: %s", url, exc)
            await asyncio.sleep(interval_seconds)


async def keep_alive_task() -> None:
    """Start the timer if configured; return immediately otherwise.

    Never raises: a keep-alive that cannot start must not stop the app from
    serving students.
    """
    if not KEEP_ALIVE:
        return
    if not KEEP_ALIVE_URL:
        log.warning(
            "KEEP_ALIVE is on but no URL is known; set KEEP_ALIVE_URL or run on "
            "a host that provides one (Render sets RENDER_EXTERNAL_URL)"
        )
        return
    if not _elect_worker():
        return

    interval = KEEP_ALIVE_INTERVAL_MINUTES * 60
    log.info("keep-alive enabled: pinging %s every %s minutes", KEEP_ALIVE_URL, KEEP_ALIVE_INTERVAL_MINUTES)
    try:
        await _ping_loop(KEEP_ALIVE_URL, interval)
    except asyncio.CancelledError:
        raise
    except Exception as exc:  # noqa: BLE001
        log.warning("keep-alive stopped: %s", exc)
