import logging
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import selectinload
from sqlalchemy.ext.asyncio import AsyncSession

from ..db import get_db
from ..generator import explain_mistake, grade_written, student_chat
from ..llm import LLMError
from ..models import Answer, Attempt, Exam, Question, iso_utc, utcnow
from ..security import optional_user, require_admin, require_user

log = logging.getLogger("tamridiano.attempts")

router = APIRouter(prefix="/api/attempts", tags=["attempts"])

WRITTEN_TYPES = {"essay", "short"}


class StartIn(BaseModel):
    exam_id: int
    student_name: str = Field(min_length=1, max_length=160)
    student_id: str | None = Field(default=None, max_length=80)


class AnswerIn(BaseModel):
    question_id: int
    response: str | None = None


class SubmitIn(BaseModel):
    answers: list[AnswerIn] = Field(default_factory=list)


class ChatIn(BaseModel):
    message: str = Field(min_length=1)
    history: list[dict] = Field(default_factory=list)


def _is_correct(qtype: str, correct: str | None, response: str | None) -> bool | None:
    if response is None or not str(response).strip():
        return False
    if qtype in WRITTEN_TYPES:
        return None
    return str(response).strip().casefold() == str(correct or "").strip().casefold()


@router.post("/start", status_code=status.HTTP_201_CREATED)
async def start_attempt(
    payload: StartIn,
    db: AsyncSession = Depends(get_db),
    user: dict | None = Depends(optional_user),
):
    exam = await db.get(Exam, payload.exam_id)
    if not exam or not exam.is_published:
        raise HTTPException(status_code=404, detail="الاختبار غير موجود")

    questions = (
        await db.scalars(
            select(Question).where(Question.exam_id == exam.id).order_by(Question.order_index)
        )
    ).all()
    if not questions:
        raise HTTPException(status_code=422, detail="هذا الاختبار لا يحتوي على أسئلة")

    student_name = payload.student_name.strip()[:160]
    student_id = (payload.student_id or "").strip()[:80] or None
    # A signed-in student's attempt is tied to their account (and, for the email
    # flow, to their verified address). That is what lets them see their own
    # results without retyping a name, and stops anyone else from claiming them.
    student_email = (user or {}).get("email") or None
    account_id = (user or {}).get("student_account_id") or None

    # Resume an unfinished attempt instead of creating duplicates for the same student.
    if account_id:
        # Match on the account so a student who edits their name still resumes.
        resume_filter = (Attempt.student_account_id == account_id,)
    else:
        resume_filter = (
            Attempt.student_name == student_name,
            Attempt.student_email.is_(None) if not student_email else Attempt.student_email == student_email,
        )
    existing = await db.scalar(
        select(Attempt)
        .where(Attempt.exam_id == exam.id, Attempt.status == "in_progress", *resume_filter)
        .order_by(Attempt.id.desc())
    )
    now = utcnow()
    if existing is not None and (existing.expires_at is None or existing.expires_at > now):
        changed = False
        if student_id and not existing.student_id:
            existing.student_id = student_id
            changed = True
        if student_email and not existing.student_email:
            existing.student_email = student_email
            changed = True
        if account_id and not existing.student_account_id:
            existing.student_account_id = account_id
            changed = True
        if changed:
            await db.commit()
        return _attempt_payload(existing, exam, questions)

    expires_at = now + timedelta(minutes=exam.duration_minutes) if exam.timed and exam.duration_minutes else None

    attempt = Attempt(
        exam_id=exam.id,
        student_name=student_name,
        student_id=student_id,
        student_email=student_email,
        student_account_id=account_id,
        started_at=now,
        expires_at=expires_at,
        max_score=sum(q.points for q in questions),
    )
    db.add(attempt)
    await db.commit()
    await db.refresh(attempt)
    return _attempt_payload(attempt, exam, questions)


def _attempt_payload(attempt: Attempt, exam: Exam, questions: list[Question]) -> dict:
    return {
        "attempt_id": attempt.id,
        "exam_id": exam.id,
        "title": exam.title,
        "student_name": attempt.student_name,
        "student_id": attempt.student_id,
        "timed": exam.timed,
        "duration_minutes": exam.duration_minutes,
        "started_at": iso_utc(attempt.started_at),
        "expires_at": iso_utc(attempt.expires_at),
        "server_time": iso_utc(utcnow()),
        "max_score": attempt.max_score,
        "questions": [
            {
                "id": q.id,
                "type": q.qtype,
                "text": q.text,
                "options": q.options,
                "points": q.points,
            }
            for q in questions
        ],
    }


@router.get("/{attempt_id:int}")
async def get_attempt(attempt_id: int, db: AsyncSession = Depends(get_db)):
    """Resume an in-progress attempt after a page reload. Never leaks answers."""
    attempt = await db.get(Attempt, attempt_id)
    if not attempt:
        raise HTTPException(status_code=404, detail="المحاولة غير موجودة")
    if attempt.status != "in_progress":
        raise HTTPException(status_code=409, detail="تم تسليم هذه المحاولة بالفعل")
    exam = await db.get(Exam, attempt.exam_id)
    if not exam:
        raise HTTPException(status_code=404, detail="الاختبار غير موجود")
    questions = (
        await db.scalars(
            select(Question).where(Question.exam_id == exam.id).order_by(Question.order_index)
        )
    ).all()
    return _attempt_payload(attempt, exam, questions)


@router.post("/{attempt_id:int}/submit")
async def submit_attempt(attempt_id: int, payload: SubmitIn, db: AsyncSession = Depends(get_db)):
    attempt = await db.get(Attempt, attempt_id)
    if not attempt:
        raise HTTPException(status_code=404, detail="المحاولة غير موجودة")
    if attempt.status == "submitted":
        raise HTTPException(status_code=409, detail="تم تسليم هذا الاختبار بالفعل")

    exam = await db.get(Exam, attempt.exam_id)
    questions = (
        await db.scalars(
            select(Question).where(Question.exam_id == attempt.exam_id).order_by(Question.order_index)
        )
    ).all()
    by_id = {q.id: q for q in questions}

    provided = {a.question_id: (a.response or "").strip() for a in payload.answers}

    existing = {
        a.question_id: a
        for a in (
            await db.scalars(select(Answer).where(Answer.attempt_id == attempt_id))
        ).all()
    }

    score = 0.0
    for q in questions:
        response = provided.get(q.id, "")
        answer_row = existing.get(q.id) or Answer(attempt_id=attempt_id, question_id=q.id)
        answer_row.response = response or None

        correct = _is_correct(q.qtype, q.correct_answer, response)
        if q.qtype in WRITTEN_TYPES:
            if not response:
                awarded, feedback = 0.0, "لم تتم الإجابة على هذا السؤال."
            else:
                awarded, feedback = await grade_written(
                    question_text=q.text,
                    model_answer=q.correct_answer,
                    student_answer=response,
                    max_points=q.points,
                )
            answer_row.is_correct = awarded >= q.points * 0.6
            answer_row.awarded = awarded
            answer_row.ai_feedback = feedback
        else:
            awarded = q.points if correct else 0.0
            answer_row.is_correct = bool(correct)
            answer_row.awarded = awarded

        score += awarded
        if answer_row.id is None:
            db.add(answer_row)

    attempt.score = round(score, 2)
    attempt.max_score = sum(q.points for q in questions)
    attempt.submitted_at = utcnow()
    # Grace window: the client may submit a few seconds after the deadline.
    expired = attempt.expires_at is not None and (utcnow() - attempt.expires_at).total_seconds() > 20
    attempt.status = "expired" if expired else "submitted"
    await db.commit()

    return await _result_payload(db, attempt, exam, questions)


async def _result_payload(db: AsyncSession, attempt: Attempt, exam: Exam, questions: list[Question]) -> dict:
    rows = (
        await db.scalars(select(Answer).where(Answer.attempt_id == attempt.id))
    ).all()
    by_q = {r.question_id: r for r in rows}

    items = []
    correct_count = 0
    wrong_count = 0
    for q in questions:
        row = by_q.get(q.id)
        response = row.response if row else None
        awarded = row.awarded if row and row.awarded is not None else 0.0
        is_correct = row.is_correct if row else None
        if is_correct:
            correct_count += 1
        else:
            wrong_count += 1
        items.append(
            {
                "question_id": q.id,
                "type": q.qtype,
                "text": q.text,
                "options": q.options,
                "points": q.points,
                "student_answer": response,
                "correct_answer": q.correct_answer,
                "explanation": q.explanation,
                "is_correct": is_correct,
                "awarded": awarded,
                "ai_feedback": row.ai_feedback if row else None,
            }
        )

    max_score = attempt.max_score or sum(q.points for q in questions) or 1
    return {
        "attempt_id": attempt.id,
        "exam_id": attempt.exam_id,
        "title": exam.title if exam else None,
        "student_name": attempt.student_name,
        "status": attempt.status,
        "started_at": iso_utc(attempt.started_at),
        "submitted_at": iso_utc(attempt.submitted_at),
        "score": attempt.score,
        "max_score": attempt.max_score,
        "percentage": round((attempt.score or 0) / max_score * 100, 2),
        "correct_count": correct_count,
        "wrong_count": wrong_count,
        "total_questions": len(questions),
        "items": items,
    }


@router.get("/{attempt_id:int}/result")
async def attempt_result(attempt_id: int, db: AsyncSession = Depends(get_db)):
    attempt = await db.get(Attempt, attempt_id)
    if not attempt:
        raise HTTPException(status_code=404, detail="المحاولة غير موجودة")
    if attempt.status == "in_progress":
        raise HTTPException(status_code=409, detail="لم يتم تسليم الاختبار بعد")
    exam = await db.get(Exam, attempt.exam_id)
    questions = (
        await db.scalars(
            select(Question).where(Question.exam_id == attempt.exam_id).order_by(Question.order_index)
        )
    ).all()
    return await _result_payload(db, attempt, exam, questions)


@router.get("/history")
async def history(
    student_id: str | None = None,
    student_name: str | None = None,
    db: AsyncSession = Depends(get_db),
    user: dict | None = Depends(optional_user),
):
    """Results for the caller.

    A signed-in student sees their own attempts. A self-registered account is
    matched on its account id (falling back to the student number it signed in
    with, so results taken before accounts existed are still found). An email
    session is matched on the verified address. Either way nobody can read
    another student's results by guessing a name.

    When no session is present (an admin previewing, or a deployment that has not
    turned sign-in on yet) the name/ID lookup still works, which is what the admin
    dashboard and the pre-sign-in behaviour rely on.
    """
    email = (user or {}).get("email") or None
    account_id = (user or {}).get("student_account_id") or None
    account_number = (user or {}).get("student_number") or None

    stmt = (
        select(Attempt)
        .where(Attempt.status != "in_progress")
        .order_by(Attempt.submitted_at.desc())
        .limit(200)
    )

    if account_id:
        # Include attempts taken with the same number before accounts existed, so
        # a student does not lose their earlier results after registering.
        if account_number:
            stmt = stmt.where(
                (Attempt.student_account_id == account_id)
                | (Attempt.student_account_id.is_(None) & (Attempt.student_id == account_number))
            )
        else:
            stmt = stmt.where(Attempt.student_account_id == account_id)
    elif email:
        stmt = stmt.where(Attempt.student_email == email)
    elif student_id:
        stmt = stmt.where(Attempt.student_id == student_id.strip())
    elif student_name:
        stmt = stmt.where(Attempt.student_name == student_name.strip())
    else:
        raise HTTPException(status_code=400, detail="حدد رقم الطالب أو اسمه لعرض النتائج")

    attempts = (await db.scalars(stmt)).all()
    exam_ids = {a.exam_id for a in attempts}
    exam_map: dict[int, Exam] = {}
    subject_map: dict[int, str] = {}
    if exam_ids:
        exams = (await db.scalars(select(Exam).where(Exam.id.in_(exam_ids)))).all()
        exam_map = {e.id: e for e in exams}
        from ..models import Subject

        subject_map = dict(
            (await db.execute(select(Subject.id, Subject.name))).all()
        )

    return {
        "attempts": [
            {
                "attempt_id": a.id,
                "exam_id": a.exam_id,
                "exam_title": exam_map[a.exam_id].title if a.exam_id in exam_map else None,
                "subject_name": subject_map.get(exam_map[a.exam_id].subject_id)
                if a.exam_id in exam_map
                else None,
                "score": a.score,
                "max_score": a.max_score,
                "percentage": round((a.score or 0) / (a.max_score or 1) * 100, 2),
                "submitted_at": iso_utc(a.submitted_at),
                "status": a.status,
            }
            for a in attempts
        ]
    }


@router.post("/{attempt_id:int}/explain/{question_id:int}")
async def explain_question(attempt_id: int, question_id: int, db: AsyncSession = Depends(get_db)):
    attempt = await db.get(Attempt, attempt_id)
    if not attempt:
        raise HTTPException(status_code=404, detail="المحاولة غير موجودة")
    question = await db.get(Question, question_id)
    if not question or question.exam_id != attempt.exam_id:
        raise HTTPException(status_code=404, detail="السؤال غير موجود في هذا الاختبار")
    row = await db.scalar(
        select(Answer).where(Answer.attempt_id == attempt_id, Answer.question_id == question_id)
    )
    if row and row.ai_feedback:
        return {"question_id": question_id, "explanation": row.ai_feedback, "cached": True}

    try:
        text = await explain_mistake(
            question_text=question.text,
            options=question.options,
            correct_answer=question.correct_answer,
            student_answer=row.response if row else None,
            base_explanation=question.explanation,
        )
    except LLMError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    if row:
        row.ai_feedback = text
        await db.commit()
    return {"question_id": question_id, "explanation": text, "cached": False}


@router.post("/{attempt_id:int}/chat")
async def attempt_chat(attempt_id: int, payload: ChatIn, db: AsyncSession = Depends(get_db)):
    attempt = await db.get(Attempt, attempt_id)
    if not attempt:
        raise HTTPException(status_code=404, detail="المحاولة غير موجودة")
    exam = await db.get(Exam, attempt.exam_id)

    questions = (
        await db.scalars(
            select(Question).where(Question.exam_id == attempt.exam_id).order_by(Question.order_index)
        )
    ).all()
    context = "\n".join(f"- ({q.qtype}) {q.text} | correct: {q.correct_answer}" for q in questions[:40])
    if exam:
        context = f"Exam: {exam.title}\n{context}"

    messages = [
        {"role": m.get("role", "user"), "content": str(m.get("content", ""))}
        for m in payload.history[-10:]
        if m.get("role") in {"user", "assistant"}
    ]
    messages.append({"role": "user", "content": payload.message})

    try:
        reply = await student_chat(messages, context=context)
    except LLMError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    return {"reply": reply}


@router.get("/admin/overview", dependencies=[Depends(require_admin)])
async def admin_overview(db: AsyncSession = Depends(get_db)):
    total_attempts = await db.scalar(select(func.count(Attempt.id)))
    submitted = await db.scalar(
        select(func.count(Attempt.id)).where(Attempt.status != "in_progress")
    )
    avg = await db.scalar(
        select(func.avg(Attempt.score * 100.0 / func.nullif(Attempt.max_score, 0))).where(
            Attempt.status != "in_progress"
        )
    )
    exam_count = await db.scalar(select(func.count(Exam.id)))
    question_count = await db.scalar(select(func.count(Question.id)))
    return {
        "total_attempts": total_attempts or 0,
        "submitted_attempts": submitted or 0,
        "average_percentage": round(float(avg), 2) if avg is not None else None,
        "exams": exam_count or 0,
        "questions": question_count or 0,
    }


@router.get("/admin/exam/{exam_id}/results", dependencies=[Depends(require_admin)])
async def exam_results(exam_id: int, db: AsyncSession = Depends(get_db)):
    exam = await db.get(Exam, exam_id)
    if not exam:
        raise HTTPException(status_code=404, detail="الاختبار غير موجود")
    attempts = (
        await db.scalars(
            select(Attempt)
            .where(Attempt.exam_id == exam_id, Attempt.status != "in_progress")
            .order_by(Attempt.submitted_at.desc())
        )
    ).all()
    return {
        "exam_id": exam_id,
        "title": exam.title,
        "results": [
            {
                "attempt_id": a.id,
                "student_name": a.student_name,
                "student_id": a.student_id,
                "score": a.score,
                "max_score": a.max_score,
                "percentage": round((a.score or 0) / (a.max_score or 1) * 100, 2),
                "submitted_at": iso_utc(a.submitted_at),
                "status": a.status,
            }
            for a in attempts
        ],
    }
