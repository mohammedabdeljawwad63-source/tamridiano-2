import asyncio
import logging
import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, status
from fastapi.responses import FileResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import MAX_UPLOAD_MB, UPLOAD_DIR
from ..db import get_db
from ..extract import SUPPORTED_SUFFIXES, extract_text
from ..models import Material, Subject, iso_utc
from ..security import require_admin, require_identity

log = logging.getLogger("tamridiano.materials")

router = APIRouter(prefix="/api/materials", tags=["materials"])

KINDS = {"material", "explanation"}

# Exact content types per extension. Phones decide which native app opens a file
# from this header, so a generic octet-stream would force a download instead of
# handing the PDF/DOCX to the on-device viewer.
MEDIA_TYPES = {
    ".pdf": "application/pdf",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    ".txt": "text/plain; charset=utf-8",
    ".md": "text/plain; charset=utf-8",
    ".csv": "text/csv; charset=utf-8",
}


def _media_type(filename: str) -> str:
    return MEDIA_TYPES.get(Path(filename).suffix.lower(), "application/octet-stream")



@router.post("", dependencies=[Depends(require_admin)], status_code=status.HTTP_201_CREATED)
async def upload_material(
    subject_id: int = Form(...),
    title: str = Form(""),
    kind: str = Form("material"),
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
):
    if kind not in KINDS:
        raise HTTPException(status_code=400, detail="نوع الملف غير مدعوم")
    if not await db.get(Subject, subject_id):
        raise HTTPException(status_code=404, detail="المادة غير موجودة")

    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="الملف فارغ")
    if len(data) > MAX_UPLOAD_MB * 1024 * 1024:
        raise HTTPException(status_code=413, detail=f"حجم الملف أكبر من {MAX_UPLOAD_MB} ميجابايت")

    filename = file.filename or "upload"
    suffix = Path(filename).suffix.lower()
    if suffix not in SUPPORTED_SUFFIXES:
        raise HTTPException(
            status_code=400,
            detail="الملفات المدعومة: PDF أو DOCX أو PPTX أو TXT أو MD أو CSV",
        )

    # Reject unreadable files up front: storing them only fails later at generation
    # time, which is the confusing part for the admin. Extraction is CPU-heavy
    # (~1s for a large PDF), so it runs on a thread rather than freezing the loop.
    try:
        extracted, warning = await asyncio.to_thread(extract_text, data, filename)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    stored_name = f"{uuid.uuid4().hex}{suffix}"
    stored_path = UPLOAD_DIR / stored_name
    await asyncio.to_thread(stored_path.write_bytes, data)

    material = Material(
        subject_id=subject_id,
        title=(title.strip() or Path(filename).stem)[:300],
        filename=filename[:400],
        stored_path=str(stored_path),
        kind=kind,
        size_bytes=len(data),
        extracted_text=extracted,
    )
    db.add(material)
    await db.commit()
    await db.refresh(material)

    return {
        "id": material.id,
        "subject_id": material.subject_id,
        "title": material.title,
        "filename": material.filename,
        "kind": material.kind,
        "size_bytes": material.size_bytes,
        "text_ready": True,
        "text_chars": len(extracted),
        "warning": warning,
        "created_at": iso_utc(material.created_at),
    }


@router.get("", dependencies=[Depends(require_admin)])
async def list_materials(subject_id: int | None = None, db: AsyncSession = Depends(get_db)):
    stmt = select(Material).order_by(Material.created_at.desc())
    if subject_id is not None:
        stmt = stmt.where(Material.subject_id == subject_id)
    items = (await db.scalars(stmt)).all()
    return {
        "materials": [
            {
                "id": m.id,
                "subject_id": m.subject_id,
                "title": m.title,
                "filename": m.filename,
                "kind": m.kind,
                "size_bytes": m.size_bytes,
                "text_ready": bool(m.extracted_text),
                "text_chars": len(m.extracted_text or ""),
                "created_at": iso_utc(m.created_at),
            }
            for m in items
        ]
    }


@router.api_route(
    "/{material_id:int}/file",
    methods=["GET", "HEAD"],
    dependencies=[Depends(require_identity)],
)
async def material_file(material_id: int, download: bool = False, db: AsyncSession = Depends(get_db)):
    """Serve the stored original.

    Inline by default so a phone hands the file to its native viewer (PDF reader,
    Word, PowerPoint). `?download=1` forces a save instead.
    """
    material = await db.get(Material, material_id)
    if not material:
        raise HTTPException(status_code=404, detail="الملف غير موجود")
    path = Path(material.stored_path)
    if not path.is_file():
        raise HTTPException(status_code=410, detail="الملف الأصلي غير متاح على الخادم")
    disposition = "attachment" if download else "inline"
    # FileResponse encodes the filename per RFC 5987, which is required here
    # because curriculum filenames are usually Arabic and cannot go in a
    # latin-1 header value verbatim.
    return FileResponse(
        path,
        media_type=_media_type(material.filename),
        filename=material.filename,
        content_disposition_type=disposition,
    )


@router.get("/{material_id:int}/text", dependencies=[Depends(require_admin)])
async def material_text(material_id: int, db: AsyncSession = Depends(get_db)):
    material = await db.get(Material, material_id)
    if not material:
        raise HTTPException(status_code=404, detail="الملف غير موجود")
    return {
        "id": material.id,
        "title": material.title,
        "text_ready": bool(material.extracted_text),
        "text": material.extracted_text or "",
    }


@router.delete("/{material_id:int}", dependencies=[Depends(require_admin)])
async def delete_material(material_id: int, db: AsyncSession = Depends(get_db)):
    material = await db.get(Material, material_id)
    if not material:
        raise HTTPException(status_code=404, detail="الملف غير موجود")
    try:
        Path(material.stored_path).unlink(missing_ok=True)
    except OSError as exc:
        log.warning("Could not delete file %s: %s", material.stored_path, exc)
    await db.delete(material)
    await db.commit()
    return {"ok": True}
