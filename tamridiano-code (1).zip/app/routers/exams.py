import asyncio
import json
import logging
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, status
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import MAX_UPLOAD_MB
from ..db import get_db
from ..extract import check_text, extract_text
from ..generator import ExamSpec, generate_questions
from ..llm import LLMError
from ..models import Attempt, Exam, Material, Question, Subject, iso_utc
from ..security import require_admin

log = logging.getLogger("tamridiano.exams")

router = APIRouter(prefix="/api/exams", tags=["exams"])

QTYPES = ("mcq", "truefalse", "essay", "short")


class GenerateIn(BaseModel):
    subject_id: int
    title: str = Field(min_length=1, max_length=300)
    source_text: str | None = None
    material_id: int | None = None
    counts: dict[str, int] = Field(default_factory=lambda: {"mcq": 5})
    timed: bool = False
    duration_minutes: int | None = None
    difficulty: str = "medium"
    language_note: str = ""
    extra_instructions: str = ""
    description: str | None = None
    model: str | None = None


class QuestionIn(BaseModel):
    type: str
    text: str
    options: list[str] | None = None
    answer: str | None = None
    explanation: str | None = None
    points: float = 1.0


class ManualExamIn(BaseModel):
    subject_id: int
    title: str = Field(min_length=1, max_length=300)
    description: str | None = None
    timed: bool = False
    duration_minutes: int | None = None
    questions: list[QuestionIn] = Field(default_factory=list)


class ExamUpdateIn(BaseModel):
    title: str | None = None
    description: str | None = None
    timed: bool | None = None
    duration_minutes: int | None = None
    is_published: bool | None = None


def _question_public(q: Question, *, reveal: bool) -> dict:
    payload = {
        "id": q.id,
        "type": q.qtype,
        "text": q.text,
        "options": q.options,
        "points": q.points,
    }
    if reveal:
        payload["answer"] = q.correct_answer
        payload["explanation"] = q.explanation
    return payload


def _validate_counts(counts: dict[str, int]) -> dict[str, int]:
    clean: dict[str, int] = {}
    for qtype, count in (counts or {}).items():
        if qtype not in QTYPES:
            raise HTTPException(status_code=400, detail=f"نوع سؤال غير مدعوم: {qtype}")
        try:
            value = int(count)
        except (TypeError, ValueError):
            raise HTTPException(status_code=400, detail=f"عدد غير صالح للنوع {qtype}")
        if value < 0:
            raise HTTPException(status_code=400, detail="عدد الأسئلة لا يمكن أن يكون سالبًا")
        if value > 0:
            clean[qtype] = value
    if not clean:
        raise HTTPException(status_code=400, detail="حدد عددًا أكبر من صفر لنوع سؤال واحد على الأقل")
    if sum(clean.values()) > 200:
        raise HTTPException(status_code=400, detail="الحد الأقصى 200 سؤال في الاختبار الواحد")
    return clean


def _apply_timing(exam: Exam, timed: bool, duration_minutes: int | None) -> None:
    exam.timed = bool(timed)
    if exam.timed:
        if not duration_minutes or duration_minutes <= 0:
            raise HTTPException(status_code=400, detail="الاختبار الموقوت يحتاج مدة بالدقائق")
        exam.duration_minutes = int(duration_minutes)
    else:
        exam.duration_minutes = None


def _build_questions(exam_id: int, raw: list[dict]) -> list[Question]:
    questions: list[Question] = []
    for idx, item in enumerate(raw):
        qtype = str(item.get("type", "")).lower()
        if qtype not in QTYPES:
            continue
        text = str(item.get("text") or "").strip()
        if not text:
            continue
        options = item.get("options")
        if qtype == "truefalse":
            options = ["True", "False"]
        elif qtype == "mcq":
            options = [str(o) for o in (options or [])] or None
        else:
            options = None
        answer = item.get("answer")
        questions.append(
            Question(
                exam_id=exam_id,
                order_index=idx,
                qtype=qtype,
                text=text,
                options=options,
                correct_answer=None if answer is None else str(answer),
                explanation=(str(item.get("explanation")).strip() if item.get("explanation") else None),
                points=float(item.get("points") or 1.0),
            )
        )
    return questions


async def _save_generated_exam(
    db: AsyncSession, *, subject_id: int, title: str, raw: list[dict], source: str, payload: GenerateIn
) -> tuple[Exam, int]:
    if not await db.get(Subject, subject_id):
        raise HTTPException(status_code=404, detail="المادة غير موجودة")

    exam = Exam(
        subject_id=subject_id,
        title=title.strip()[:300],
        description=payload.description,
        source=source,
    )
    _apply_timing(exam, payload.timed, payload.duration_minutes)
    db.add(exam)
    await db.flush()

    questions = _build_questions(exam.id, raw)
    if not questions:
        await db.rollback()
        raise HTTPException(status_code=422, detail="لم يتم إنتاج أي سؤال صالح")
    db.add_all(questions)
    await db.commit()
    return exam, len(questions)


async def _generate(
    db: AsyncSession, payload: GenerateIn, source_text: str, source_kind: str, on_progress=None
) -> tuple[Exam, int]:
    counts = _validate_counts(payload.counts)
    spec = ExamSpec(
        counts=counts,
        language_note=payload.language_note,
        difficulty=payload.difficulty,
        extra_instructions=payload.extra_instructions,
    )
    try:
        raw = await generate_questions(source_text, spec, model=payload.model, on_progress=on_progress)
    except LLMError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    return await _save_generated_exam(
        db, subject_id=payload.subject_id, title=payload.title, raw=raw, source=source_kind, payload=payload
    )


def _sse(event: str, data: dict) -> str:
    return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"


def _stage(message: str) -> str:
    return _sse("progress", {"stage": "working", "done": 0, "total": 0, "message": message})


async def _resolve_source(db: AsyncSession, payload: GenerateIn) -> tuple[str, str]:
    if payload.material_id:
        material = await db.get(Material, payload.material_id)
        if not material:
            raise HTTPException(status_code=404, detail="الملف المرفق غير موجود")
        if not material.extracted_text:
            raise HTTPException(
                status_code=422,
                detail="تعذّر استخراج نص من هذا الملف. جرّب ملفًا نصيًا أو أدخل النص يدويًا.",
            )
        problem = check_text(material.extracted_text)
        if problem:
            raise HTTPException(status_code=422, detail=problem)
        return material.extracted_text, "material"
    text = (payload.source_text or "").strip()
    if not text:
        raise HTTPException(status_code=400, detail="أدخل نص الأسئلة أو اختر ملفًا من المنهج")
    return text, "text"


@router.post("/generate", dependencies=[Depends(require_admin)], status_code=status.HTTP_201_CREATED)
async def generate(payload: GenerateIn, db: AsyncSession = Depends(get_db)):
    source_text, kind = await _resolve_source(db, payload)
    exam, qcount = await _generate(db, payload, source_text, kind)
    return {"id": exam.id, "title": exam.title, "source": exam.source, "questions": qcount}


@router.post("/generate-from-upload", dependencies=[Depends(require_admin)], status_code=status.HTTP_201_CREATED)
async def generate_from_upload(
    subject_id: int = Form(...),
    title: str = Form(...),
    counts: str = Form('{"mcq":5}'),
    timed: bool = Form(False),
    duration_minutes: int | None = Form(None),
    difficulty: str = Form("medium"),
    language_note: str = Form(""),
    extra_instructions: str = Form(""),
    description: str | None = Form(None),
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
):
    try:
        parsed_counts = json.loads(counts or "{}")
    except json.JSONDecodeError as exc:
        raise HTTPException(status_code=400, detail="صيغة عدد الأسئلة غير صحيحة") from exc
    if not isinstance(parsed_counts, dict):
        raise HTTPException(status_code=400, detail="صيغة عدد الأسئلة غير صحيحة")

    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="الملف فارغ")
    if len(data) > MAX_UPLOAD_MB * 1024 * 1024:
        raise HTTPException(status_code=413, detail=f"حجم الملف أكبر من {MAX_UPLOAD_MB} ميجابايت")

    filename = file.filename or "upload.pdf"
    suffix = Path(filename).suffix.lower()
    # Extraction is CPU-heavy (~1s for a large PDF); keep the loop free.
    try:
        text, _warning = await asyncio.to_thread(extract_text, data, filename)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    payload = GenerateIn(
        subject_id=subject_id,
        title=title,
        counts=parsed_counts,
        timed=timed,
        duration_minutes=duration_minutes,
        difficulty=difficulty,
        language_note=language_note,
        extra_instructions=extra_instructions,
        description=description,
    )
    exam, qcount = await _generate(db, payload, text, "pdf" if suffix == ".pdf" else "text")
    return {"id": exam.id, "title": exam.title, "source": exam.source, "questions": qcount}


@router.post("", dependencies=[Depends(require_admin)], status_code=status.HTTP_201_CREATED)
async def create_manual(payload: ManualExamIn, db: AsyncSession = Depends(get_db)):
    if not await db.get(Subject, payload.subject_id):
        raise HTTPException(status_code=404, detail="المادة غير موجودة")
    if not payload.questions:
        raise HTTPException(status_code=400, detail="أضف سؤالًا واحدًا على الأقل")

    exam = Exam(subject_id=payload.subject_id, title=payload.title.strip()[:300], description=payload.description, source="manual")
    _apply_timing(exam, payload.timed, payload.duration_minutes)
    db.add(exam)
    await db.flush()

    raw = [
        {
            "type": q.type,
            "text": q.text,
            "options": q.options,
            "answer": q.answer,
            "explanation": q.explanation,
            "points": q.points,
        }
        for q in payload.questions
    ]
    questions = _build_questions(exam.id, raw)
    if not questions:
        await db.rollback()
        raise HTTPException(status_code=400, detail="لا توجد أسئلة صالحة")
    db.add_all(questions)
    await db.commit()
    await db.refresh(exam)
    return {"id": exam.id, "title": exam.title, "questions": len(questions)}


@router.get("")
async def list_exams(subject_id: int | None = None, db: AsyncSession = Depends(get_db)):
    stmt = select(Exam).where(Exam.is_published.is_(True)).order_by(Exam.created_at.desc())
    if subject_id is not None:
        stmt = stmt.where(Exam.subject_id == subject_id)
    exams = (await db.scalars(stmt)).all()

    counts = dict(
        (
            await db.execute(
                select(Question.exam_id, func.count(Question.id)).group_by(Question.exam_id)
            )
        ).all()
    )
    attempt_counts = dict(
        (
            await db.execute(
                select(Attempt.exam_id, func.count(Attempt.id))
                .where(Attempt.status == "submitted")
                .group_by(Attempt.exam_id)
            )
        ).all()
    )
    subject_names = dict((await db.execute(select(Subject.id, Subject.name))).all())

    return {
        "exams": [
            {
                "id": e.id,
                "title": e.title,
                "description": e.description,
                "subject_id": e.subject_id,
                "subject_name": subject_names.get(e.subject_id),
                "timed": e.timed,
                "duration_minutes": e.duration_minutes,
                "questions": counts.get(e.id, 0),
                "attempts": attempt_counts.get(e.id, 0),
                "source": e.source,
                "created_at": iso_utc(e.created_at),
            }
            for e in exams
        ]
    }


@router.get("/admin")
async def list_exams_admin(db: AsyncSession = Depends(get_db), _: str = Depends(require_admin)):
    exams = (await db.scalars(select(Exam).order_by(Exam.created_at.desc()))).all()
    counts = dict(
        (
            await db.execute(select(Question.exam_id, func.count(Question.id)).group_by(Question.exam_id))
        ).all()
    )
    subject_names = dict((await db.execute(select(Subject.id, Subject.name))).all())
    return {
        "exams": [
            {
                "id": e.id,
                "title": e.title,
                "subject_id": e.subject_id,
                "subject_name": subject_names.get(e.subject_id),
                "timed": e.timed,
                "duration_minutes": e.duration_minutes,
                "questions": counts.get(e.id, 0),
                "is_published": e.is_published,
                "source": e.source,
                "created_at": iso_utc(e.created_at),
            }
            for e in exams
        ]
    }


@router.get("/{exam_id:int}")
async def exam_detail(exam_id: int, db: AsyncSession = Depends(get_db)):
    exam = await db.get(Exam, exam_id)
    if not exam or not exam.is_published:
        raise HTTPException(status_code=404, detail="الاختبار غير موجود")
    subject = await db.get(Subject, exam.subject_id)
    questions = (
        await db.scalars(select(Question).where(Question.exam_id == exam_id).order_by(Question.order_index))
    ).all()
    return {
        "id": exam.id,
        "title": exam.title,
        "description": exam.description,
        "subject_id": exam.subject_id,
        "subject_name": subject.name if subject else None,
        "timed": exam.timed,
        "duration_minutes": exam.duration_minutes,
        "total_points": sum(q.points for q in questions),
        "questions": [_question_public(q, reveal=False) for q in questions],
    }


@router.get("/{exam_id:int}/review", dependencies=[Depends(require_admin)])
async def exam_review(exam_id: int, db: AsyncSession = Depends(get_db)):
    exam = await db.get(Exam, exam_id)
    if not exam:
        raise HTTPException(status_code=404, detail="الاختبار غير موجود")
    questions = (
        await db.scalars(select(Question).where(Question.exam_id == exam_id).order_by(Question.order_index))
    ).all()
    return {
        "id": exam.id,
        "title": exam.title,
        "timed": exam.timed,
        "duration_minutes": exam.duration_minutes,
        "is_published": exam.is_published,
        "questions": [_question_public(q, reveal=True) for q in questions],
    }


@router.patch("/{exam_id:int}", dependencies=[Depends(require_admin)])
async def update_exam(exam_id: int, payload: ExamUpdateIn, db: AsyncSession = Depends(get_db)):
    exam = await db.get(Exam, exam_id)
    if not exam:
        raise HTTPException(status_code=404, detail="الاختبار غير موجود")
    if payload.title is not None:
        exam.title = payload.title.strip()[:300]
    if payload.description is not None:
        exam.description = payload.description
    if payload.timed is not None or payload.duration_minutes is not None:
        timed = exam.timed if payload.timed is None else payload.timed
        duration = exam.duration_minutes if payload.duration_minutes is None else payload.duration_minutes
        _apply_timing(exam, timed, duration)
    if payload.is_published is not None:
        exam.is_published = payload.is_published
    await db.commit()
    return {"id": exam.id, "title": exam.title, "is_published": exam.is_published}


@router.delete("/{exam_id:int}", dependencies=[Depends(require_admin)])
async def delete_exam(exam_id: int, db: AsyncSession = Depends(get_db)):
    exam = await db.get(Exam, exam_id)
    if not exam:
        raise HTTPException(status_code=404, detail="الاختبار غير موجود")
    await db.delete(exam)
    await db.commit()
    return {"ok": True}


def _stream_generate(payload: GenerateIn, source_text: str, source_kind: str):
    """Yield SSE progress frames while generating, then the saved exam.

    The DB session is created inside the generator because the request-scoped
    dependency is torn down before the response body is streamed.
    """

    async def _events():
        from ..db import SessionLocal

        try:
            yield _stage("جارٍ تحليل المصدر وتقسيمه…")
            async with SessionLocal() as db:
                queue: asyncio.Queue = asyncio.Queue()

                async def on_progress(done: int, total: int) -> None:
                    await queue.put((done, total))

                task = asyncio.create_task(
                    _generate(db, payload, source_text, source_kind, on_progress=on_progress)
                )

                while not task.done() or not queue.empty():
                    try:
                        done, total = await asyncio.wait_for(queue.get(), timeout=1.0)
                    except asyncio.TimeoutError:
                        if task.done() and queue.empty():
                            break
                        yield _sse("progress", {"stage": "working", "done": 0, "total": 0})
                        continue
                    if done == 0:
                        message = (
                            f"جارٍ توليد الأسئلة من {total} أجزاء…"
                            if total > 1
                            else "جارٍ توليد الأسئلة…"
                        )
                    else:
                        message = (
                            f"اكتمل الجزء {done} من {total}…"
                            if total > 1
                            else "جارٍ توليد الأسئلة…"
                        )
                    yield _sse("progress", {"stage": "working", "done": done, "total": total, "message": message})

                try:
                    exam, qcount = await task
                except HTTPException as exc:
                    yield _sse("error", {"detail": exc.detail})
                    return
                except LLMError as exc:
                    yield _sse("error", {"detail": str(exc)})
                    return
                except Exception as exc:  # noqa: BLE001 - surface a usable message
                    log.exception("Streaming generation failed")
                    yield _sse("error", {"detail": f"حدث خطأ غير متوقع: {exc}"})
                    return

            yield _sse(
                "done",
                {"id": exam.id, "title": exam.title, "source": exam.source, "questions": qcount},
            )
        except asyncio.CancelledError:
            raise

    return StreamingResponse(
        _events(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@router.post("/generate-stream", dependencies=[Depends(require_admin)])
async def generate_stream(payload: GenerateIn, db: AsyncSession = Depends(get_db)):
    source_text, kind = await _resolve_source(db, payload)
    _validate_counts(payload.counts)
    return _stream_generate(payload, source_text, kind)


@router.post("/generate-from-upload-stream", dependencies=[Depends(require_admin)])
async def generate_from_upload_stream(
    subject_id: int = Form(...),
    title: str = Form(...),
    counts: str = Form('{"mcq":5}'),
    timed: bool = Form(False),
    duration_minutes: int | None = Form(None),
    difficulty: str = Form("medium"),
    language_note: str = Form(""),
    extra_instructions: str = Form(""),
    description: str | None = Form(None),
    file: UploadFile = File(...),
):
    try:
        parsed_counts = json.loads(counts or "{}")
    except json.JSONDecodeError as exc:
        raise HTTPException(status_code=400, detail="صيغة عدد الأسئلة غير صحيحة") from exc
    if not isinstance(parsed_counts, dict):
        raise HTTPException(status_code=400, detail="صيغة عدد الأسئلة غير صحيحة")

    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="الملف فارغ")
    if len(data) > MAX_UPLOAD_MB * 1024 * 1024:
        raise HTTPException(status_code=413, detail=f"حجم الملف أكبر من {MAX_UPLOAD_MB} ميجابايت")

    filename = file.filename or "upload.pdf"
    suffix = Path(filename).suffix.lower()
    # Extraction is CPU-heavy (~1s for a large PDF); keep the loop free.
    try:
        text, _warning = await asyncio.to_thread(extract_text, data, filename)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    payload = GenerateIn(
        subject_id=subject_id,
        title=title,
        counts=parsed_counts,
        timed=timed,
        duration_minutes=duration_minutes,
        difficulty=difficulty,
        language_note=language_note,
        extra_instructions=extra_instructions,
        description=description,
    )
    _validate_counts(payload.counts)
    return _stream_generate(payload, text, "pdf" if suffix == ".pdf" else "text")
