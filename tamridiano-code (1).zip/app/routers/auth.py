"""Student sign-in by emailed one-time code.

Two endpoints: request a code, then exchange it for the same signed session
cookie the Google flow issues. Everything downstream (results, library, exam
attempts) therefore works identically whichever method was used.
"""

import logging

from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from pydantic import BaseModel, Field

from ..config import (
    OTP_TTL_MINUTES,
    STUDENT_SIGNUP_ENABLED,
    USER_COOKIE,
    USER_SESSION_TTL_HOURS,
)
from ..db import get_db
from ..mailer import MailError, email_ready, provider_is_live, send_login_code
from ..otp import OtpError, issue_code, normalise_email, verify_code
from ..security import create_user_token, is_admin_email, optional_user
from ..students import (
    StudentError,
    authenticate as authenticate_student,
    register as register_student,
)

log = logging.getLogger("tamridiano.auth_router")

router = APIRouter(prefix="/api/auth", tags=["auth"])


def _start_student_session(response: Response, student) -> dict:
    """Issue the student cookie and return the profile the front-end shows."""
    response.set_cookie(
        USER_COOKIE,
        create_user_token(
            email="",
            name=student.name,
            picture=None,
            admin=False,
            student_number=student.student_number,
            student_account_id=student.id,
        ),
        httponly=True,
        samesite="lax",
        max_age=USER_SESSION_TTL_HOURS * 3600,
        path="/",
    )
    return {
        "id": student.id,
        "name": student.name,
        "student_number": student.student_number,
        "admin": False,
    }


class RegisterIn(BaseModel):
    name: str = Field(min_length=2, max_length=160)
    student_number: str = Field(min_length=1, max_length=80)
    password: str = Field(min_length=1, max_length=200)


class LoginIn(BaseModel):
    student_number: str = Field(min_length=1, max_length=80)
    password: str = Field(min_length=1, max_length=200)


class EmailIn(BaseModel):
    email: str = Field(min_length=3, max_length=320)


class CodeIn(BaseModel):
    email: str = Field(min_length=3, max_length=320)
    code: str = Field(min_length=1, max_length=12)


def _client_ip(request: Request) -> str | None:
    """Best-effort client address, honouring the proxy header a deployment sets."""
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()[:64] or None
    real = request.headers.get("x-real-ip")
    if real:
        return real.strip()[:64] or None
    return request.client.host if request.client else None


@router.get("/methods")
async def methods():
    """Which sign-in methods the gate should offer."""
    return {
        "student_accounts": True,
        "signup_enabled": STUDENT_SIGNUP_ENABLED,
        "email_ready": email_ready(),
        # True only when codes are really delivered; the UI says "development
        # mode" otherwise so a misconfigured server is obvious rather than silent.
        "email_live": provider_is_live(),
        "otp_ttl_minutes": OTP_TTL_MINUTES,
    }


@router.post("/register", status_code=status.HTTP_201_CREATED)
async def register(payload: RegisterIn, response: Response, db=Depends(get_db)):
    """Create a student account and sign it in straight away."""
    if not STUDENT_SIGNUP_ENABLED:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="إنشاء الحسابات متوقف حاليًا. تواصل مع المشرف.",
        )
    try:
        student = await register_student(db, payload.name, payload.student_number, payload.password)
    except StudentError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)) from exc
    return {"ok": True, "user": _start_student_session(response, student)}


@router.post("/login")
async def login(payload: LoginIn, response: Response, db=Depends(get_db)):
    """Sign in with a student number and password."""
    try:
        student = await authenticate_student(db, payload.student_number, payload.password)
    except StudentError as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=str(exc)) from exc
    return {"ok": True, "user": _start_student_session(response, student)}


@router.get("/me")
async def me(user: dict | None = Depends(optional_user)):
    """The signed-in student, used to restore the session on page load."""
    return {"user": user}


@router.post("/request-code")
async def request_code(payload: EmailIn, request: Request, db=Depends(get_db)):
    try:
        email = normalise_email(payload.email)
    except OtpError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)) from exc

    if not email_ready():
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="تسجيل الدخول بالبريد غير مُهيّأ على الخادم بعد.",
        )

    ip = _client_ip(request)
    try:
        code = await issue_code(db, email, ip)
    except OtpError as exc:
        raise HTTPException(status_code=status.HTTP_429_TOO_MANY_REQUESTS, detail=str(exc)) from exc

    try:
        await send_login_code(email, code, OTP_TTL_MINUTES)
    except MailError as exc:
        # A provider failure is ours, not the student's; surface it plainly.
        raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=str(exc)) from exc

    return {
        "ok": True,
        "email": email,
        "ttl_minutes": OTP_TTL_MINUTES,
        "delivered": provider_is_live(),
    }


@router.post("/verify-code")
async def verify(payload: CodeIn, response: Response, db=Depends(get_db)):
    try:
        email = normalise_email(payload.email)
    except OtpError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)) from exc

    try:
        await verify_code(db, email, payload.code)
    except OtpError as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=str(exc)) from exc

    name = email.split("@")[0]
    admin = is_admin_email(email)
    response.set_cookie(
        USER_COOKIE,
        create_user_token(email, name, None, admin),
        httponly=True,
        samesite="lax",
        max_age=USER_SESSION_TTL_HOURS * 3600,
        path="/",
    )
    return {"ok": True, "email": email, "name": name, "admin": admin}
