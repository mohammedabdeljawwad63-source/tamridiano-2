from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from ..db import get_db
from ..models import Exam, Material, Section, Subject, iso_utc
from ..security import require_admin

router = APIRouter(prefix="/api", tags=["catalogue"])


class SectionIn(BaseModel):
    name: str = Field(min_length=1, max_length=160)
    description: str | None = None
    order_index: int | None = None
    icon: str | None = None
    is_active: bool | None = None


class ReorderIn(BaseModel):
    ids: list[int] = Field(default_factory=list)


class SubjectIn(BaseModel):
    section_id: int
    name: str = Field(min_length=1, max_length=160)
    description: str | None = None


async def _subject_payload(db: AsyncSession, subject: Subject) -> dict:
    material_count = await db.scalar(
        select(func.count(Material.id)).where(Material.subject_id == subject.id)
    )
    exam_count = await db.scalar(
        select(func.count(Exam.id)).where(Exam.subject_id == subject.id, Exam.is_published.is_(True))
    )
    return {
        "id": subject.id,
        "section_id": subject.section_id,
        "name": subject.name,
        "description": subject.description,
        "materials": material_count or 0,
        "exams": exam_count or 0,
    }


def _section_order():
    """Years sort by explicit order, then name, so admin-added ones land predictably."""
    return (Section.order_index, Section.name)


@router.get("/catalogue")
async def catalogue(db: AsyncSession = Depends(get_db)):
    """Public tree of academic years -> subjects with counts."""
    sections = (await db.scalars(select(Section).order_by(*_section_order()))).all()
    subjects = (await db.scalars(select(Subject).order_by(Subject.name))).all()

    exam_rows = (
        await db.execute(
            select(Exam.subject_id, func.count(Exam.id))
            .where(Exam.is_published.is_(True))
            .group_by(Exam.subject_id)
        )
    ).all()
    material_rows = (
        await db.execute(
            select(func.count(Material.id), Material.subject_id).group_by(Material.subject_id)
        )
    ).all()
    exam_map = dict(exam_rows)
    material_map = dict(material_rows)

    by_section: dict[int, list[dict]] = {}
    for s in subjects:
        by_section.setdefault(s.section_id, []).append(
            {
                "id": s.id,
                "section_id": s.section_id,
                "name": s.name,
                "description": s.description,
                "exams": exam_map.get(s.id, 0),
                "materials": material_map.get(s.id, 0),
            }
        )

    return {
        "sections": [
            {
                "id": sec.id,
                "name": sec.name,
                "description": sec.description,
                "order_index": sec.order_index,
                "icon": sec.icon,
                "is_active": sec.is_active,
                "subjects": by_section.get(sec.id, []),
            }
            for sec in sections
        ]
    }


@router.get("/library")
async def library(db: AsyncSession = Depends(get_db)):
    """Public listing of curriculum files grouped by section and subject.

    Only metadata is exposed — never the extracted text or the stored path.
    """
    sections = (await db.scalars(select(Section).order_by(*_section_order()))).all()
    subjects = (await db.scalars(select(Subject).order_by(Subject.name))).all()
    materials = (
        await db.scalars(select(Material).order_by(Material.created_at.desc()))
    ).all()

    by_subject: dict[int, list[dict]] = {}
    for m in materials:
        by_subject.setdefault(m.subject_id, []).append(
            {
                "id": m.id,
                "title": m.title,
                "filename": m.filename,
                "kind": m.kind,
                "size_bytes": m.size_bytes,
                "text_ready": bool(m.extracted_text),
                "created_at": iso_utc(m.created_at),
            }
        )

    subject_rows = {s.id: s for s in subjects}
    return {
        "sections": [
            {
                "id": sec.id,
                "name": sec.name,
                "subjects": [
                    {
                        "id": s.id,
                        "name": s.name,
                        "materials": by_subject.get(s.id, []),
                    }
                    for s in subjects
                    if s.section_id == sec.id
                ],
            }
            for sec in sections
        ],
        "subject_names": {sid: s.name for sid, s in subject_rows.items()},
    }


@router.post("/sections", dependencies=[Depends(require_admin)], status_code=status.HTTP_201_CREATED)
async def create_section(payload: SectionIn, db: AsyncSession = Depends(get_db)):
    name = payload.name.strip()
    order_index = payload.order_index
    if order_index is None:
        # New years go to the end so the existing order stays stable.
        highest = await db.scalar(select(func.max(Section.order_index)))
        order_index = (highest or 0) + 1
    section = Section(
        name=name,
        description=payload.description,
        order_index=order_index,
        icon=payload.icon,
        is_active=True if payload.is_active is None else payload.is_active,
    )
    db.add(section)
    try:
        await db.commit()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(status_code=409, detail="يوجد قسم بنفس الاسم بالفعل")
    await db.refresh(section)
    return _section_payload(section, [])


def _section_payload(section: Section, subjects: list[dict]) -> dict:
    return {
        "id": section.id,
        "name": section.name,
        "description": section.description,
        "order_index": section.order_index,
        "icon": section.icon,
        "is_active": section.is_active,
        "subjects": subjects,
    }


@router.patch("/sections/{section_id}", dependencies=[Depends(require_admin)])
async def update_section(section_id: int, payload: SectionIn, db: AsyncSession = Depends(get_db)):
    section = await db.get(Section, section_id)
    if not section:
        raise HTTPException(status_code=404, detail="القسم غير موجود")
    section.name = payload.name.strip()
    section.description = payload.description
    if payload.order_index is not None:
        section.order_index = payload.order_index
    if payload.icon is not None:
        section.icon = payload.icon
    if payload.is_active is not None:
        section.is_active = payload.is_active
    try:
        await db.commit()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(status_code=409, detail="يوجد قسم بنفس الاسم بالفعل")
    await db.refresh(section)
    return _section_payload(section, [])


@router.post("/sections/reorder", dependencies=[Depends(require_admin)])
async def reorder_sections(payload: ReorderIn, db: AsyncSession = Depends(get_db)):
    """Persist a new year order. Ids not listed keep their current position."""
    for index, section_id in enumerate(payload.ids):
        section = await db.get(Section, section_id)
        if section:
            section.order_index = index
    await db.commit()
    return {"ok": True}


@router.delete("/sections/{section_id}", dependencies=[Depends(require_admin)])
async def delete_section(section_id: int, db: AsyncSession = Depends(get_db)):
    section = await db.get(Section, section_id)
    if not section:
        raise HTTPException(status_code=404, detail="القسم غير موجود")
    await db.delete(section)
    await db.commit()
    return {"ok": True}


@router.get("/sections/{section_id}/subjects")
async def list_subjects(section_id: int, db: AsyncSession = Depends(get_db)):
    subjects = (
        await db.scalars(select(Subject).where(Subject.section_id == section_id).order_by(Subject.name))
    ).all()
    return {"subjects": [await _subject_payload(db, s) for s in subjects]}


@router.post("/subjects", dependencies=[Depends(require_admin)], status_code=status.HTTP_201_CREATED)
async def create_subject(payload: SubjectIn, db: AsyncSession = Depends(get_db)):
    if not await db.get(Section, payload.section_id):
        raise HTTPException(status_code=404, detail="القسم غير موجود")
    subject = Subject(section_id=payload.section_id, name=payload.name.strip(), description=payload.description)
    db.add(subject)
    try:
        await db.commit()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(status_code=409, detail="توجد مادة بنفس الاسم داخل هذا القسم")
    await db.refresh(subject)
    return await _subject_payload(db, subject)


@router.patch("/subjects/{subject_id}", dependencies=[Depends(require_admin)])
async def update_subject(subject_id: int, payload: SubjectIn, db: AsyncSession = Depends(get_db)):
    subject = await db.get(Subject, subject_id)
    if not subject:
        raise HTTPException(status_code=404, detail="المادة غير موجودة")
    subject.name = payload.name.strip()
    subject.description = payload.description
    subject.section_id = payload.section_id
    try:
        await db.commit()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(status_code=409, detail="توجد مادة بنفس الاسم داخل هذا القسم")
    return await _subject_payload(db, subject)


@router.delete("/subjects/{subject_id}", dependencies=[Depends(require_admin)])
async def delete_subject(subject_id: int, db: AsyncSession = Depends(get_db)):
    subject = await db.get(Subject, subject_id)
    if not subject:
        raise HTTPException(status_code=404, detail="المادة غير موجودة")
    await db.delete(subject)
    await db.commit()
    return {"ok": True}


@router.get("/subjects/{subject_id}")
async def subject_detail(subject_id: int, db: AsyncSession = Depends(get_db)):
    subject = await db.get(Subject, subject_id)
    if not subject:
        raise HTTPException(status_code=404, detail="المادة غير موجودة")
    section = await db.get(Section, subject.section_id)
    return {
        **(await _subject_payload(db, subject)),
        "section_name": section.name if section else None,
    }
