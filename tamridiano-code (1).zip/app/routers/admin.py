from fastapi import APIRouter, Cookie, Depends, HTTPException, Response, status
from pydantic import BaseModel

from ..config import (
    ADMIN_PASSCODE,
    ALLOWED_EMAIL_DOMAINS,
    GOOGLE_ALLOWED_DOMAIN,
    GOOGLE_CLIENT_ID,
    REQUIRE_GOOGLE_LOGIN,
    SESSION_TTL_HOURS,
    STUDENT_SIGNUP_ENABLED,
    USER_SESSION_TTL_HOURS,
)
from ..mailer import email_ready, provider_is_live
from ..security import (
    ADMIN_COOKIE,
    USER_COOKIE,
    AuthError,
    check_passcode,
    create_admin_token,
    create_user_token,
    is_admin_email,
    optional_user,
    require_admin,
    verify_admin_token,
    verify_google_token,
)

router = APIRouter(prefix="/api/admin", tags=["admin"])


class PasscodeIn(BaseModel):
    passcode: str


class GoogleIn(BaseModel):
    credential: str


@router.post("/login")
async def login(payload: PasscodeIn, response: Response):
    if not check_passcode(payload.passcode):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="كود الأمان غير صحيح")
    response.set_cookie(
        ADMIN_COOKIE,
        create_admin_token(),
        httponly=True,
        samesite="lax",
        max_age=SESSION_TTL_HOURS * 3600,
        path="/",
    )
    return {"ok": True}


@router.post("/google")
async def google_login(payload: GoogleIn, response: Response):
    """Exchange a Google ID token for a signed session cookie."""
    try:
        claims = verify_google_token(payload.credential)
    except AuthError as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=str(exc)) from exc

    email = claims["email"].lower()
    name = claims.get("name") or email.split("@")[0]
    picture = claims.get("picture")
    admin = is_admin_email(email)

    response.set_cookie(
        USER_COOKIE,
        create_user_token(email, name, picture, admin),
        httponly=True,
        samesite="lax",
        max_age=USER_SESSION_TTL_HOURS * 3600,
        path="/",
    )
    return {"ok": True, "email": email, "name": name, "picture": picture, "admin": admin}


@router.post("/logout")
async def logout(response: Response):
    """Sign the user out of both the Google session and the passcode session."""
    response.delete_cookie(USER_COOKIE, path="/")
    response.delete_cookie(ADMIN_COOKIE, path="/")
    return {"ok": True}


@router.get("/session")
async def session(
    tmr_admin: str | None = Cookie(default=None),
    user: dict | None = Depends(optional_user),
):
    passcode_admin = verify_admin_token(tmr_admin)
    return {
        "authenticated": passcode_admin or bool(user and user.get("admin")),
        "passcode_configured": bool(ADMIN_PASSCODE),
        "passcode_admin": passcode_admin,
        "user": user,
    }


@router.get("/me")
async def me(user: dict | None = Depends(optional_user)):
    return {"user": user}


@router.get("/config")
async def public_config():
    """Everything the front-end needs to render the sign-in gate."""
    return {
        "google_client_id": GOOGLE_CLIENT_ID or None,
        "google_ready": bool(GOOGLE_CLIENT_ID),
        "require_google": REQUIRE_GOOGLE_LOGIN,
        "allowed_domain": GOOGLE_ALLOWED_DOMAIN or None,
        "passcode_enabled": bool(ADMIN_PASSCODE),
        "student_signup": STUDENT_SIGNUP_ENABLED,
        "email_ready": email_ready(),
        "email_live": provider_is_live(),
        "email_allowed_domains": sorted(ALLOWED_EMAIL_DOMAINS),
    }


@router.get("/verify")
async def verify(_: str = Depends(require_admin)):
    return {"ok": True}
