import asyncio
import json
import logging
import re
from dataclasses import dataclass, field

from .config import LLM_MODEL, LLM_MODEL_HEAVY
from .llm import LLMError, chat, extract_json

log = logging.getLogger("tamridiano.generator")

VALID_TYPES = ("mcq", "truefalse", "essay", "short")
TYPE_LABELS = {
    "mcq": "multiple choice (single correct option)",
    "truefalse": "true/false",
    "essay": "long written essay",
    "short": "short written answer",
}

CHUNK_CHARS = 14_000


@dataclass
class ExamSpec:
    counts: dict[str, int] = field(default_factory=lambda: {"mcq": 5})
    language_note: str = ""
    difficulty: str = "medium"
    extra_instructions: str = ""

    @property
    def total(self) -> int:
        return sum(max(0, v) for v in self.counts.values())

    def normalized(self) -> dict[str, int]:
        return {k: max(0, int(v)) for k, v in self.counts.items() if k in VALID_TYPES and int(v) > 0}


SYSTEM_PROMPT = """You are an expert exam author for school and university assessments.

Hard rules:
1. The question stem, every answer option, and the model answer MUST be written in ENGLISH.
2. The "explanation" field MUST be written in ARABIC (Modern Standard Arabic). It explains why the
   correct answer is correct and why the distractors are wrong. Keep it 1-4 sentences, clear and simple.
3. Only use the supplied source material. Never invent facts that contradict it.
4. For "mcq": give 4 plausible options, exactly one correct. "answer" must be the EXACT text of the
   correct option, copied character for character from "options".
5. For "truefalse": "options" must be exactly ["True","False"] and "answer" exactly "True" or "False".
6. For "essay" and "short": "options" must be null and "answer" is a concise model answer in English.
7. Never repeat a question. Do not number the question text.
8. "points" is an integer difficulty weight: 1 for easy recall, 2 for application, 3 for analysis.

Return ONLY a JSON object shaped exactly like this:
{"questions":[{"type":"mcq","text":"...","options":["...","...","...","..."],"answer":"...","explanation":"...","points":1}]}
"""


def _counts_line(counts: dict[str, int]) -> str:
    parts = [f"{n} x {TYPE_LABELS[t]}" for t, n in counts.items() if n > 0]
    return ", ".join(parts) if parts else "5 x multiple choice"


def _build_user_prompt(source: str, counts: dict[str, int], spec: ExamSpec, part: str | None) -> str:
    lines = [
        f"Produce exactly these questions: {_counts_line(counts)}.",
        f"Overall difficulty: {spec.difficulty}.",
    ]
    if spec.language_note:
        lines.append(f"Audience/context: {spec.language_note}")
    if spec.extra_instructions:
        lines.append(f"Extra requirements: {spec.extra_instructions}")
    if part:
        lines.append(f"This is section {part} of the source material; cover this section only.")
    lines.append("")
    lines.append("SOURCE MATERIAL:")
    lines.append('"""')
    lines.append(source)
    lines.append('"""')
    return "\n".join(lines)


def _chunk(text: str, size: int = CHUNK_CHARS) -> list[str]:
    text = text.strip()
    if len(text) <= size:
        return [text]
    paragraphs = re.split(r"\n\s*\n", text)
    chunks: list[str] = []
    current = ""
    for para in paragraphs:
        if len(current) + len(para) + 2 > size and current:
            chunks.append(current.strip())
            current = ""
        if len(para) > size:
            for i in range(0, len(para), size):
                chunks.append(para[i : i + size])
            continue
        current += para + "\n\n"
    if current.strip():
        chunks.append(current.strip())
    return chunks or [text[:size]]


def _distribute(counts: dict[str, int], parts: int) -> list[dict[str, int]]:
    """Spread requested question counts across source chunks."""
    if parts <= 1:
        return [counts]
    per_part: list[dict[str, int]] = [dict.fromkeys(counts, 0) for _ in range(parts)]
    for qtype, total in counts.items():
        base, extra = divmod(total, parts)
        for i in range(parts):
            per_part[i][qtype] = base + (1 if i < extra else 0)
    return per_part


def _normalize_question(item: dict) -> dict | None:
    if not isinstance(item, dict):
        return None
    qtype = str(item.get("type", "")).strip().lower()
    aliases = {
        "multiple_choice": "mcq", "multiple-choice": "mcq", "choice": "mcq", "mcq": "mcq",
        "true_false": "truefalse", "true-false": "truefalse", "true/false": "truefalse",
        "tf": "truefalse", "boolean": "truefalse", "truefalse": "truefalse",
        "essay": "essay", "long": "essay", "long_answer": "essay", "descriptive": "essay",
        "short": "short", "short_answer": "short", "brief": "short",
    }
    qtype = aliases.get(qtype, qtype)
    if qtype not in VALID_TYPES:
        return None

    text = str(item.get("text") or item.get("question") or "").strip()
    if not text:
        return None

    explanation = str(item.get("explanation") or item.get("explain") or "").strip() or None
    answer = item.get("answer", item.get("correct_answer", item.get("correct")))
    options = item.get("options")

    try:
        points = float(item.get("points") or 1)
    except (TypeError, ValueError):
        points = 1.0

    if qtype == "truefalse":
        options = ["True", "False"]
        if isinstance(answer, bool):
            answer = "True" if answer else "False"
        elif isinstance(answer, int):
            answer = "True" if answer else "False"
        else:
            token = str(answer or "").strip().lower()
            if token in {"true", "t", "yes", "1", "correct", "صحيح"}:
                answer = "True"
            elif token in {"false", "f", "no", "0", "incorrect", "خطأ"}:
                answer = "False"
            else:
                return None
    elif qtype == "mcq":
        if not isinstance(options, list) or len(options) < 2:
            return None
        options = [str(o).strip() for o in options if str(o).strip()]
        if len(options) < 2:
            return None
        answer_str = str(answer).strip()
        # Model may return an index, a letter, or the option text.
        if answer_str.isdigit() and 0 <= int(answer_str) < len(options):
            answer_str = options[int(answer_str)]
        elif len(answer_str) == 1 and answer_str.upper() in "ABCDEFGH" and answer_str.lower() not in options:
            idx = ord(answer_str.upper()) - 65
            if idx < len(options):
                answer_str = options[idx]
        match = next((o for o in options if o.lower() == answer_str.lower()), None)
        if match is None:
            match = next((o for o in options if answer_str.lower() and answer_str.lower() in o.lower()), None)
        if match is None:
            return None
        answer = match
    else:  # essay / short
        options = None
        answer = str(answer or "").strip() or None

    return {
        "type": qtype,
        "text": text,
        "options": options,
        "answer": None if answer is None else str(answer),
        "explanation": explanation,
        "points": points,
    }


def _dedupe(questions: list[dict]) -> list[dict]:
    seen: set[str] = set()
    out: list[dict] = []
    for q in questions:
        key = re.sub(r"[^a-z0-9\u0600-\u06ff]+", "", q["text"].lower())[:120]
        if key in seen:
            continue
        seen.add(key)
        out.append(q)
    return out


async def _questions_for_chunk(
    chunk_text: str, part_counts: dict[str, int], spec: ExamSpec, part: str | None, model: str, idx: int
) -> list[dict]:
    prompt = _build_user_prompt(chunk_text, part_counts, spec, part)
    messages = [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": prompt}]
    raw = await chat(messages, model=model, json_mode=True)
    try:
        data = extract_json(raw)
    except LLMError:
        log.warning("Chunk %s returned unparsable JSON; retrying once", idx)
        raw = await chat(messages, model=model, json_mode=True)
        data = extract_json(raw)
    items = data.get("questions") if isinstance(data, dict) else data
    if not isinstance(items, list):
        raise LLMError("AI response did not contain a questions list.")
    return [n for n in (_normalize_question(i) for i in items) if n]


async def generate_questions(
    source: str,
    spec: ExamSpec,
    *,
    model: str | None = None,
    on_progress=None,
) -> list[dict]:
    """Generate questions from `source`, running source chunks concurrently.

    `on_progress(done, total)` is awaited after each chunk settles so callers can
    report real progress instead of showing a blind spinner.
    """
    counts = spec.normalized()
    if not counts:
        raise LLMError("Select at least one question type with a count greater than zero.")
    if not source.strip():
        raise LLMError("No source material was provided.")

    chunks = _chunk(source)
    plan = _distribute(counts, len(chunks))
    chosen_model = model or LLM_MODEL

    # Chunks are independent, so run them together: a 6-chunk PDF otherwise takes
    # six sequential round-trips, which is slow enough that admins assume it hung.
    jobs = []
    for idx, (chunk_text, part_counts) in enumerate(zip(chunks, plan), start=1):
        if not any(part_counts.values()):
            continue
        part = f"{idx}/{len(chunks)}" if len(chunks) > 1 else None
        jobs.append(_questions_for_chunk(chunk_text, part_counts, spec, part, chosen_model, idx))

    total = len(jobs)
    done = 0
    if on_progress:
        await on_progress(0, total)

    async def _run(idx: int, coro):
        nonlocal done
        try:
            value = await coro
        except BaseException as exc:  # noqa: BLE001 - recorded and reported below
            value = exc
        done += 1
        if on_progress:
            await on_progress(done, total)
        return idx, value

    # Results are re-ordered by index so question order still follows the source,
    # even though chunks finish out of order.
    settled = await asyncio.gather(*(_run(i, c) for i, c in enumerate(jobs)))
    ordered: list = [None] * total
    for idx, value in settled:
        ordered[idx] = value

    collected: list[dict] = []
    failures: list[str] = []
    for result in ordered:
        if isinstance(result, BaseException):
            log.warning("Chunk failed: %s", result)
            failures.append(str(result))
            continue
        collected.extend(result)

    if not collected:
        detail = failures[0] if failures else "unknown error"
        raise LLMError(f"The AI could not produce valid questions from this material. ({detail})")
    if failures:
        log.warning("%s of %s chunks failed; returning partial exam", len(failures), len(results))

    collected = _dedupe(collected)
    if not collected:
        raise LLMError("The AI could not produce valid questions from this material. Try adding more text.")
    return collected


TUTOR_SYSTEM = """You are a patient tutor helping an Arabic-speaking student.

Write ONLY in Arabic (Modern Standard Arabic), clear and simple, like a good teacher.
You receive: the exam question, the options, the correct answer, and the student's answer.
Explain in this order, using short paragraphs:
1. لماذا إجابته خطأ (أو صحيحة).
2. الشرح الصحيح للمفهوم خطوة بخطوة.
3. القاعدة أو المعلومة التي يجب أن يتذكرها.
Keep technical terms in English between brackets when helpful. Be encouraging, never condescending.
Do not use markdown headings; use plain paragraphs and short bullet lines starting with "-"."""


async def explain_mistake(
    *,
    question_text: str,
    options: list | None,
    correct_answer: str | None,
    student_answer: str | None,
    base_explanation: str | None,
    model: str | None = None,
) -> str:
    opts = "\n".join(f"- {o}" for o in options) if options else "(no options)"
    user = (
        f"Question: {question_text}\n"
        f"Options:\n{opts}\n"
        f"Correct answer: {correct_answer or '(open question)'}\n"
        f"Student answer: {student_answer or '(left blank)'}\n"
        f"Author explanation: {base_explanation or '(none)'}\n\n"
        "Explain the mistake to the student now."
    )
    return await chat(
        [{"role": "system", "content": TUTOR_SYSTEM}, {"role": "user", "content": user}],
        model=model or LLM_MODEL,
        max_tokens=2000,
    )


CHAT_SYSTEM = """You are the study assistant inside an Arabic exam platform.
Answer the student's questions about the exam material in ARABIC (Modern Standard Arabic).
Question text and options stay in English when you quote them. Be concise, friendly and accurate.
If the question is outside the study material, say so politely and offer what you can help with."""


async def student_chat(
    messages: list[dict],
    *,
    context: str | None = None,
    model: str | None = None,
) -> str:
    system = CHAT_SYSTEM
    if context:
        system += f"\n\nExam context for reference:\n{context[:6000]}"
    convo = [{"role": "system", "content": system}] + messages[-12:]
    return await chat(convo, model=model or LLM_MODEL, max_tokens=2500)


GRADE_SYSTEM = """You grade a student's written answer for an exam.

Compare the student's answer with the model answer. Judge meaning, not wording.
Return ONLY JSON: {"score": <number from 0 to 1>, "feedback": "<Arabic feedback>"}
- score is the fraction of the mark earned (0 = nothing correct, 1 = fully correct).
- feedback is 1-3 sentences in ARABIC explaining what was right and what was missing."""


async def grade_written(
    *,
    question_text: str,
    model_answer: str | None,
    student_answer: str,
    max_points: float,
    model: str | None = None,
) -> tuple[float, str]:
    user = (
        f"Question: {question_text}\n"
        f"Model answer: {model_answer or '(none supplied - judge on general correctness)'}\n"
        f"Student answer: {student_answer}\n"
        f"Mark available: {max_points}"
    )
    try:
        raw = await chat(
            [{"role": "system", "content": GRADE_SYSTEM}, {"role": "user", "content": user}],
            model=model or LLM_MODEL_HEAVY,
            json_mode=True,
            max_tokens=1500,
        )
        data = extract_json(raw)
        ratio = float(data.get("score", 0))
        ratio = min(max(ratio, 0.0), 1.0)
        feedback = str(data.get("feedback") or "").strip()
    except (LLMError, ValueError, TypeError) as exc:
        log.warning("Auto-grading failed, awarding zero: %s", exc)
        return 0.0, "لم يتمكن المصحح الآلي من تقييم الإجابة، راجع المعلم."
    return round(ratio * max_points, 2), feedback
