/* Tamridiano front-end. Single-file SPA, no build step. */
(function () {
  "use strict";

  const API = "api";
  const state = {
    route: "home",
    params: {},
    catalogue: null,
    admin: false,
    user: null,
    config: null,
    student: JSON.parse(localStorage.getItem("tmr_student") || "null"),
    attempt: null,
    timerHandle: null,
  };

  /* ---------------- helpers ---------------- */
  const $ = (sel, root) => (root || document).querySelector(sel);
  const view = () => $("#view");

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
    }[c]));
  }

  function nl2br(s) { return esc(s).replace(/\n/g, "<br>"); }

  function toast(msg, kind) {
    const host = $("#toasts");
    const el = document.createElement("div");
    el.className = "toast " + (kind || "");
    el.textContent = msg;
    host.appendChild(el);
    setTimeout(() => { el.style.opacity = "0"; el.style.transition = "opacity .3s"; }, 4200);
    setTimeout(() => el.remove(), 4700);
  }

  async function api(path, opts) {
    const options = Object.assign({ headers: {} }, opts || {});
    if (options.body && !(options.body instanceof FormData)) {
      options.headers["Content-Type"] = "application/json";
      options.body = JSON.stringify(options.body);
    }
    const res = await fetch(API + path, Object.assign({ credentials: "same-origin" }, options));
    const text = await res.text();
    let data = null;
    try { data = text ? JSON.parse(text) : null; } catch (e) { data = { detail: text }; }
    if (!res.ok) {
      let detail = (data && data.detail) || res.statusText;
      if (Array.isArray(detail)) detail = detail.map((d) => d.msg || JSON.stringify(d)).join("; ");
      else if (detail && typeof detail === "object") detail = detail.message || JSON.stringify(detail);
      const err = new Error(detail || "حدث خطأ");
      err.status = res.status;
      throw err;
    }
    return data;
  }

  const TYPE_LABEL = { mcq: "اختيار من متعدد", truefalse: "صح / خطأ", essay: "مقالي", short: "إجابة قصيرة" };
  const TYPE_SHORT = { mcq: "MCQ", truefalse: "T/F", essay: "Essay", short: "Short" };

  function fmtDate(iso) {
    if (!iso) return "—";
    const d = new Date(iso);
    if (isNaN(d)) return "—";
    return d.toLocaleString("ar-EG", { dateStyle: "medium", timeStyle: "short" });
  }

  function pctColor(p) {
    if (p >= 80) return "#17a673";
    if (p >= 60) return "#f59e0b";
    return "#e5484d";
  }

  function busy(btn, on) {
    if (!btn) return;
    if (on) {
      btn.dataset.label = btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner"></span> جارٍ العمل…';
    } else {
      btn.disabled = false;
      if (btn.dataset.label) btn.innerHTML = btn.dataset.label;
    }
  }

  function loadingBox(msg) {
    return '<div class="loading-box"><div class="spinner dark"></div><div>' + esc(msg || "جارٍ التحميل…") + "</div></div>";
  }

  function alertBox(msg, kind) {
    return '<div class="alert ' + (kind || "err") + '">' + esc(msg) + "</div>";
  }

  /* ---------------- modal ---------------- */
  function modal(title, bodyHtml, footHtml) {
    closeModal();
    const host = document.createElement("div");
    host.className = "modal-host";
    host.innerHTML =
      '<div class="modal"><div class="modal-head"><h3>' + esc(title) + "</h3></div>" +
      '<div class="modal-body">' + bodyHtml + "</div>" +
      (footHtml ? '<div class="modal-foot">' + footHtml + "</div>" : "") +
      "</div>";
    host.addEventListener("click", (e) => { if (e.target === host) closeModal(); });
    $("#modal-host").appendChild(host);
    return host;
  }
  function closeModal() { $("#modal-host").innerHTML = ""; }

  /* ---------------- 3D brand mark ---------------- */
  /* Pure-CSS 3D mark: a letter floating inside a spinning torus. The same
     markup is used small (nav) and large (hero, sign-in gate). */
  function logo3d(size) {
    return '<div class="logo3d"' + (size ? ' style="--size:' + size + '"' : "") + ">" +
      '<div class="halo"></div>' +
      '<div class="stage">' +
      '<div class="orb r1"></div><div class="orb r2"></div>' +
      '<div class="orb r3"></div><div class="orb r4"></div>' +
      '<div class="glyph">ت</div>' +
      "</div>" +
      '<div class="shadow"></div>' +
      "</div>";
  }

  function brandMark() {
    return '<div class="brand-mark">' +
      '<div class="ring"></div><div class="ring tilt"></div>' +
      '<div class="core">ت</div></div>';
  }

  /* ---------------- auth gate ---------------- */
  /* Students create an account with their name, a student number and a password,
     then sign in with the number. `state.user` is the signed-in account and is
     what results are keyed on. Email codes, Google and the admin passcode remain
     available when they are configured. */
  async function loadConfig() {
    if (state.config) return state.config;
    state.config = await api("/admin/config").catch(() => ({
      google_client_id: null, google_ready: false, require_google: false, passcode_enabled: true,
      student_signup: true,
    }));
    return state.config;
  }

  async function loadUser() {
    try {
      const data = await api("/admin/session");
      state.user = data.user || null;
      state.admin = !!data.authenticated;
      return state.user;
    } catch (e) {
      state.user = null;
      state.admin = false;
      return null;
    }
  }

  function initials(name, email) {
    const src = (name || email || "?").trim();
    return src ? src[0].toUpperCase() : "?";
  }

  function avatarHtml(user) {
    if (user && user.picture) return '<img src="' + esc(user.picture) + '" alt="">';
    return '<span class="who" style="font-weight:800">' + esc(initials(user && user.name, user && user.email)) + "</span>";
  }

  /* Which of the two student panels is showing: sign in, or create an account.
     Held in module state so a re-render (e.g. an error) does not lose the choice. */
  const gateState = { step: "login" };

  function renderGate(message) {
    const cfg = state.config || {};
    const gate = document.createElement("div");
    gate.className = "gate";
    gate.id = "gate";

    const studentBlock = '<div id="gate-student"></div>';

    const googleBlock = cfg.google_ready
      ? '<div id="gsi-slot"></div>' +
        '<div class="hint" style="color:rgba(255,255,255,.55);text-align:center;margin-top:8px">' +
        (cfg.allowed_domain ? "متاح لبريد @" + esc(cfg.allowed_domain) + " فقط" : "أي حساب جوجل") +
        "</div>"
      : "";

    gate.innerHTML =
      '<div class="gate-inner">' +
      logo3d("230px") +
      "<h1>تمريضيانو</h1>" +
      '<p class="tagline">منصة الاختبارات الإلكترونية الذكية</p>' +
      '<div class="gate-panel">' +
      "<h2>تسجيل الدخول</h2>" +
      "<p>أنشئ حسابك باسمك ورقم الطالب، ثم ادخل لحل الاختبارات ومتابعة نتائجك.</p>" +
      '<div id="gate-err">' + (message ? alertBox(message) : "") + "</div>" +
      studentBlock +
      (googleBlock ? '<div class="gate-sep">أو</div>' + googleBlock : "") +
      (cfg.passcode_enabled
        ? '<div class="gate-sep">أو ادخل بكود الأمان</div>' +
          '<div class="field"><label for="gate-pc">كود الأمان (للمشرف)</label>' +
          '<input type="password" id="gate-pc" placeholder="••••••••" autocomplete="current-password"></div>' +
          '<button class="btn ghost block" id="gate-pc-go">دخول المشرف</button>'
        : "") +
      '<p class="gate-foot">بالمتابعة أنت توافق على استخدام حسابك لعرض اختباراتك ونتائجك فقط.</p>' +
      "</div></div>";
    document.body.appendChild(gate);

    const fail = (msg) => {
      const host = $("#gate-err");
      if (host) host.innerHTML = alertBox(msg);
    };

    const pcGo = $("#gate-pc-go");
    if (pcGo) {
      const submit = async (ev) => {
        const btn = ev.currentTarget;
        busy(btn, true);
        try {
          await api("/admin/login", { method: "POST", body: { passcode: $("#gate-pc").value } });
          await enterApp();
        } catch (e) {
          busy(btn, false);
          fail(e.message);
        }
      };
      pcGo.addEventListener("click", submit);
      $("#gate-pc").addEventListener("keydown", (e) => { if (e.key === "Enter") pcGo.click(); });
    }

    renderStudentStep(fail);
    if (cfg.google_ready) mountGoogleButton(fail);
  }

  /* The student panel: sign in with a number, or create an account. */
  function renderStudentStep(fail) {
    const host = $("#gate-student");
    if (!host) return;
    const cfg = state.config || {};
    const registering = gateState.step === "register";

    if (registering && !cfg.student_signup) {
      gateState.step = "login";
    }

    const tabs =
      '<div class="gate-tabs">' +
      '<button class="' + (registering ? "" : "on") + '" id="tab-login">دخول</button>' +
      (cfg.student_signup
        ? '<button class="' + (registering ? "on" : "") + '" id="tab-register">حساب جديد</button>'
        : "") +
      "</div>";

    if (registering) {
      host.innerHTML =
        tabs +
        '<div class="field"><label for="rg-name">الاسم الكامل <span style="color:#e5484d">*</span></label>' +
        '<input type="text" id="rg-name" autocomplete="name" placeholder="اكتب اسمك كما تريده أن يظهر"></div>' +
        '<div class="field"><label for="rg-num">رقم الطالب <span style="color:#e5484d">*</span></label>' +
        '<input type="text" id="rg-num" dir="ltr" autocomplete="username" placeholder="مثال: 20240012"></div>' +
        '<div class="field"><label for="rg-pass">كلمة المرور <span style="color:#e5484d">*</span></label>' +
        '<input type="password" id="rg-pass" autocomplete="new-password" placeholder="6 أحرف على الأقل"></div>' +
        '<button class="btn block" id="rg-go">إنشاء الحساب والدخول</button>' +
        '<p class="hint">احفظ رقم الطالب وكلمة المرور — بهما تدخل وتشاهد نتائجك في أي وقت.</p>';
    } else {
      host.innerHTML =
        tabs +
        '<div class="field"><label for="lg-num">رقم الطالب</label>' +
        '<input type="text" id="lg-num" dir="ltr" autocomplete="username" placeholder="مثال: 20240012"></div>' +
        '<div class="field"><label for="lg-pass">كلمة المرور</label>' +
        '<input type="password" id="lg-pass" autocomplete="current-password" placeholder="••••••••"></div>' +
        '<button class="btn block" id="lg-go">دخول</button>';
    }

    const tabLogin = $("#tab-login");
    if (tabLogin) tabLogin.addEventListener("click", () => { gateState.step = "login"; renderStudentStep(fail); });
    const tabReg = $("#tab-register");
    if (tabReg) tabReg.addEventListener("click", () => { gateState.step = "register"; renderStudentStep(fail); });

    if (registering) {
      const go = $("#rg-go");
      const submit = async (ev) => {
        const btn = ev.currentTarget;
        const name = $("#rg-name").value.trim();
        const number = $("#rg-num").value.trim();
        const password = $("#rg-pass").value;
        if (!name || !number || !password) { fail("اكمل كل الحقول أولًا."); return; }
        busy(btn, true);
        try {
          await api("/auth/register", { method: "POST", body: { name: name, student_number: number, password: password } });
          gateState.step = "login";
          await enterApp();
        } catch (e) {
          busy(btn, false);
          fail(e.message);
        }
      };
      go.addEventListener("click", submit);
      $("#rg-pass").addEventListener("keydown", (e) => { if (e.key === "Enter") go.click(); });
      return;
    }

    const go = $("#lg-go");
    const submit = async (ev) => {
      const btn = ev.currentTarget;
      const number = $("#lg-num").value.trim();
      const password = $("#lg-pass").value;
      if (!number || !password) { fail("اكتب رقم الطالب وكلمة المرور."); return; }
      busy(btn, true);
      try {
        await api("/auth/login", { method: "POST", body: { student_number: number, password: password } });
        await enterApp();
      } catch (e) {
        busy(btn, false);
        fail(e.message);
      }
    };
    go.addEventListener("click", submit);
    $("#lg-pass").addEventListener("keydown", (e) => { if (e.key === "Enter") go.click(); });
  }

  /* Google renders its own button into the slot. The callback receives a signed
     ID token which the server verifies before issuing our session cookie. */
  function mountGoogleButton(onError) {
    const slot = $("#gsi-slot");
    if (!slot) return;
    const start = () => {
      if (!window.google || !window.google.accounts || !window.google.accounts.id) {
        slot.innerHTML = '<div class="gate-note">تعذّر تحميل زر جوجل. تحقق من الاتصال بالإنترنت.</div>';
        return;
      }
      window.google.accounts.id.initialize({
        client_id: state.config.google_client_id,
        callback: async (response) => {
          try {
            await api("/admin/google", { method: "POST", body: { credential: response.credential } });
            await enterApp();
          } catch (e) {
            onError(e.message);
          }
        },
      });
      window.google.accounts.id.renderButton(slot, {
        theme: "filled_blue", size: "large", text: "signin_with",
        shape: "pill", logo_alignment: "center", width: 320,
      });
    };
    if (window.google && window.google.accounts) { start(); return; }
    const s = document.createElement("script");
    s.src = "https://accounts.google.com/gsi/client";
    s.async = true;
    s.defer = true;
    s.onload = start;
    s.onerror = () => {
      slot.innerHTML = '<div class="gate-note">تعذّر الوصول إلى خدمات جوجل.</div>';
    };
    document.head.appendChild(s);
  }

  function removeGate() {
    const gate = $("#gate");
    if (gate) gate.remove();
  }

  /* Called after a successful sign-in: tear down the gate and load the app. */
  async function enterApp() {
    await loadUser();
    removeGate();
    renderNav();
    const r = location.hash.slice(1);
    go(r && ROUTES[r] ? r : "home");
  }

  async function requireAuth() {
    const cfg = await loadConfig();
    const user = await loadUser();
    // When Google is not configured, the passcode session is the only way in and
    // the gate would block a working app, so fall through to the passcode screen.
    if (user || state.admin) return true;
    renderGate();
    return false;
  }

  const ROUTES = {
    home: { label: "الرئيسية", render: renderHome, nav: true },
    subjects: { label: "المواد والاختبارات", render: renderSubjects, nav: true },
    results: { label: "نتائجي", render: renderResults, nav: true },
    library: { label: "مكتبة المنهج", render: renderLibrary, nav: true },
    admin: { label: "إدارة", render: renderAdmin, nav: true },
    // Not in the nav bar: reached from within an exam flow.
    exam: { label: "الاختبار", render: renderExam, nav: false },
    result: { label: "النتيجة", render: renderResult, nav: false },
  };

  function go(route, params) {
    if (state.timerHandle) { clearInterval(state.timerHandle); state.timerHandle = null; }
    state.route = route;
    state.params = params || {};
    if (location.hash.slice(1) !== route) location.hash = route;
    renderNav();
    window.scrollTo({ top: 0, behavior: "instant" });
    ROUTES[route] ? ROUTES[route].render() : renderHome();
  }

  function renderNav() {
    const nav = $("#nav");
    let html = "";
    for (const key of Object.keys(ROUTES)) {
      const r = ROUTES[key];
      if (!r.nav) continue;
      html += '<button data-route="' + key + '" class="' + (state.route === key ? "active" : "") + '">' + esc(r.label) + "</button>";
    }
    if (state.user) {
      html += '<span class="user-chip">' + avatarHtml(state.user) +
        '<span class="who">' + esc(state.user.name || state.user.email) + "</span>" +
        (state.user.admin ? '<span class="adm">مشرف</span>' : "") + "</span>" +
        '<button data-logout="1" title="خروج">خروج</button>';
    }
    nav.innerHTML = html;
    nav.querySelectorAll("button[data-route]").forEach((b) =>
      b.addEventListener("click", () => go(b.dataset.route))
    );
    const lo = nav.querySelector("button[data-logout]");
    if (lo) {
      lo.addEventListener("click", async () => {
        await api("/admin/logout", { method: "POST" }).catch(() => {});
        state.user = null;
        state.admin = false;
        state.config = null;
        state.catalogue = null;
        renderNav();
        renderGate();
      });
    }
  }

  async function loadCatalogue(force) {
    if (state.catalogue && !force) return state.catalogue;
    state.catalogue = await api("/catalogue");
    return state.catalogue;
  }

  /* ================= HOME ================= */
  async function renderHome() {
    view().innerHTML =
      '<section class="hero">' +
      "<div>" +
      "<h1>منصة تمريضيانو للاختبارات الإلكترونية</h1>" +
      "<p>حوّل أي نص أو ملف PDF إلى امتحان إلكتروني احترافي في دقائق. أسئلة اختيار من متعدد، صح وخطأ، مقالي، وإجابة قصيرة — مع تصحيح آلي ومساعد ذكاء اصطناعي يشرح لك كل سؤال أخطأت فيه بالعربية.</p>" +
      '<div class="pills"><span class="pill">توليد بالذكاء الاصطناعي</span><span class="pill">رفع ملفات PDF</span><span class="pill">امتحان بوقت أو بدون</span><span class="pill">تصحيح تلقائي</span><span class="pill">شرح بالعربية</span></div>' +
      "</div>" +
      '<div class="hero-visual">' + logo3d("215px") + "</div>" +
      "</section>" +
      '<div class="stats mb" id="home-stats">' + loadingBox("جارٍ تحميل الإحصائيات…") + "</div>" +
      '<h2 class="mb">السنوات الدراسية</h2>' +
      '<div class="year-grid" id="home-sections">' + loadingBox("جارٍ تحميل السنوات…") + "</div>";

    try {
      const cat = await loadCatalogue(true);
      const subjectCount = cat.sections.reduce((n, s) => n + s.subjects.length, 0);
      let exams = 0;
      let materials = 0;
      cat.sections.forEach((s) => s.subjects.forEach((sub) => {
        exams += sub.exams;
        materials += sub.materials;
      }));
      $("#home-stats").innerHTML =
        '<div class="stats">' +
        stat(cat.sections.length, "سنة دراسية") +
        stat(subjectCount, "مادة متاحة") +
        stat(exams, "اختبار منشور") +
        stat(materials, "ملف منهج") +
        "</div>";

      const host = $("#home-sections");
      if (!cat.sections.length) {
        host.innerHTML = '<div class="card lift"><div class="empty">لا توجد سنوات دراسية بعد. ادخل إلى <b>إدارة</b> وأنشئ سنة ثم أضف المواد والاختبارات.</div></div>';
        return;
      }
      host.innerHTML = cat.sections
        .map((s, i) => {
          const subCount = s.subjects.length;
          let ex = 0;
          let mat = 0;
          s.subjects.forEach((sub) => { ex += sub.exams; mat += sub.materials; });
          return '<div class="year-card" data-year="' + s.id + '">' +
            '<div class="badge">' + esc(String(i + 1)) + "</div>" +
            '<div class="y-name">' + esc(s.name) + "</div>" +
            (s.description ? '<div class="y-meta">' + esc(s.description) + "</div>" : "") +
            '<div class="y-counts">' +
            '<span class="tag">' + subCount + " مادة</span>" +
            '<span class="tag gray">' + ex + " اختبار</span>" +
            '<span class="tag gray">' + mat + " ملف</span>" +
            "</div></div>";
        })
        .join("");
      host.querySelectorAll("[data-year]").forEach((el) =>
        el.addEventListener("click", () => go("subjects", { sectionId: Number(el.dataset.year) }))
      );
    } catch (e) {
      $("#home-sections").innerHTML = '<div class="card">' + alertBox(e.message) + "</div>";
    }
  }

  function stat(value, label) {
    return '<div class="stat"><div class="v">' + esc(value) + '</div><div class="k">' + esc(label) + "</div></div>";
  }

  /* ================= SUBJECTS ================= */
  async function renderSubjects() {
    view().innerHTML =
      '<div class="card"><div class="card-head"><h2>المواد والاختبارات</h2><span class="spacer"></span>' +
      '<span class="muted" id="sub-count"></span></div>' +
      '<div id="year-filter" class="inline mb"></div>' +
      '<div id="subject-list">' + loadingBox() + "</div></div>";
    try {
      const cat = await loadCatalogue(true);
      const all = [];
      cat.sections.forEach((s) =>
        s.subjects.forEach((sub) => all.push(Object.assign({ section: s.name, section_id: s.id }, sub)))
      );

      // Year filter: only worth showing once there is more than one year.
      const filter = $("#year-filter");
      if (cat.sections.length > 1) {
        const active = state.params.sectionId ? Number(state.params.sectionId) : null;
        filter.innerHTML = '<span class="muted">السنة:</span>' +
          '<button class="btn ghost sm' + (active ? "" : " active-year") + '" data-year-all="1">الكل</button>' +
          cat.sections.map((s) =>
            '<button class="btn ghost sm" data-year-pick="' + s.id + '">' + esc(s.name) + "</button>"
          ).join("");
        filter.querySelectorAll("button").forEach((b) => {
          b.addEventListener("click", () => {
            const sid = b.dataset.yearAll ? null : Number(b.dataset.yearPick);
            go("subjects", sid ? { sectionId: sid } : {});
          });
        });
      }

      const visible = state.params.sectionId
        ? all.filter((s) => s.section_id === Number(state.params.sectionId))
        : all;
      $("#sub-count").textContent = visible.length + " مادة";
      const host = $("#subject-list");
      if (!visible.length) {
        host.innerHTML = '<div class="empty">لا توجد مواد بعد. أنشئها من قسم <b>إدارة</b>.</div>';
        return;
      }
      host.innerHTML =
        '<div class="list">' +
        visible
          .map(
            (sub) =>
              '<div class="list-item clickable" data-subject="' + sub.id + '"><div class="grow"><div class="title">' +
              esc(sub.name) + '</div><div class="meta">' + esc(sub.section) + " · " + sub.exams + " اختبار · " +
              sub.materials + ' ملف</div></div><span class="tag">' + sub.exams + " اختبار</span></div>"
          )
          .join("") +
        "</div>";
      host.querySelectorAll("[data-subject]").forEach((el) =>
        el.addEventListener("click", () => go("subjects", { subjectId: Number(el.dataset.subject) }))
      );
      if (state.params.subjectId) openSubject(state.params.subjectId);
    } catch (e) {
      $("#subject-list").innerHTML = alertBox(e.message);
    }
  }

  async function openSubject(subjectId) {
    view().innerHTML = loadingBox("جارٍ تحميل المادة…");
    try {
      const [subject, exams] = await Promise.all([
        api("/subjects/" + subjectId),
        api("/exams?subject_id=" + subjectId),
      ]);
      view().innerHTML =
        '<div class="card mb"><div class="card-head"><button class="btn ghost sm" id="back">← رجوع</button><h2>' +
        esc(subject.name) + '</h2><span class="spacer"></span><span class="tag gray">' +
        esc(subject.section_name || "") + "</span></div>" +
        (subject.description ? '<p class="muted">' + esc(subject.description) + "</p>" : "") +
        '<div class="inline"><span class="tag">' + exams.exams.length + ' اختبار</span><span class="tag gray">' +
        subject.materials + ' ملف في مكتبة المنهج</span></div></div>' +
        '<div class="card"><h3>الاختبارات المتاحة</h3><div id="exam-list"></div></div>';

      $("#back").addEventListener("click", () => go("subjects"));
      const host = $("#exam-list");
      if (!exams.exams.length) {
        host.innerHTML = '<div class="empty">لا توجد اختبارات منشورة في هذه المادة بعد.</div>';
        return;
      }
      host.innerHTML =
        '<div class="list">' +
        exams.exams
          .map(
            (ex) =>
              '<div class="list-item"><div class="grow"><div class="title">' + esc(ex.title) + "</div>" +
              '<div class="meta">' + ex.questions + " سؤال · " +
              (ex.timed ? "موقوت " + ex.duration_minutes + " دقيقة" : "بدون وقت") +
              " · " + ex.attempts + " محاولة</div></div>" +
              '<button class="btn sm" data-exam="' + ex.id + '">ابدأ الاختبار</button></div>'
          )
          .join("") +
        "</div>";
      host.querySelectorAll("[data-exam]").forEach((b) =>
        b.addEventListener("click", () => startExam(Number(b.dataset.exam)))
      );
    } catch (e) {
      view().innerHTML = '<div class="card">' + alertBox(e.message) + "</div>";
    }
  }

  /* ================= EXAM FLOW ================= */
  function studentForm(examId) {
    const s = state.student || {};
    const signedIn = !!state.user;
    // A signed-in student already gave their name at sign-in, so prefill it
    // rather than making them type it again on every exam.
    const nameValue = (signedIn ? (state.user.name || "") : "") || s.name || "";
    const body =
      '<div id="start-err"></div>' +
      '<div class="field"><label for="sname">اسم الطالب <span style="color:#e5484d">*</span></label>' +
      '<input type="text" id="sname" value="' + esc(nameValue) + '" placeholder="اكتب اسمك الكامل"></div>' +
      (signedIn
        ? '<p class="hint">سيُربط هذا الاختبار بحسابك <b>' + esc(state.user.name || "") +
          (state.user.student_number ? " · رقم " + esc(state.user.student_number) : "") +
          "</b> لتظهر نتيجته في «نتائجي» تلقائيًا.</p>"
        : '<div class="field"><label for="sid">رقم الطالب / المجموعة (اختياري)</label>' +
          '<input type="text" id="sid" value="' + esc(s.sid || "") + '" placeholder="مثال: 20240012"></div>' +
          '<p class="hint">يُستخدم هذا لتجميع نتائجك في صفحة «نتائجي». احفظ نفس الرقم في كل اختبار.</p>');
    modal("بيانات الطالب", body, '<button class="btn" id="go-exam">ابدأ الآن</button><button class="btn ghost" id="cancel">إلغاء</button>');

    $("#cancel").addEventListener("click", closeModal);
    $("#go-exam").addEventListener("click", async (ev) => {
      const btn = ev.currentTarget;
      const name = $("#sname").value.trim();
      const sid = ($("#sid") ? $("#sid").value.trim() : "") ||
        (state.user && state.user.student_number ? state.user.student_number : "");
      if (!name) { $("#start-err").innerHTML = alertBox("اكتب اسم الطالب أولًا"); return; }
      state.student = { name: name, sid: sid };
      localStorage.setItem("tmr_student", JSON.stringify(state.student));
      busy(btn, true);
      try {
        const attempt = await api("/attempts/start", { method: "POST", body: { exam_id: examId, student_name: name, student_id: sid || null } });
        closeModal();
        state.attempt = attempt;
        go("exam", { attemptId: attempt.attempt_id });
      } catch (e) {
        busy(btn, false);
        $("#start-err").innerHTML = alertBox(e.message);
      }
    });
  }

  async function startExam(examId) { studentForm(examId); }

  async function renderExam() {
    const attemptId = Number(state.params.attemptId || sessionStorage.getItem("tmr_attempt"));
    if (!attemptId) {
      view().innerHTML = '<div class="card">' + alertBox("لا يوجد اختبار جارٍ. ابدأ الاختبار من قائمة المواد.", "info") +
        '<button class="btn mt" onclick="App.go(\'subjects\')">العودة للمواد</button></div>';
      return;
    }
    let attempt = state.attempt && state.attempt.attempt_id === attemptId ? state.attempt : null;
    if (!attempt) {
      // Page was reloaded mid-exam: restore the attempt from the server.
      view().innerHTML = loadingBox("جارٍ استعادة الاختبار…");
      try {
        attempt = await api("/attempts/" + attemptId);
      } catch (e) {
        view().innerHTML = '<div class="card">' + alertBox(e.message) +
          '<button class="btn mt" onclick="App.go(\'subjects\')">العودة للمواد</button></div>';
        return;
      }
    }
    state.attempt = attempt;
    sessionStorage.setItem("tmr_attempt", String(attemptId));

    view().innerHTML =
      '<div class="card mb"><div class="card-head"><div><h2>' + esc(attempt.title) + "</h2>" +
      '<div class="muted">الطالب: ' + esc(attempt.student_name) + " · " + attempt.questions.length + " سؤال · " +
      attempt.max_score + " درجة</div></div><span class=\"spacer\"></span><div id=\"timer-host\"></div></div></div>" +
      '<form id="exam-form">' + attempt.questions.map(renderQuestion).join("") + "</form>" +
      '<div class="card" style="position:sticky;bottom:0;z-index:20"><div class="inline">' +
      '<button class="btn ok" id="submit-btn">تسليم الاختبار</button>' +
      '<span class="muted" id="progress"></span></div></div>';

    const form = $("#exam-form");
    form.addEventListener("change", () => { updateProgress(); saveDraft(); });
    form.addEventListener("input", () => { updateProgress(); saveDraft(); });
    restoreDraft();
    updateProgress();
    $("#submit-btn").addEventListener("click", () => submitAttempt(attemptId));

    if (attempt.expires_at) startTimer(attempt.expires_at);
  }

  function renderQuestion(q, i) {
    let body = "";
    if (q.type === "mcq" || q.type === "truefalse") {
      body =
        '<div class="opts" data-q="' + q.id + '">' +
        (q.options || [])
          .map(
            (opt, oi) =>
              '<label class="opt" data-opt><input type="radio" name="q' + q.id + '" value="' + esc(opt) + '"><span>' +
              esc(opt) + "</span></label>"
          )
          .join("") +
        "</div>";
    } else {
      body =
        '<textarea data-q="' + q.id + '" placeholder="' + (q.type === "essay" ? "اكتب إجابتك المفصلة هنا…" : "اكتب إجابتك القصيرة هنا…") + '"></textarea>';
    }
    return (
      '<div class="qcard"><div class="qhead"><div class="qnum">' + (i + 1) + '</div><span class="tag">' +
      esc(TYPE_LABEL[q.type] || q.type) + '</span><span class="tag gray">' + q.points + " درجة</span></div>" +
      '<div class="qtext">' + esc(q.text) + "</div>" + body + "</div>"
    );
  }

  function draftKey(attemptId) { return "tmr_draft_" + attemptId; }

  function saveDraft() {
    if (!state.attempt) return;
    try {
      localStorage.setItem(draftKey(state.attempt.attempt_id), JSON.stringify(collectAnswers()));
    } catch (e) { /* storage full or unavailable: drafts are a convenience only */ }
  }

  function restoreDraft() {
    if (!state.attempt) return;
    let saved;
    try {
      saved = JSON.parse(localStorage.getItem(draftKey(state.attempt.attempt_id)) || "null");
    } catch (e) { saved = null; }
    if (!Array.isArray(saved)) return;
    saved.forEach((a) => {
      if (!a || !a.response) return;
      const radio = document.querySelector('input[name="q' + a.question_id + '"][value="' + CSS.escape(a.response) + '"]');
      if (radio) { radio.checked = true; return; }
      const ta = document.querySelector('textarea[data-q="' + a.question_id + '"]');
      if (ta) ta.value = a.response;
    });
  }

  function collectAnswers() {
    const answers = [];
    state.attempt.questions.forEach((q) => {
      if (q.type === "mcq" || q.type === "truefalse") {
        const sel = document.querySelector('input[name="q' + q.id + '"]:checked');
        answers.push({ question_id: q.id, response: sel ? sel.value : null });
      } else {
        const ta = document.querySelector('textarea[data-q="' + q.id + '"]');
        answers.push({ question_id: q.id, response: ta ? ta.value : null });
      }
    });
    return answers;
  }

  function updateProgress() {
    const answers = collectAnswers();
    const done = answers.filter((a) => a.response && a.response.trim()).length;
    const el = $("#progress");
    if (el) el.textContent = "أجبت على " + done + " من " + answers.length + " سؤال";
  }

  function startTimer(expiresAt) {
    const host = $("#timer-host");
    if (!host) return;
    const end = new Date(expiresAt).getTime();
    const tick = () => {
      const left = Math.max(0, end - Date.now());
      const total = Math.floor(left / 1000);
      const h = String(Math.floor(total / 3600)).padStart(2, "0");
      const m = String(Math.floor((total % 3600) / 60)).padStart(2, "0");
      const s = String(total % 60).padStart(2, "0");
      host.innerHTML = '<div class="timer' + (left < 120000 ? " warn" : "") + '">⏱ ' + h + ":" + m + ":" + s + "</div>";
      if (left <= 0) {
        clearInterval(state.timerHandle);
        state.timerHandle = null;
        toast("انتهى وقت الاختبار، جارٍ التسليم تلقائيًا…", "err");
        submitAttempt(state.attempt.attempt_id, true);
      }
    };
    tick();
    state.timerHandle = setInterval(tick, 1000);
  }

  async function submitAttempt(attemptId, auto) {
    const answers = collectAnswers();
    const answered = answers.filter((a) => a.response && a.response.trim()).length;
    if (!auto) {
      const blank = answers.length - answered;
      if (blank > 0) {
        const ok = await confirmDialog("لديك " + blank + " سؤال بدون إجابة. هل تريد التسليم الآن؟");
        if (!ok) return;
      }
    }
    const btn = $("#submit-btn");
    busy(btn, true);
    try {
      const result = await api("/attempts/" + attemptId + "/submit", { method: "POST", body: { answers: answers } });
      if (state.timerHandle) { clearInterval(state.timerHandle); state.timerHandle = null; }
      state.lastResult = result;
      sessionStorage.removeItem("tmr_attempt");
      localStorage.removeItem(draftKey(attemptId));
      go("result", { attemptId: attemptId });
    } catch (e) {
      busy(btn, false);
      toast(e.message, "err");
    }
  }

  function confirmDialog(msg) {
    return new Promise((resolve) => {
      modal("تأكيد", "<p>" + esc(msg) + "</p>",
        '<button class="btn" id="yes">نعم، سلّم</button><button class="btn ghost" id="no">إلغاء</button>');
      $("#yes").addEventListener("click", () => { closeModal(); resolve(true); });
      $("#no").addEventListener("click", () => { closeModal(); resolve(false); });
    });
  }

  /* ================= RESULT ================= */
  async function renderResult() {
    view().innerHTML = loadingBox("جارٍ تصحيح الاختبار…");
    try {
      const r = state.lastResult && state.lastResult.attempt_id === state.params.attemptId
        ? state.lastResult
        : await api("/attempts/" + state.params.attemptId + "/result");
      state.lastResult = r;
      const pct = r.percentage || 0;
      const deg = Math.round((pct / 100) * 360);
      view().innerHTML =
        '<div class="card pad-lg mb"><div class="card-head"><div class="score-ring" style="background:conic-gradient(' +
        pctColor(pct) + " " + deg + "deg, #e6ebf5 " + deg + 'deg)"><div class="inner"><div><div class="pct" style="color:' +
        pctColor(pct) + '">' + pct + '%</div><div class="lbl">' + r.score + " / " + r.max_score + "</div></div></div></div>" +
        '<div style="flex:1;min-width:230px"><h2>' + esc(r.title) + "</h2>" +
        '<div class="muted mb">الطالب: ' + esc(r.student_name) + " · سُلّم في " + fmtDate(r.submitted_at) + "</div>" +
        '<div class="inline"><span class="tag green">' + r.correct_count + ' صحيح</span><span class="tag red">' +
        r.wrong_count + ' خطأ</span><span class="tag gray">' + r.total_questions + " سؤال</span>" +
        (r.status === "expired" ? '<span class="tag amber">انتهى الوقت</span>' : "") + "</div></div></div>" +
        '<div class="inline"><button class="btn" id="again">إعادة الاختبار</button>' +
        '<button class="btn ghost" id="hist">نتائجي</button>' +
        '<button class="btn subtle" id="chat-open">مساعد الدراسة 🤖</button></div></div>' +
        '<div class="card mb"><h3>تحليل مفصل</h3><div class="table-wrap"><table><thead><tr>' +
        "<th>#</th><th>السؤال</th><th>النوع</th><th>إجابتك</th><th>الإجابة الصحيحة</th><th>الدرجة</th></tr></thead><tbody>" +
        r.items.map((it, i) => resultRow(it, i)).join("") +
        "</tbody></table></div></div>" +
        '<div class="card"><div class="card-head"><h3>اشرح لي الأسئلة التي أخطأت فيها</h3><span class="spacer"></span>' +
        '<button class="btn accent sm" id="explain-all">اشرح كل الأخطاء</button></div>' +
        '<div id="explain-host">' + r.items.map((it) => explainCard(it)).join("") + "</div></div>";

      $("#again").addEventListener("click", () => startExam(r.exam_id));
      $("#hist").addEventListener("click", () => go("results"));
      $("#chat-open").addEventListener("click", () => openChat(r.attempt_id));
      $("#explain-all").addEventListener("click", (ev) => explainAll(r, ev.currentTarget));
      view().querySelectorAll("[data-explain]").forEach((b) =>
        b.addEventListener("click", () => explainOne(r.attempt_id, Number(b.dataset.explain), b))
      );
    } catch (e) {
      view().innerHTML = '<div class="card">' + alertBox(e.message) + "</div>";
    }
  }

  function resultRow(it, i) {
    const ok = it.is_correct;
    const badge = ok === true ? '<span class="tag green">صحيح</span>'
      : ok === false ? '<span class="tag red">خطأ</span>'
      : '<span class="tag amber">مقالي</span>';
    return (
      "<tr><td>" + (i + 1) + '</td><td style="direction:ltr;text-align:left;max-width:340px">' + esc(it.text) +
      "</td><td>" + esc(TYPE_SHORT[it.type] || it.type) + '</td><td style="direction:ltr;text-align:left;max-width:220px">' +
      esc(it.student_answer || "—") + '</td><td style="direction:ltr;text-align:left;max-width:220px">' +
      esc(it.correct_answer || "—") + "</td><td class=\"nowrap\">" + badge + " " + it.awarded + "/" + it.points + "</td></tr>"
    );
  }

  function explainCard(it) {
    return (
      '<div class="qcard" id="ex-' + it.question_id + '"><div class="qhead"><div class="qnum">' +
      (it.is_correct === true ? "✓" : "✗") + '</div><span class="tag">' + esc(TYPE_LABEL[it.type] || it.type) +
      "</span>" + (it.is_correct === false ? '<span class="tag red">أخطأت فيها</span>' : "") + "</div>" +
      '<div class="qtext">' + esc(it.text) + "</div>" +
      (it.options ? '<div class="opts">' + it.options.map((o) =>
        '<div class="opt ' + (o === it.correct_answer ? "correct" : o === it.student_answer ? "wrong" : "") + '"><span>' +
        esc(o) + "</span>" + (o === it.correct_answer ? '<span class="mark" style="color:#17a673">الإجابة الصحيحة</span>'
          : o === it.student_answer ? '<span class="mark" style="color:#e5484d">إجابتك</span>' : "") + "</div>"
      ).join("") + "</div>" : "") +
      (it.explanation ? '<div class="explain"><h4>شرح السؤال</h4><div class="body">' + nl2br(it.explanation) + "</div></div>" : "") +
      (it.ai_feedback ? '<div class="explain" style="background:#fff9ec;border-color:#f4e2bd"><h4>تقييم المصحح الآلي</h4><div class="body">' + nl2br(it.ai_feedback) + "</div></div>" : "") +
      '<div class="mt" id="ai-' + it.question_id + '"></div>' +
      (it.is_correct === false || it.type === "essay" || it.type === "short"
        ? '<button class="btn ghost sm mt" data-explain="' + it.question_id + '">اشرح لي بالتفصيل 🤖</button>'
        : "") +
      "</div>"
    );
  }

  async function explainOne(attemptId, questionId, btn) {
    const host = $("#ai-" + questionId);
    if (!host) return;
    busy(btn, true);
    host.innerHTML = loadingBox("المساعد يجهّز الشرح…");
    try {
      const res = await api("/attempts/" + attemptId + "/explain/" + questionId, { method: "POST" });
      host.innerHTML = '<div class="explain" style="background:#eef8f4;border-color:#c3e8da"><h4>شرح المساعد الذكي</h4><div class="body">' +
        nl2br(res.explanation) + "</div></div>";
      if (btn) btn.remove();
    } catch (e) {
      host.innerHTML = alertBox(e.message);
      busy(btn, false);
    }
  }

  async function explainAll(result, btn) {
    const targets = result.items.filter((it) => it.is_correct === false || it.type === "essay" || it.type === "short");
    if (!targets.length) { toast("لا توجد أخطاء — نتيجة ممتازة!", "ok"); return; }
    busy(btn, true);
    for (const it of targets) {
      const b = view().querySelector('[data-explain="' + it.question_id + '"]');
      await explainOne(result.attempt_id, it.question_id, b);
    }
    busy(btn, false);
  }

  function openChat(attemptId) {
    modal("مساعد الدراسة الذكي",
      '<p class="muted">اسأل عن أي شيء في الاختبار — الشرح بالعربية.</p><div class="chat" id="chat-log">' +
      '<div class="msg bot">أهلًا بك! اسألني عن أي سؤال أو مفهوم في هذا الاختبار وسأشرحه لك بالعربية.</div></div>' +
      '<div class="inline mt"><input type="text" id="chat-in" placeholder="اكتب سؤالك هنا…" style="flex:1">' +
      '<button class="btn" id="chat-send">إرسال</button></div>');
    const log = $("#chat-log");
    const history = [];
    const send = async () => {
      const input = $("#chat-in");
      const msg = input.value.trim();
      if (!msg) return;
      input.value = "";
      log.insertAdjacentHTML("beforeend", '<div class="msg user">' + esc(msg) + "</div>");
      const thinking = document.createElement("div");
      thinking.className = "msg bot";
      thinking.innerHTML = '<span class="spinner dark"></span>';
      log.appendChild(thinking);
      log.scrollTop = log.scrollHeight;
      try {
        const res = await api("/attempts/" + attemptId + "/chat", { method: "POST", body: { message: msg, history: history.slice(-10) } });
        thinking.innerHTML = nl2br(res.reply);
        history.push({ role: "user", content: msg }, { role: "assistant", content: res.reply });
      } catch (e) {
        thinking.innerHTML = '<span style="color:#a02024">' + esc(e.message) + "</span>";
      }
      log.scrollTop = log.scrollHeight;
    };
    $("#chat-send").addEventListener("click", send);
    $("#chat-in").addEventListener("keydown", (e) => { if (e.key === "Enter") send(); });
  }

  /* ================= RESULTS HISTORY ================= */
  async function renderResults() {
    const s = state.student || {};
    const signedIn = !!state.user;
    const preset = signedIn ? (state.user.name || "") : (s.name || "");
    const accountLabel = signedIn
      ? esc(state.user.name || "") + (state.user.student_number ? " · رقم " + esc(state.user.student_number) : "")
      : "";
    view().innerHTML =
      '<div class="card mb"><div class="card-head"><h2>نتائجي</h2></div>' +
      (signedIn
        ? '<p class="hint">النتائج معروضة لحسابك <b>' + accountLabel + "</b>.</p>"
        : '<div class="row"><div><label for="h-name">اسم الطالب</label><input type="text" id="h-name" value="' + esc(preset) + '"></div>' +
          '<div><label for="h-sid">رقم الطالب</label><input type="text" id="h-sid" value="' + esc(s.sid || "") + '"></div>' +
          '<div style="display:flex;align-items:flex-end"><button class="btn block" id="h-go">عرض النتائج</button></div></div>' +
          '<p class="hint">أدخل رقم الطالب (الأدق) أو الاسم كما كتبته عند بدء الاختبار.</p>') +
      '</div>' +
      '<div id="h-host"><div class="empty">' +
      (signedIn ? "جارٍ تحميل نتائجك…" : "أدخل بياناتك واضغط «عرض النتائج».") +
      "</div></div>";

    const load = async (query) => {
      const data = await api("/attempts/history" + (query || ""));
      const host = $("#h-host");
      if (!data.attempts.length) {
        host.innerHTML = '<div class="empty">لا توجد نتائج محفوظة بعد.</div>';
        return;
      }
      const avg = Math.round(data.attempts.reduce((n, a) => n + a.percentage, 0) / data.attempts.length);
      host.innerHTML =
        '<div class="stats mb">' + stat(data.attempts.length, "اختبار مُسلَّم") + stat(avg + "%", "المتوسط العام") + "</div>" +
        '<div class="card"><div class="table-wrap"><table><thead><tr><th>الاختبار</th><th>المادة</th><th>الدرجة</th><th>النسبة</th><th>التاريخ</th><th></th></tr></thead><tbody>' +
        data.attempts.map((a) =>
          "<tr><td>" + esc(a.exam_title) + "</td><td>" + esc(a.subject_name || "—") + "</td><td>" + a.score + "/" + a.max_score +
          '</td><td style="color:' + pctColor(a.percentage) + ';font-weight:700">' + a.percentage + "%</td><td>" + fmtDate(a.submitted_at) +
          '</td><td><button class="btn ghost sm" data-view="' + a.attempt_id + '">التفاصيل</button></td></tr>'
        ).join("") + "</tbody></table></div></div>";
      host.querySelectorAll("[data-view]").forEach((b) =>
        b.addEventListener("click", () => { state.lastResult = null; go("result", { attemptId: Number(b.dataset.view) }); })
      );
    };

    if (signedIn) {
      // No name or ID needed: the server resolves the account from the session.
      try {
        await load();
      } catch (e) {
        $("#h-host").innerHTML = '<div class="card">' + alertBox(e.message) + "</div>";
      }
      return;
    }

    $("#h-go").addEventListener("click", async (ev) => {
      const btn = ev.currentTarget;
      const name = $("#h-name").value.trim();
      const sid = $("#h-sid").value.trim();
      if (!name && !sid) { toast("أدخل الاسم أو الرقم", "err"); return; }
      state.student = { name: name, sid: sid };
      localStorage.setItem("tmr_student", JSON.stringify(state.student));
      busy(btn, true);
      try {
        const q = sid ? "?student_id=" + encodeURIComponent(sid) : "?student_name=" + encodeURIComponent(name);
        await load(q);
      } catch (e) {
        $("#h-host").innerHTML = '<div class="card">' + alertBox(e.message) + "</div>";
      } finally {
        busy(btn, false);
      }
    });
  }

  /* ================= LIBRARY ================= */
  async function renderLibrary() {
    view().innerHTML =
      '<div class="card"><div class="card-head"><h2>مكتبة المنهج</h2><span class="spacer"></span>' +
      '<span class="muted">اضغط على الملف لفتحه</span></div>' +
      '<p class="muted">كل ملفات المنهج مرتبة حسب السنة الدراسية ثم المادة. ' +
      "اضغط على أي ملف ليُفتح في تطبيق الهاتف المناسب (قارئ PDF أو Word أو PowerPoint). " +
      "رفع الملفات متاح للمشرف من لوحة الإدارة.</p>" +
      '<div id="lib-host">' + loadingBox() + "</div></div>";
    try {
      const data = await api("/library");
      const host = $("#lib-host");
      const sections = (data.sections || []).filter((s) => (s.subjects || []).some((x) => (x.materials || []).length));
      if (!sections.length) {
        host.innerHTML = '<div class="empty">لا توجد ملفات مرفوعة بعد.</div>';
        return;
      }
      host.innerHTML = sections.map((s) => {
        const subs = s.subjects.filter((x) => (x.materials || []).length);
        return '<div class="mb"><h3>' + esc(s.name) + "</h3>" +
          subs.map((sub) =>
            '<div class="mb"><div class="meta">' + esc(sub.name) + " · " + sub.materials.length + " ملف</div>" +
            sub.materials.map((m) =>
              '<div class="list-item clickable" data-open-m="' + m.id + '">' +
              '<span class="tag">' + esc(fileKindLabel(m.filename)) + "</span>" +
              '<div class="grow"><div class="title">' + esc(m.title) +
              '</div><div class="meta">' + esc(m.filename) + " · " + Math.round(m.size_bytes / 1024) + " KB" +
              (m.text_ready ? "" : ' · <span class="tag amber">لا نص</span>') + "</div></div>" +
              '<span class="btn ghost sm">فتح الملف</span>' +
              "</div>"
            ).join("") + "</div>"
          ).join("") + "</div>";
      }).join("");
      host.querySelectorAll("[data-open-m]").forEach((el) =>
        el.addEventListener("click", () => openMaterialFile(Number(el.dataset.openM)))
      );
    } catch (e) {
      $("#lib-host").innerHTML = alertBox(e.message);
    }
  }

  /* Extension badge for a curriculum file, so the list shows what will open. */
  function fileKindLabel(filename) {
    const ext = String(filename || "").split(".").pop().toUpperCase();
    return ext.length > 1 && ext.length <= 5 ? ext : "ملف";
  }

  /* Open the stored original in the device's own viewer.

     The server sends the file inline with its real content type, so a plain
     navigation to the endpoint is handed straight to the installed PDF/Word/
     PowerPoint app. We avoid object URLs: iOS Safari often renders a blob PDF as
     a blank page, and a blob carries no filename into the receiving app. Where
     the Web Share API can share files we prefer it, because it gives the student
     an explicit "open with" chooser. */
  async function openMaterialFile(id) {
    const url = API + "/materials/" + id + "/file";

    if (navigator.canShare) {
      try {
        const res = await fetch(url, { credentials: "same-origin" });
        if (res.ok) {
          const blob = await res.blob();
          const name = filenameFromDisposition(res.headers.get("Content-Disposition")) || "curriculum";
          const file = new File([blob], name, { type: blob.type || "application/octet-stream" });
          if (navigator.canShare({ files: [file] })) {
            await navigator.share({ files: [file], title: name });
            return;
          }
        }
      } catch (e) {
        if (e && e.name === "AbortError") return; // user dismissed the sheet
      }
    }

    // Direct navigation: the session cookie rides along, and the browser routes
    // the response to the native viewer by content type.
    const a = document.createElement("a");
    a.href = url;
    a.target = "_blank";
    a.rel = "noopener";
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  /* RFC 5987 aware: prefer filename* (UTF-8) so Arabic names survive. */
  function filenameFromDisposition(header) {
    if (!header) return null;
    const star = header.match(/filename\*=UTF-8''([^;]+)/i);
    if (star) {
      try { return decodeURIComponent(star[1]); } catch (e) { /* fall through */ }
    }
    const plain = header.match(/filename="?([^";]+)"?/i);
    return plain ? plain[1] : null;
  }

  /* Preview a curriculum file's text and offer the original for download. */
  async function openMaterial(id) {
    modal("محتوى الملف", loadingBox("جارٍ فتح الملف…"));
    try {
      const data = await api("/materials/" + id + "/text");
      const body =
        '<div class="row"><div class="grow"><strong>' + esc(data.title) + "</strong></div>" +
        '<a class="btn ghost sm" href="' + API + "/materials/" + id + '/file?download=1" download>تنزيل الملف الأصلي</a></div>' +
        (data.text_ready
          ? '<div class="field"><label>النص المستخرج (' + data.text.length + " حرف)</label>" +
            '<textarea class="tall" readonly>' + esc(data.text.slice(0, 20000)) + "</textarea></div>"
          : '<div class="empty">لا يوجد نص مستخرج من هذا الملف.</div>');
      const host = modal("محتوى الملف", body);
      host.querySelector("a.btn")?.addEventListener("click", () => toast("جارٍ التنزيل…", "ok"));
    } catch (e) {
      modal("محتوى الملف",
        e.status === 401
          ? alertBox("سجّل الدخول كمشرف لعرض محتوى الملفات.")
          : alertBox(e.message));
    }
  }

  /* ================= ADMIN ================= */
  async function renderAdmin() {
    view().innerHTML = loadingBox("جارٍ التحقق من الصلاحية…");
    let session;
    try { session = await api("/admin/session"); } catch (e) { view().innerHTML = '<div class="card">' + alertBox(e.message) + "</div>"; return; }
    if (!session.authenticated) return renderAdminLogin();
    state.admin = true;
    renderAdminPanel();
  }

  function renderAdminLogin() {
    view().innerHTML =
      '<div class="card pad-lg" style="max-width:440px;margin:40px auto"><div class="card-head"><h2>🔒 إدارة المنصة</h2></div>' +
      "<p class=\"muted\">هذا القسم محمي. أدخل كود الأمان الخاص بك.</p>" +
      '<div id="admin-err"></div>' +
      '<div class="field"><label for="pc">كود الأمان</label><input type="password" id="pc" placeholder="••••••••" autocomplete="current-password"></div>' +
      '<button class="btn block" id="login-btn">دخول</button></div>';
    const submit = async (ev) => {
      const btn = ev.currentTarget;
      busy(btn, true);
      try {
        await api("/admin/login", { method: "POST", body: { passcode: $("#pc").value } });
        toast("تم الدخول بنجاح", "ok");
        renderAdminPanel();
      } catch (e) {
        busy(btn, false);
        $("#admin-err").innerHTML = alertBox(e.message);
      }
    };
    $("#login-btn").addEventListener("click", submit);
    $("#pc").addEventListener("keydown", (e) => { if (e.key === "Enter") $("#login-btn").click(); });
  }

  async function renderAdminPanel() {
    view().innerHTML =
      '<div class="card mb"><div class="card-head"><h2>لوحة الإدارة</h2><span class="spacer"></span>' +
      '<button class="btn ghost sm" id="logout">خروج</button></div>' +
      '<div class="tabs" id="admin-tabs">' +
      '<button data-tab="overview" class="active">نظرة عامة</button>' +
      '<button data-tab="generate">إنشاء اختبار بالذكاء الاصطناعي</button>' +
      '<button data-tab="exams">الاختبارات</button>' +
      '<button data-tab="sections">السنوات والمواد</button>' +
      '<button data-tab="materials">ملفات المنهج</button>' +
      "</div><div id=\"admin-body\">" + loadingBox() + "</div></div>";

    $("#logout").addEventListener("click", async () => {
      await api("/admin/logout", { method: "POST" });
      toast("تم الخروج");
      go("home");
    });
    $("#admin-tabs").querySelectorAll("button").forEach((b) =>
      b.addEventListener("click", () => {
        $("#admin-tabs").querySelectorAll("button").forEach((x) => x.classList.remove("active"));
        b.classList.add("active");
        adminTab(b.dataset.tab);
      })
    );
    adminTab("overview");
  }

  function adminTab(tab) {
    const host = $("#admin-body");
    if (tab === "overview") return adminOverview(host);
    if (tab === "generate") return adminGenerate(host);
    if (tab === "exams") return adminExams(host);
    if (tab === "sections") return adminSections(host);
    if (tab === "materials") return adminMaterials(host);
  }

  async function adminOverview(host) {
    host.innerHTML = loadingBox();
    try {
      const o = await api("/attempts/admin/overview");
      host.innerHTML =
        '<div class="stats">' + stat(o.exams, "اختبار") + stat(o.questions, "سؤال") +
        stat(o.submitted_attempts, "محاولة مُسلَّمة") +
        stat(o.average_percentage == null ? "—" : o.average_percentage + "%", "متوسط الدرجات") + "</div>";
    } catch (e) { host.innerHTML = alertBox(e.message); }
  }

  /* ---- generate ---- */
  async function adminGenerate(host) {
    host.innerHTML = loadingBox("جارٍ تحميل الأقسام…");
    let cat;
    try { cat = await loadCatalogue(true); } catch (e) { host.innerHTML = alertBox(e.message); return; }
    if (!cat.sections.length) {
      host.innerHTML = '<div class="empty">أنشئ قسمًا ومادة أولًا من تبويب «الأقسام والمواد».</div>';
      return;
    }
    const subjectOptions = cat.sections
      .map((s) => '<optgroup label="' + esc(s.name) + '">' +
        s.subjects.map((x) => '<option value="' + x.id + '">' + esc(x.name) + "</option>").join("") +
        (s.subjects.length ? "" : '<option disabled>— لا مواد —</option>') + "</optgroup>")
      .join("");

    host.innerHTML =
      '<div id="gen-err"></div>' +
      '<div class="row"><div><label for="g-subject">المادة <span style="color:#e5484d">*</span></label><select id="g-subject">' + subjectOptions + "</select></div>" +
      '<div><label for="g-title">عنوان الاختبار <span style="color:#e5484d">*</span></label><input type="text" id="g-title" placeholder="مثال: مراجعة الوحدة الأولى"></div></div>' +
      '<div class="field"><label>مصدر الأسئلة</label><div class="inline">' +
      '<label class="check"><input type="radio" name="gsrc" value="text" checked> نص / لصق</label>' +
      '<label class="check"><input type="radio" name="gsrc" value="upload"> رفع ملف PDF</label>' +
      '<label class="check"><input type="radio" name="gsrc" value="material"> من ملفات المنهج</label>' +
      "</div></div>" +
      '<div id="src-text"><div class="field"><label for="g-text">الصق الأسئلة أو نص الشرح هنا</label>' +
      '<textarea id="g-text" class="tall" placeholder="الصق نص الدرس أو قائمة الأسئلة هنا… المنصة ستحوله إلى امتحان كامل."></textarea>' +
      '<div class="hint">يعمل مع أي نص: أسئلة جاهزة، ملخص درس، أو شرح — والمحرك يبني منه اختبارًا.</div></div></div>' +
      '<div id="src-upload" class="hidden"><div class="field"><label for="g-file">ملف الأسئلة أو الشرح (PDF / DOCX / PPTX / TXT)</label>' +
      '<input type="file" id="g-file" accept=".pdf,.docx,.pptx,.txt,.md,.csv"><div class="hint">استخراج النص تلقائي من PDF أو Word أو PowerPoint ثم توليد الاختبار منه.</div></div></div>' +
      '<div id="src-material" class="hidden"><div class="field"><label for="g-material">اختر ملفًا من مكتبة المنهج</label>' +
      '<select id="g-material"><option value="">— اختر ملفًا —</option></select></div></div>' +
      '<div class="field"><label>عدد الأسئلة لكل نوع</label><div class="count-grid">' +
      countBox("mcq", "اختيار من متعدد", 5) + countBox("truefalse", "صح / خطأ", 2) +
      countBox("essay", "مقالي", 0) + countBox("short", "إجابة قصيرة", 0) + "</div>" +
      '<div class="hint">اترك النوع على صفر لتجاهله.</div></div>' +
      '<div class="row"><div><label>درجة الصعوبة</label><select id="g-diff">' +
      '<option value="easy">سهل</option><option value="medium" selected>متوسط</option><option value="hard">صعب</option></select></div>' +
      '<div><label>المستوى / الجمهور</label><input type="text" id="g-aud" placeholder="مثال: الصف الثالث الثانوي"></div></div>' +
      '<div class="field"><label>تعليمات إضافية للمحرك (اختياري)</label>' +
      '<input type="text" id="g-extra" placeholder="مثال: ركّز على القوانين والتطبيقات"></div>' +
      '<div class="field"><label>الوقت</label><div class="inline">' +
      '<label class="check"><input type="checkbox" id="g-timed"> اختبار بوقت محدد</label>' +
      '<input type="number" id="g-dur" min="1" max="600" value="30" style="width:110px" disabled><span class="muted">دقيقة</span>' +
      "</div></div>" +
      '<button class="btn" id="g-go">توليد الاختبار ✨</button>';

    $("#g-timed").addEventListener("change", (e) => { $("#g-dur").disabled = !e.target.checked; });
    host.querySelectorAll('input[name="gsrc"]').forEach((r) =>
      r.addEventListener("change", () => {
        const v = host.querySelector('input[name="gsrc"]:checked').value;
        $("#src-text").classList.toggle("hidden", v !== "text");
        $("#src-upload").classList.toggle("hidden", v !== "upload");
        $("#src-material").classList.toggle("hidden", v !== "material");
      })
    );

    try {
      const mats = await api("/materials");
      const sel = $("#g-material");
      mats.materials.filter((m) => m.text_ready).forEach((m) => {
        const o = document.createElement("option");
        o.value = m.id;
        o.textContent = m.title + " (" + m.kind + ")";
        sel.appendChild(o);
      });
    } catch (e) { /* materials are optional */ }

    $("#g-go").addEventListener("click", async (ev) => {
      const btn = ev.currentTarget;
      const subjectId = Number($("#g-subject").value);
      const title = $("#g-title").value.trim();
      if (!subjectId) { $("#gen-err").innerHTML = alertBox("اختر مادة"); return; }
      if (!title) { $("#gen-err").innerHTML = alertBox("اكتب عنوان الاختبار"); return; }
      const counts = {
        mcq: Number($("#g-mcq").value) || 0,
        truefalse: Number($("#g-truefalse").value) || 0,
        essay: Number($("#g-essay").value) || 0,
        short: Number($("#g-short").value) || 0,
      };
      if (!Object.values(counts).some((v) => v > 0)) { $("#gen-err").innerHTML = alertBox("حدد عدد أسئلة أكبر من صفر"); return; }
      const mode = host.querySelector('input[name="gsrc"]:checked').value;
      const timed = $("#g-timed").checked;
      const duration = Number($("#g-dur").value) || null;
      const common = {
        subject_id: subjectId, title: title, counts: counts, timed: timed, duration_minutes: duration,
        difficulty: $("#g-diff").value, language_note: $("#g-aud").value.trim(),
        extra_instructions: $("#g-extra").value.trim(),
      };
      busy(btn, true);
      $("#gen-err").innerHTML = "";
      const prog = showProgress();
      try {
        let res;
        if (mode === "upload") {
          const file = $("#g-file").files[0];
          if (!file) throw new Error("اختر ملفًا أولًا");
          const fd = new FormData();
          Object.keys(common).forEach((k) => { if (common[k] != null) fd.append(k, typeof common[k] === "object" ? JSON.stringify(common[k]) : common[k]); });
          fd.append("file", file);
          res = await streamGenerate("/exams/generate-from-upload-stream", fd, prog);
        } else if (mode === "material") {
          const mid = Number($("#g-material").value);
          if (!mid) throw new Error("اختر ملفًا من المنهج");
          res = await streamGenerate("/exams/generate-stream", Object.assign({ material_id: mid }, common), prog);
        } else {
          const text = $("#g-text").value.trim();
          if (text.length < 30) throw new Error("الصق نصًا أطول (30 حرفًا على الأقل)");
          res = await streamGenerate("/exams/generate-stream", Object.assign({ source_text: text }, common), prog);
        }
        prog.done();
        toast("تم إنشاء الاختبار: " + res.questions + " سؤال", "ok");
        adminTab("exams");
      } catch (e) {
        prog.close();
        busy(btn, false);
        $("#gen-err").innerHTML = alertBox(e.message);
      }
    });
  }

  /* Progress bar driven by the server's SSE frames. */
  function showProgress() {
    const host = $("#gen-err");
    host.innerHTML =
      '<div class="progress-card"><div class="progress-label" id="pg-label">جارٍ تجهيز الطلب…</div>' +
      '<div class="progress-track"><div class="progress-fill" id="pg-fill" style="width:6%"></div></div></div>';
    const label = $("#pg-label");
    const fill = $("#pg-fill");
    let timer = setInterval(() => {
      const w = parseFloat(fill.style.width) || 6;
      if (w < 92) fill.style.width = (w + Math.max(0.4, (92 - w) * 0.04)) + "%";
    }, 600);
    return {
      update(d) {
        if (d.message) label.textContent = d.message;
        if (d.total > 1 && d.done > 0) fill.style.width = Math.round((d.done / d.total) * 95) + "%";
      },
      done() {
        clearInterval(timer);
        fill.style.width = "100%";
        label.textContent = "تم إنشاء الاختبار ✅";
        setTimeout(() => { host.innerHTML = ""; }, 900);
      },
      close() {
        clearInterval(timer);
        host.innerHTML = "";
      },
    };
  }

  /* POST that reads an SSE stream, reporting progress as frames arrive. */
  async function streamGenerate(path, body, prog) {
    const isForm = body instanceof FormData;
    const res = await fetch(API + path, {
      method: "POST",
      credentials: "same-origin",
      headers: isForm ? {} : { "Content-Type": "application/json" },
      body: isForm ? body : JSON.stringify(body),
    });
    if (!res.ok) {
      const text = await res.text();
      let detail = res.statusText;
      try { const j = JSON.parse(text); detail = j.detail || detail; } catch (e) { detail = text || detail; }
      if (Array.isArray(detail)) detail = detail.map((d) => d.msg || JSON.stringify(d)).join("; ");
      const err = new Error(detail || "حدث خطأ");
      err.status = res.status;
      throw err;
    }
    if (!res.body) throw new Error("المتصفح لا يدعم البث المباشر");

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let result = null;
    let failure = null;

    while (true) {
      const chunk = await reader.read();
      if (chunk.done) break;
      buffer += decoder.decode(chunk.value, { stream: true });
      const frames = buffer.split("\n\n");
      buffer = frames.pop();
      for (const frame of frames) {
        const evLine = frame.split("\n").find((l) => l.startsWith("event: "));
        const dataLine = frame.split("\n").find((l) => l.startsWith("data: "));
        if (!evLine || !dataLine) continue;
        const event = evLine.slice(7).trim();
        let data;
        try { data = JSON.parse(dataLine.slice(6)); } catch (e) { continue; }
        if (event === "progress") prog.update(data);
        else if (event === "done") result = data;
        else if (event === "error") failure = data.detail;
      }
    }

    if (failure) throw new Error(failure);
    if (!result) throw new Error("لم يكتمل توليد الاختبار — أعد المحاولة.");
    return result;
  }

  function countBox(id, label, val) {
    return '<div class="count-box"><label for="g-' + id + '">' + esc(label) + '</label>' +
      '<input type="number" id="g-' + id + '" min="0" max="100" value="' + val + '"></div>';
  }

  async function adminExams(host) {
    host.innerHTML = loadingBox();
    try {
      const data = await api("/exams/admin");
      if (!data.exams.length) { host.innerHTML = '<div class="empty">لا توجد اختبارات بعد.</div>'; return; }
      host.innerHTML =
        '<div class="table-wrap"><table><thead><tr><th>العنوان</th><th>المادة</th><th>أسئلة</th><th>الوقت</th><th>الحالة</th><th></th></tr></thead><tbody>' +
        data.exams.map((e) =>
          "<tr><td>" + esc(e.title) + "</td><td>" + esc(e.subject_name || "—") + "</td><td>" + e.questions +
          "</td><td>" + (e.timed ? e.duration_minutes + " د" : "بدون") + "</td><td>" +
          (e.is_published ? '<span class="tag green">منشور</span>' : '<span class="tag amber">مسودة</span>') +
          '</td><td class="nowrap"><button class="btn ghost sm" data-edit="' + e.id + '">تعديل</button> ' +
          '<button class="btn subtle sm" data-res="' + e.id + '">النتائج</button> ' +
          '<button class="btn danger sm" data-del="' + e.id + '">حذف</button></td></tr>'
        ).join("") + "</tbody></table></div>";

      host.querySelectorAll("[data-del]").forEach((b) =>
        b.addEventListener("click", async () => {
          if (!(await confirmDialog("حذف الاختبار وكل نتائجه نهائيًا؟"))) return;
          try { await api("/exams/" + b.dataset.del, { method: "DELETE" }); toast("تم الحذف", "ok"); adminTab("exams"); }
          catch (e) { toast(e.message, "err"); }
        })
      );
      host.querySelectorAll("[data-edit]").forEach((b) =>
        b.addEventListener("click", () => adminEditExam(data.exams.find((x) => x.id === Number(b.dataset.edit))))
      );
      host.querySelectorAll("[data-res]").forEach((b) =>
        b.addEventListener("click", () => adminExamResults(Number(b.dataset.res)))
      );
    } catch (e) { host.innerHTML = alertBox(e.message); }
  }

  function adminEditExam(exam) {
    modal("تعديل الاختبار",
      '<div id="e-err"></div>' +
      '<div class="field"><label>العنوان</label><input type="text" id="e-title" value="' + esc(exam.title) + '"></div>' +
      '<div class="field"><label>الوقت</label><div class="inline">' +
      '<label class="check"><input type="checkbox" id="e-timed" ' + (exam.timed ? "checked" : "") + '> موقوت</label>' +
      '<input type="number" id="e-dur" min="1" max="600" value="' + (exam.duration_minutes || 30) + '" style="width:110px"></div></div>' +
      '<div class="field"><label class="check"><input type="checkbox" id="e-pub" ' + (exam.is_published ? "checked" : "") + '> منشور للطلاب</label></div>',
      '<button class="btn" id="e-save">حفظ</button><button class="btn ghost" id="e-cancel">إلغاء</button>');
    $("#e-cancel").addEventListener("click", closeModal);
    $("#e-save").addEventListener("click", async (ev) => {
      const btn = ev.currentTarget;
      busy(btn, true);
      try {
        await api("/exams/" + exam.id, {
          method: "PATCH",
          body: {
            title: $("#e-title").value.trim(), timed: $("#e-timed").checked,
            duration_minutes: Number($("#e-dur").value) || null, is_published: $("#e-pub").checked,
          },
        });
        closeModal(); toast("تم الحفظ", "ok"); adminTab("exams");
      } catch (e) { busy(btn, false); $("#e-err").innerHTML = alertBox(e.message); }
    });
  }

  async function adminExamResults(examId) {
    modal("نتائج الاختبار", loadingBox());
    try {
      const data = await api("/attempts/admin/exam/" + examId + "/results");
      const body =
        data.results.length
          ? '<div class="table-wrap"><table><thead><tr><th>الطالب</th><th>الرقم</th><th>الدرجة</th><th>النسبة</th><th>التاريخ</th></tr></thead><tbody>' +
            data.results.map((r) =>
              "<tr><td>" + esc(r.student_name) + "</td><td>" + esc(r.student_id || "—") + "</td><td>" + r.score + "/" + r.max_score +
              '</td><td style="color:' + pctColor(r.percentage) + ';font-weight:700">' + r.percentage + "%</td><td>" + fmtDate(r.submitted_at) + "</td></tr>"
            ).join("") + "</tbody></table></div>"
          : '<div class="empty">لا توجد نتائج بعد.</div>';
      $(".modal-body").innerHTML = "<h3>" + esc(data.title) + "</h3>" + body;
    } catch (e) { $(".modal-body").innerHTML = alertBox(e.message); }
  }

  /* ---- sections ---- */
  async function adminSections(host) {
    host.innerHTML = loadingBox();
    try {
      const cat = await loadCatalogue(true);
      host.innerHTML =
        '<div class="grid cols-2"><div><div class="card-head"><h3>السنوات الدراسية</h3><span class="spacer"></span>' +
        '<button class="btn sm" id="new-sec">+ سنة دراسية</button></div>' +
        '<p class="hint">رتب السنوات بالأسهم — الترتيب يظهر كما هو للطلاب.</p>' +
        '<div class="list" id="sec-list">' +
        (cat.sections.length ? cat.sections.map((s, i) =>
          '<div class="list-item"><div class="grow"><div class="title">' + esc(s.name) +
          ' <span class="tag gray">' + (i + 1) + '</span></div><div class="meta">' +
          s.subjects.length + ' مادة</div></div>' +
          '<button class="btn ghost sm" data-up="' + s.id + '"' + (i === 0 ? " disabled" : "") + ' title="لأعلى">▲</button>' +
          '<button class="btn ghost sm" data-down="' + s.id + '"' + (i === cat.sections.length - 1 ? " disabled" : "") + ' title="لأسفل">▼</button>' +
          '<button class="btn ghost sm" data-edit-sec="' + s.id + '">تعديل</button>' +
          '<button class="btn danger sm" data-del-sec="' + s.id + '">حذف</button></div>'
        ).join("") : '<div class="empty">لا توجد سنوات دراسية.</div>') + "</div></div>" +
        '<div><div class="card-head"><h3>المواد</h3><span class="spacer"></span>' +
        '<button class="btn sm" id="new-sub">+ مادة جديدة</button></div>' +
        '<div class="list" id="subj-list">' +
        (cat.sections.some((s) => s.subjects.length) ? cat.sections.map((s) =>
          s.subjects.map((sub) =>
            '<div class="list-item"><div class="grow"><div class="title">' + esc(sub.name) + '</div><div class="meta">' +
            esc(s.name) + " · " + sub.exams + " اختبار · " + sub.materials + ' ملف</div></div>' +
            '<button class="btn danger sm" data-del-sub="' + sub.id + '">حذف</button></div>'
          ).join("")
        ).join("") : '<div class="empty">لا توجد مواد.</div>') + "</div></div></div>";

      const sectionModal = (existing) => {
        const isEdit = !!existing;
        modal(isEdit ? "تعديل سنة دراسية" : "سنة دراسية جديدة",
          '<div id="s-err"></div><div class="field"><label>اسم السنة</label>' +
          '<input type="text" id="s-name" placeholder="مثال: الفرقة الخامسة" value="' +
          (isEdit ? esc(existing.name) : "") + '"></div>' +
          '<div class="field"><label>وصف (اختياري)</label><input type="text" id="s-desc" value="' +
          (isEdit && existing.description ? esc(existing.description) : "") + '"></div>' +
          '<div class="hint">أضف "الفرقة الخامسة" أو أي سنة إضافية بنفس الطريقة.</div>',
          '<button class="btn" id="s-save">' + (isEdit ? "حفظ" : "إنشاء") + '</button>' +
          '<button class="btn ghost" id="s-cancel">إلغاء</button>');
        $("#s-cancel").addEventListener("click", closeModal);
        $("#s-save").addEventListener("click", async (ev) => {
          const btn = ev.currentTarget;
          const body = { name: $("#s-name").value.trim(), description: $("#s-desc").value.trim() || null };
          if (!body.name) { $("#s-err").innerHTML = alertBox("اكتب اسم السنة"); return; }
          busy(btn, true);
          try {
            if (isEdit) await api("/sections/" + existing.id, { method: "PATCH", body: body });
            else await api("/sections", { method: "POST", body: body });
            closeModal(); toast(isEdit ? "تم التعديل" : "تم إنشاء السنة", "ok"); adminTab("sections");
          } catch (e) { busy(btn, false); $("#s-err").innerHTML = alertBox(e.message); }
        });
      };

      $("#new-sec").addEventListener("click", () => sectionModal(null));

      $("#new-sub").addEventListener("click", () => {
        modal("مادة جديدة", '<div id="x-err"></div>' +
          '<div class="field"><label>السنة الدراسية</label><select id="x-sec">' +
          cat.sections.map((s) => '<option value="' + s.id + '">' + esc(s.name) + "</option>").join("") + "</select></div>" +
          '<div class="field"><label>اسم المادة</label><input type="text" id="x-name" placeholder="مثال: الكيمياء"></div>' +
          '<div class="field"><label>وصف (اختياري)</label><input type="text" id="x-desc"></div>',
          '<button class="btn" id="x-save">إنشاء</button><button class="btn ghost" id="x-cancel">إلغاء</button>');
        $("#x-cancel").addEventListener("click", closeModal);
        $("#x-save").addEventListener("click", async (ev) => {
          const btn = ev.currentTarget;
          busy(btn, true);
          try {
            await api("/subjects", { method: "POST", body: { section_id: Number($("#x-sec").value), name: $("#x-name").value.trim(), description: $("#x-desc").value.trim() || null } });
            closeModal(); toast("تم إنشاء المادة", "ok"); adminTab("sections");
          } catch (e) { busy(btn, false); $("#x-err").innerHTML = alertBox(e.message); }
        });
      });

      // Reordering sends the full id list so the server stores a clean 0..n order.
      const move = async (id, delta) => {
        const ids = cat.sections.map((s) => s.id);
        const from = ids.indexOf(id);
        const to = from + delta;
        if (from < 0 || to < 0 || to >= ids.length) return;
        ids.splice(to, 0, ids.splice(from, 1)[0]);
        try {
          await api("/sections/reorder", { method: "POST", body: { ids: ids } });
          state.catalogue = null;
          adminTab("sections");
        } catch (e) { toast(e.message, "err"); }
      };
      host.querySelectorAll("[data-up]").forEach((b) =>
        b.addEventListener("click", () => move(Number(b.dataset.up), -1))
      );
      host.querySelectorAll("[data-down]").forEach((b) =>
        b.addEventListener("click", () => move(Number(b.dataset.down), 1))
      );
      host.querySelectorAll("[data-edit-sec]").forEach((b) =>
        b.addEventListener("click", () => sectionModal(cat.sections.find((s) => s.id === Number(b.dataset.editSec))))
      );
      host.querySelectorAll("[data-del-sec]").forEach((b) =>
        b.addEventListener("click", async () => {
          if (!(await confirmDialog("حذف السنة الدراسية بكل موادها واختباراتها؟"))) return;
          try { await api("/sections/" + b.dataset.delSec, { method: "DELETE" }); state.catalogue = null; toast("تم الحذف", "ok"); adminTab("sections"); }
          catch (e) { toast(e.message, "err"); }
        })
      );
      host.querySelectorAll("[data-del-sub]").forEach((b) =>
        b.addEventListener("click", async () => {
          if (!(await confirmDialog("حذف المادة بكل ملفاتها واختباراتها؟"))) return;
          try { await api("/subjects/" + b.dataset.delSub, { method: "DELETE" }); state.catalogue = null; toast("تم الحذف", "ok"); adminTab("sections"); }
          catch (e) { toast(e.message, "err"); }
        })
      );
    } catch (e) { host.innerHTML = alertBox(e.message); }
  }

  /* ---- materials ---- */
  async function adminMaterials(host) {
    host.innerHTML = loadingBox();
    let cat;
    try { cat = await loadCatalogue(true); } catch (e) { host.innerHTML = alertBox(e.message); return; }
    const subjectOptions = cat.sections
      .map((s) => s.subjects.map((x) => '<option value="' + x.id + '">' + esc(s.name + " › " + x.name) + "</option>").join(""))
      .join("");

    host.innerHTML =
      '<div id="m-err"></div><div class="row">' +
      '<div><label for="m-subject">المادة <span style="color:#e5484d">*</span></label><select id="m-subject">' + (subjectOptions || '<option value="">— لا مواد —</option>') + "</select></div>" +
      '<div><label for="m-kind">نوع الملف</label><select id="m-kind">' +
      '<option value="material">ملف منهج</option><option value="explanation">ملف شرح</option></select></div>' +
      '<div><label for="m-title">عنوان الملف (اختياري)</label><input type="text" id="m-title"></div></div>' +
      '<div class="field"><label for="m-file">اختر ملفًا (PDF / DOCX / PPTX / TXT / MD / CSV)</label><input type="file" id="m-file" accept=".pdf,.docx,.pptx,.txt,.md,.csv"></div>' +
      '<button class="btn" id="m-go">رفع الملف</button>' +
      '<hr style="margin:22px 0;border:none;border-top:1px solid var(--line)">' +
      '<h3>الملفات المرفوعة</h3><div id="m-list">' + loadingBox() + "</div>";

    $("#m-go").addEventListener("click", async (ev) => {
      const btn = ev.currentTarget;
      const file = $("#m-file").files[0];
      const subjectId = $("#m-subject").value;
      if (!subjectId) { $("#m-err").innerHTML = alertBox("أنشئ مادة أولًا"); return; }
      if (!file) { $("#m-err").innerHTML = alertBox("اختر ملفًا"); return; }
      const fd = new FormData();
      fd.append("subject_id", subjectId);
      fd.append("kind", $("#m-kind").value);
      fd.append("title", $("#m-title").value.trim());
      fd.append("file", file);
      busy(btn, true);
      $("#m-err").innerHTML = "";
      try {
        const res = await api("/materials", { method: "POST", body: fd });
        toast(res.text_ready ? "تم الرفع واستخراج النص (" + res.text_chars + " حرف)" : "تم الرفع", "ok");
        if (res.warning) toast("تنبيه: " + res.warning, "err");
        $("#m-file").value = ""; $("#m-title").value = "";
        loadMaterials();
      } catch (e) { $("#m-err").innerHTML = alertBox(e.message); }
      busy(btn, false);
    });

    async function loadMaterials() {
      try {
        const data = await api("/materials");
        const host2 = $("#m-list");
        if (!data.materials.length) { host2.innerHTML = '<div class="empty">لا توجد ملفات بعد.</div>'; return; }
        host2.innerHTML = '<div class="table-wrap"><table><thead><tr><th>العنوان</th><th>النوع</th><th>الحجم</th><th>النص</th><th></th></tr></thead><tbody>' +
          data.materials.map((m) =>
            "<tr><td>" + esc(m.title) + '</td><td><span class="tag gray">' + esc(m.kind) + "</span></td><td>" +
            Math.round(m.size_bytes / 1024) + " KB</td><td>" +
            (m.text_ready ? '<span class="tag green">' + m.text_chars + " حرف</span>" : '<span class="tag amber">لا نص</span>') +
            '</td><td class="nowrap"><button class="btn ghost sm" data-open-m="' + m.id + '">فتح</button> ' +
            '<a class="btn ghost sm" href="' + API + "/materials/" + m.id + '/file?download=1" download>تنزيل</a> ' +
            '<button class="btn danger sm" data-del-m="' + m.id + '">حذف</button></td></tr>'
          ).join("") + "</tbody></table></div>";
        host2.querySelectorAll("[data-open-m]").forEach((b) =>
          b.addEventListener("click", () => openMaterial(Number(b.dataset.openM)))
        );
        host2.querySelectorAll("[data-del-m]").forEach((b) =>
          b.addEventListener("click", async () => {
            if (!(await confirmDialog("حذف هذا الملف؟"))) return;
            try { await api("/materials/" + b.dataset.delM, { method: "DELETE" }); toast("تم الحذف", "ok"); loadMaterials(); }
            catch (e) { toast(e.message, "err"); }
          })
        );
      } catch (e) { $("#m-list").innerHTML = alertBox(e.message); }
    }
    loadMaterials();
  }

  /* ---------------- boot ---------------- */
  window.App = { go: go, api: api, state: state };

  window.addEventListener("hashchange", () => {
    const r = location.hash.slice(1);
    if (r && ROUTES[r] && r !== state.route) go(r, state.params);
  });

  (async function boot() {
    // Everything sits behind the sign-in gate; the nav and view only render once
    // a session exists, so a signed-out visitor never sees an empty shell.
    const ok = await requireAuth();
    if (!ok) return;
    renderNav();
    const initial = location.hash.slice(1);
    if (initial && ROUTES[initial]) {
      state.route = initial;
      renderNav();
      ROUTES[initial].render();
    } else {
      go("home");
    }
  })();
})();
