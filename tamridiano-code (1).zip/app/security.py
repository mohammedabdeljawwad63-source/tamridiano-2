"""Backwards-compatible re-export of the auth helpers.

The implementation lives in `app.auth`; this module exists so existing imports
keep working and so the admin-passcode helpers have one obvious home.
"""

from .auth import (  # noqa: F401
    ADMIN_COOKIE,
    USER_COOKIE,
    AuthError,
    check_passcode,
    create_admin_token,
    create_user_token,
    is_admin_email,
    optional_user,
    require_admin,
    require_identity,
    require_user,
    verify_admin_token,
    verify_google_token,
    verify_user_token,
)

__all__ = [
    "ADMIN_COOKIE",
    "USER_COOKIE",
    "AuthError",
    "check_passcode",
    "create_admin_token",
    "create_user_token",
    "is_admin_email",
    "optional_user",
    "require_admin",
    "require_identity",
    "require_user",
    "verify_admin_token",
    "verify_google_token",
    "verify_user_token",
]
