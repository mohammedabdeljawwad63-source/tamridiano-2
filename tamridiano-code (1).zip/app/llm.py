import io
import json
import logging
import re

import httpx
from pypdf import PdfReader

from .config import LLM_API_KEY, LLM_BASE_URL, LLM_MAX_TOKENS, LLM_MODEL, LLM_TIMEOUT

log = logging.getLogger("tamridiano.llm")

_client: httpx.AsyncClient | None = None


def _get_client() -> httpx.AsyncClient:
    global _client
    if _client is None or _client.is_closed:
        _client = httpx.AsyncClient(
            base_url=LLM_BASE_URL,
            timeout=httpx.Timeout(LLM_TIMEOUT, connect=20.0),
            limits=httpx.Limits(max_connections=200, max_keepalive_connections=50),
        )
    return _client


async def close_client() -> None:
    global _client
    if _client is not None and not _client.is_closed:
        await _client.aclose()
    _client = None


class LLMError(RuntimeError):
    pass


async def chat(
    messages: list[dict],
    *,
    model: str | None = None,
    json_mode: bool = False,
    max_tokens: int | None = None,
    temperature: float = 0.3,
) -> str:
    payload: dict = {
        "model": model or LLM_MODEL,
        "messages": messages,
        "max_tokens": max_tokens or LLM_MAX_TOKENS,
        "temperature": temperature,
    }
    if json_mode:
        payload["response_format"] = {"type": "json_object"}

    try:
        resp = await _get_client().post(
            "/chat/completions",
            json=payload,
            headers={"Authorization": f"Bearer {LLM_API_KEY}"},
        )
    except httpx.HTTPError as exc:
        raise LLMError(f"AI provider unreachable: {exc}") from exc

    if resp.status_code >= 400:
        raise LLMError(f"AI provider error {resp.status_code}: {resp.text[:300]}")

    data = resp.json()
    try:
        choice = data["choices"][0]["message"]
    except (KeyError, IndexError, TypeError) as exc:
        raise LLMError(f"Malformed AI response: {str(data)[:300]}") from exc

    content = choice.get("content") or ""
    if not content.strip():
        finish = data["choices"][0].get("finish_reason")
        usage = data.get("usage", {})
        reasoning = usage.get("completion_tokens_details", {}).get("reasoning_tokens")
        raise LLMError(
            "The AI model returned an empty answer"
            f" (finish_reason={finish}, reasoning_tokens={reasoning}). "
            "Increase LLM_MAX_TOKENS."
        )
    return content


def extract_json(raw: str) -> dict:
    """Parse JSON from a model reply, tolerating ```json fences and prose padding."""
    text = raw.strip()
    fence = re.search(r"```(?:json)?\s*(.+?)\s*```", text, re.DOTALL)
    if fence:
        text = fence.group(1).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    start, end = text.find("{"), text.rfind("}")
    if start != -1 and end > start:
        try:
            return json.loads(text[start : end + 1])
        except json.JSONDecodeError as exc:
            raise LLMError(f"AI returned invalid JSON: {text[:300]}") from exc
    raise LLMError(f"AI returned no JSON object: {text[:300]}")


def pdf_to_text(data: bytes, max_chars: int = 120_000) -> str:
    try:
        reader = PdfReader(io.BytesIO(data))
    except Exception as exc:  # noqa: BLE001 - pypdf raises assorted errors
        raise ValueError("تعذّر قراءة ملف PDF — تأكد أن الملف سليم وغير تالف.") from exc

    if reader.is_encrypted:
        try:
            reader.decrypt("")
        except Exception as exc:  # noqa: BLE001
            raise ValueError("ملف PDF محمي بكلمة مرور. أزل الحماية ثم ارفعه من جديد.") from exc

    chunks: list[str] = []
    total = 0
    for page in reader.pages:
        try:
            page_text = page.extract_text() or ""
        except Exception:  # noqa: BLE001 - skip unreadable page
            continue
        if page_text.strip():
            chunks.append(page_text)
            total += len(page_text)
            if total >= max_chars:
                break
    text = "\n\n".join(chunks).strip()
    if not text:
        raise ValueError(
            "لا يوجد نص قابل للاستخراج في ملف PDF — يبدو أنه صورة ممسوحة (Scanned). "
            "ارفع ملفًا نصيًا أو الصق نص الشرح يدويًا."
        )
    return text[:max_chars]
