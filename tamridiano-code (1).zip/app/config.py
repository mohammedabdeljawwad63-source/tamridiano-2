import os
from pathlib import Path

from sqlalchemy.engine import make_url

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
UPLOAD_DIR = DATA_DIR / "uploads"
STATIC_DIR = BASE_DIR / "app" / "static"

DATA_DIR.mkdir(parents=True, exist_ok=True)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

# Public mount prefix, for serving behind a proxy that strips a path prefix.
# Empty by default: a site on its own domain lives at "/". A non-empty default
# would make the HTML load at "/" while its assets resolve under the prefix,
# so every stylesheet and script 404s and the page renders unstyled.
ROOT_PATH = os.getenv("APP_ROOT_PATH", "").rstrip("/")

_SQLITE_URL = f"sqlite+aiosqlite:///{DATA_DIR / 'tamridiano.db'}"


def _asyncpg_url(raw: str) -> str:
    """Rewrite a managed Postgres URL into the form asyncpg accepts.

    Providers (Neon, Render, Supabase) hand out libpq-style URLs: a bare
    ``postgres://`` scheme plus ``sslmode=require`` and ``channel_binding=require``.
    asyncpg rejects both query parameters outright — it spells sslmode as ``ssl``
    and has no channel binding — so a URL pasted straight from a provider
    dashboard makes the app fail to start. Translate it here rather than asking
    the operator to hand-edit a connection string.
    """
    if not raw.startswith("postgresql+asyncpg://"):
        for prefix in ("postgres://", "postgresql://"):
            if raw.startswith(prefix):
                raw = "postgresql+asyncpg://" + raw[len(prefix):]
                break
        else:
            return raw

    url = make_url(raw)
    query = dict(url.query)
    sslmode = query.pop("sslmode", None)
    query.pop("channel_binding", None)
    if sslmode and "ssl" not in query:
        query["ssl"] = sslmode
    return url.set(query=query).render_as_string(hide_password=False)


# An empty DATABASE_URL (as shipped in .env.example) means "use SQLite".
DATABASE_URL = _asyncpg_url((os.getenv("DATABASE_URL") or "").strip()) or _SQLITE_URL

# How many startup snapshots of the SQLite file to keep in data/backups.
DB_BACKUP_KEEP = int(os.getenv("DB_BACKUP_KEEP", "10"))

# One-off source archive download, so the project can be pulled off the box
# without a GitHub account. Set DOWNLOAD_TOKEN to a random string to enable
# GET /source/<token>; empty (the default) makes the route return 404.
DOWNLOAD_TOKEN = os.getenv("DOWNLOAD_TOKEN", "")
SOURCE_ZIP = DATA_DIR / "tamridiano-code.zip"

# --- Keep-alive ---------------------------------------------------------------
# Free hosts (Render, Koyeb) suspend a web service after ~15 minutes without
# inbound traffic, so the next student waits ~1 minute for a cold start. When
# enabled, the app requests its own public health endpoint on a timer and the
# platform counts that as traffic, so the service never goes idle.
#
# This cannot wake an already-sleeping service — a stopped process cannot send
# anything. Pair it with an external pinger (cron-job.org, UptimeRobot) for
# that, or keep it as a safety net for the hours it does cover.
KEEP_ALIVE = os.getenv("KEEP_ALIVE", "false").strip().lower() in {"1", "true", "yes", "on"}
# Ping more often than the 15-minute idle window, with room for a slow response.
KEEP_ALIVE_INTERVAL_MINUTES = int(os.getenv("KEEP_ALIVE_INTERVAL_MINUTES", "10"))


def _keep_alive_url() -> str:
    """The app's own public health URL, or "" when it cannot be determined.

    Render publishes the service's URL, which is the only case that needs no
    configuration. Everywhere else the operator sets KEEP_ALIVE_URL.
    """
    explicit = os.getenv("KEEP_ALIVE_URL", "").strip()
    if explicit:
        return explicit
    render_url = os.getenv("RENDER_EXTERNAL_URL", "").strip().rstrip("/")
    return f"{render_url}/api/health" if render_url else ""


KEEP_ALIVE_URL = _keep_alive_url()

LLM_BASE_URL = os.getenv("LLM_BASE_URL", "https://codecraftapi.com/v1")
LLM_API_KEY = os.getenv("LLM_API_KEY", "")
LLM_MODEL = os.getenv("LLM_MODEL", "gemini-3.7-flash")
LLM_MODEL_HEAVY = os.getenv("LLM_MODEL_HEAVY", "claude-opus-5")
LLM_MAX_TOKENS = int(os.getenv("LLM_MAX_TOKENS", "8000"))
LLM_TIMEOUT = float(os.getenv("LLM_TIMEOUT", "300"))

ADMIN_PASSCODE = os.getenv("ADMIN_PASSCODE", "tamridiano-admin")
SESSION_SECRET = os.getenv("SESSION_SECRET", "change-me-in-production")
SESSION_TTL_HOURS = int(os.getenv("SESSION_TTL_HOURS", "72"))

# --- Google Sign-In -----------------------------------------------------------
# The OAuth *client ID* is public and is the only value the browser needs; the
# ID token it returns is verified against Google's public keys below, so no
# client secret is required for this flow.
GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID", "").strip()
GOOGLE_ISSUERS = ("accounts.google.com", "https://accounts.google.com")
GOOGLE_JWKS_URL = os.getenv("GOOGLE_JWKS_URL", "https://www.googleapis.com/oauth2/v3/certs")
GOOGLE_TOKENINFO_URL = os.getenv("GOOGLE_TOKENINFO_URL", "https://oauth2.googleapis.com/tokeninfo")
# Comma-separated allowlist. Listed accounts are granted admin without a passcode.
ADMIN_EMAILS = {e.strip().lower() for e in os.getenv("ADMIN_EMAILS", "").split(",") if e.strip()}
# Restrict sign-in to one Workspace domain (e.g. "school.edu"). Empty = any Google account.
GOOGLE_ALLOWED_DOMAIN = os.getenv("GOOGLE_ALLOWED_DOMAIN", "").strip().lower()
# When false, the passcode login stays available alongside Google.
REQUIRE_GOOGLE_LOGIN = os.getenv("REQUIRE_GOOGLE_LOGIN", "true").strip().lower() in {"1", "true", "yes", "on"}

USER_COOKIE = "tmr_user"
USER_SESSION_TTL_HOURS = int(os.getenv("USER_SESSION_TTL_HOURS", "720"))

# --- Student accounts ---------------------------------------------------------
# Students create their own account with a name, a student number and a password.
# No email provider or Google client is needed, which is what makes sign-in work
# on a phone in a classroom.
STUDENT_SIGNUP_ENABLED = os.getenv("STUDENT_SIGNUP_ENABLED", "true").strip().lower() in {"1", "true", "yes", "on"}
STUDENT_MIN_PASSWORD = int(os.getenv("STUDENT_MIN_PASSWORD", "6"))
STUDENT_NUMBER_MIN = int(os.getenv("STUDENT_NUMBER_MIN", "3"))
STUDENT_NUMBER_MAX = int(os.getenv("STUDENT_NUMBER_MAX", "40"))
# Wrong passwords allowed before the account is locked for a while.
STUDENT_MAX_FAILED_LOGINS = int(os.getenv("STUDENT_MAX_FAILED_LOGINS", "8"))
STUDENT_LOCKOUT_MINUTES = int(os.getenv("STUDENT_LOCKOUT_MINUTES", "15"))
# PBKDF2 rounds. Stored inside each hash, so raising this only affects new
# passwords and never locks anyone out.
PASSWORD_ITERATIONS = int(os.getenv("PASSWORD_ITERATIONS", "240000"))

# --- Email one-time codes (student sign-in) -----------------------------------
# Students sign in by receiving a short code by email. This needs no Google
# account and no password, and every supported provider has a free tier.
#   resend -> https://resend.com  (3,000 emails/month, needs a verified domain
#             to reach anyone but your own address)
#   brevo  -> https://brevo.com   (300 emails/day, a single sender address can
#             be verified instead of a whole domain)
#   gmail  -> an ordinary Gmail account plus an App Password. The quickest path
#             when you own no domain at all.
#   console -> print the code to the server log (local development only)
EMAIL_PROVIDER = os.getenv("EMAIL_PROVIDER", "console").strip().lower()
EMAIL_API_KEY = os.getenv("EMAIL_API_KEY", "").strip()
EMAIL_FROM = os.getenv("EMAIL_FROM", "Tamridiano <no-reply@tamridiano.app>").strip()
EMAIL_FROM_NAME = os.getenv("EMAIL_FROM_NAME", "تمريضيانو").strip()
EMAIL_TIMEOUT = float(os.getenv("EMAIL_TIMEOUT", "15"))

# SMTP settings, used only by the gmail provider. The password is a 16-character
# Google App Password, which requires 2-Step Verification on the account.
SMTP_HOST = os.getenv("SMTP_HOST", "smtp.gmail.com").strip()
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER", "").strip()
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "").strip()

OTP_TTL_MINUTES = int(os.getenv("OTP_TTL_MINUTES", "10"))
OTP_LENGTH = int(os.getenv("OTP_LENGTH", "6"))
# Wrong guesses allowed before a code is burned.
OTP_MAX_ATTEMPTS = int(os.getenv("OTP_MAX_ATTEMPTS", "5"))
# Minimum gap between two codes for the same address.
OTP_RESEND_SECONDS = int(os.getenv("OTP_RESEND_SECONDS", "60"))
# Codes a single address may request per hour.
OTP_MAX_PER_HOUR = int(os.getenv("OTP_MAX_PER_HOUR", "5"))
# Codes a single IP may request per hour, to blunt scripted abuse.
OTP_MAX_PER_IP_HOUR = int(os.getenv("OTP_MAX_PER_IP_HOUR", "20"))
# Codes are stored as HMACs. Defaults to SESSION_SECRET so no extra setup is
# needed; set it explicitly to invalidate outstanding codes independently.
OTP_SECRET = os.getenv("OTP_SECRET", "").strip() or SESSION_SECRET

# Comma-separated domains allowed to sign in by email, e.g. "nursing.edu,edu.eg".
# Empty = any address.
ALLOWED_EMAIL_DOMAINS = {
    d.strip().lower().lstrip("@") for d in os.getenv("ALLOWED_EMAIL_DOMAINS", "").split(",") if d.strip()
}

# --- Academic years -----------------------------------------------------------
DEFAULT_YEARS = [
    y.strip()
    for y in os.getenv(
        "DEFAULT_YEARS",
        "الفرقة الأولى,الفرقة الثانية,الفرقة الثالثة,الفرقة الرابعة",
    ).split(",")
    if y.strip()
]
SEED_DEFAULT_YEARS = os.getenv("SEED_DEFAULT_YEARS", "true").strip().lower() in {"1", "true", "yes", "on"}

# --- Scale --------------------------------------------------------------------
# SQLite is fine for a single process; for 2500+ concurrent students point
# DATABASE_URL at PostgreSQL and set workers accordingly.
DB_POOL_SIZE = int(os.getenv("DB_POOL_SIZE", "20"))
DB_MAX_OVERFLOW = int(os.getenv("DB_MAX_OVERFLOW", "40"))
DB_POOL_RECYCLE = int(os.getenv("DB_POOL_RECYCLE", "1800"))

MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "25"))
