"""Self-service student accounts: register once, then sign in with a number.

A student picks their own name, a student number and a password. No email and no
Google account are involved, which is what makes this usable on a phone in a
classroom. The account is the anchor for results: an attempt taken while signed
in is stored against the account id, so a student only ever sees their own work.

Passwords are stored as PBKDF2-HMAC-SHA256 with a per-user random salt, using
only the standard library. The iteration count is stored in the hash string so
it can be raised later without invalidating existing accounts.
"""

import asyncio
import base64
import hashlib
import hmac
import logging
import re
import secrets
from datetime import timedelta

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from .config import (
    PASSWORD_ITERATIONS,
    STUDENT_LOCKOUT_MINUTES,
    STUDENT_MAX_FAILED_LOGINS,
    STUDENT_MIN_PASSWORD,
    STUDENT_NUMBER_MAX,
    STUDENT_NUMBER_MIN,
)
from .models import Student, utcnow

log = logging.getLogger("tamridiano.students")

_ALGO = "pbkdf2_sha256"

# Arabic-Indic and Extended Arabic-Indic digits folded to ASCII, so a number
# typed on an Arabic keyboard matches one typed on a Latin keyboard.
_DIGIT_FOLD = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")


class StudentError(RuntimeError):
    """Carries an Arabic message safe to show the student."""


def normalise_number(raw: str | None) -> str:
    """Validate and canonicalise a student number.

    Spaces and dashes are dropped, so "2024 0012" and "2024-0012" are one account.
    """
    text = (raw or "").strip().translate(_DIGIT_FOLD)
    text = re.sub(r"[\s\-_]", "", text)

    if not text:
        raise StudentError("اكتب رقم الطالب.")
    if not text.isascii() or not text.isalnum():
        raise StudentError("رقم الطالب يجب أن يكون أرقامًا أو حروفًا إنجليزية فقط.")
    if not (STUDENT_NUMBER_MIN <= len(text) <= STUDENT_NUMBER_MAX):
        raise StudentError(
            f"رقم الطالب يجب أن يكون بين {STUDENT_NUMBER_MIN} و {STUDENT_NUMBER_MAX} خانة."
        )
    return text


def normalise_name(raw: str | None) -> str:
    """Collapse whitespace and bound the length of a display name."""
    name = re.sub(r"\s+", " ", (raw or "").strip())
    if len(name) < 2:
        raise StudentError("اكتب اسمك الكامل.")
    if len(name) > 160:
        raise StudentError("الاسم طويل جدًا.")
    return name


def check_password(raw: str | None) -> str:
    password = raw or ""
    if len(password) < STUDENT_MIN_PASSWORD:
        raise StudentError(f"كلمة المرور يجب أن تكون {STUDENT_MIN_PASSWORD} أحرف على الأقل.")
    if len(password) > 200:
        raise StudentError("كلمة المرور طويلة جدًا.")
    return password


# --------------------------------------------------------------------------- #
# Password hashing
# --------------------------------------------------------------------------- #

def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, PASSWORD_ITERATIONS)
    return "$".join(
        [
            _ALGO,
            str(PASSWORD_ITERATIONS),
            base64.b64encode(salt).decode(),
            base64.b64encode(digest).decode(),
        ]
    )


async def hash_password_async(password: str) -> str:
    """`hash_password` on a worker thread.

    PBKDF2 is deliberately CPU-heavy (~45ms at the default 240k rounds). Run
    inline it would freeze the whole event loop for that long, so a burst of
    logins at the start of an exam would stall every other student on the same
    worker. Off-loading it keeps the loop free to serve them.
    """
    return await asyncio.to_thread(hash_password, password)


def verify_password(password: str, stored: str | None) -> bool:
    """Constant-time check. A malformed stored hash is a failed login, not a crash."""
    if not stored:
        return False
    try:
        algo, iterations_s, salt_b64, digest_b64 = stored.split("$", 3)
        if algo != _ALGO:
            return False
        iterations = int(iterations_s)
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(digest_b64)
    except (ValueError, TypeError):
        return False
    candidate = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, iterations)
    return hmac.compare_digest(candidate, expected)


async def verify_password_async(password: str, stored: str | None) -> bool:
    """`verify_password` on a worker thread. See `hash_password_async`."""
    return await asyncio.to_thread(verify_password, password, stored)


# --------------------------------------------------------------------------- #
# Registration and sign-in
# --------------------------------------------------------------------------- #

async def register(db: AsyncSession, name: str, number: str, password: str) -> Student:
    """Create an account, raising StudentError when the number is taken."""
    clean_name = normalise_name(name)
    clean_number = normalise_number(number)
    check_password(password)

    existing = await db.scalar(
        select(Student).where(func.lower(Student.student_number) == clean_number.lower())
    )
    if existing is not None:
        raise StudentError("رقم الطالب مسجّل بالفعل. سجّل الدخول بدلًا من إنشاء حساب.")

    student = Student(
        name=clean_name,
        student_number=clean_number,
        password_hash=await hash_password_async(password),
        created_at=utcnow(),
    )
    db.add(student)
    try:
        await db.commit()
    except IntegrityError as exc:
        # Two registrations for the same number raced; the unique index decided.
        await db.rollback()
        raise StudentError("رقم الطالب مسجّل بالفعل. سجّل الدخول بدلًا من إنشاء حساب.") from exc
    await db.refresh(student)
    log.info("student account created: %s", student.student_number)
    return student


async def authenticate(db: AsyncSession, number: str, password: str) -> Student:
    """Check credentials, raising StudentError with a deliberately vague message.

    The same wording is used for an unknown number and a wrong password, so the
    endpoint cannot be used to discover which numbers exist.
    """
    try:
        clean_number = normalise_number(number)
    except StudentError as exc:
        raise StudentError("رقم الطالب أو كلمة المرور غير صحيحة.") from exc

    student = await db.scalar(
        select(Student).where(func.lower(Student.student_number) == clean_number.lower())
    )
    if student is None:
        # Spend the same work as a real check so timing does not reveal existence.
        await hash_password_async(password or "")
        raise StudentError("رقم الطالب أو كلمة المرور غير صحيحة.")

    now = utcnow()
    if student.locked_until is not None and student.locked_until > now:
        wait = max(1, int((student.locked_until - now).total_seconds() // 60) + 1)
        raise StudentError(f"تم إيقاف الحساب مؤقتًا بعد محاولات خاطئة. حاول بعد {wait} دقيقة.")

    if not await verify_password_async(password, student.password_hash):
        student.failed_attempts = (student.failed_attempts or 0) + 1
        if student.failed_attempts >= STUDENT_MAX_FAILED_LOGINS:
            student.locked_until = now + timedelta(minutes=STUDENT_LOCKOUT_MINUTES)
            student.failed_attempts = 0
        await db.commit()
        raise StudentError("رقم الطالب أو كلمة المرور غير صحيحة.")

    student.failed_attempts = 0
    student.locked_until = None
    student.last_login_at = now
    await db.commit()
    await db.refresh(student)
    return student


async def change_password(db: AsyncSession, student: Student, current: str, new: str) -> None:
    """Change a password, requiring the current one."""
    if not await verify_password_async(current, student.password_hash):
        raise StudentError("كلمة المرور الحالية غير صحيحة.")
    check_password(new)
    student.password_hash = await hash_password_async(new)
    await db.commit()


__all__ = [
    "StudentError",
    "authenticate",
    "change_password",
    "check_password",
    "hash_password",
    "normalise_name",
    "normalise_number",
    "register",
    "verify_password",
]
