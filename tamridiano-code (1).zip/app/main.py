import asyncio
import logging
import secrets
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .config import DOWNLOAD_TOKEN, ROOT_PATH, STATIC_DIR, SOURCE_ZIP
from .db import init_db
from .keepalive import keep_alive_task
from .llm import LLMError, close_client
from .routers import admin, attempts, auth, catalogue, exams, materials

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("tamridiano")


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    keep_alive = asyncio.create_task(keep_alive_task())
    log.info("Tamridiano ready (root_path=%s)", ROOT_PATH or "/")
    yield
    keep_alive.cancel()
    await asyncio.gather(keep_alive, return_exceptions=True)
    await close_client()


app = FastAPI(
    title="Tamridiano",
    description="Electronic exam platform with AI question generation",
    version="1.0.0",
    root_path=ROOT_PATH,
    lifespan=lifespan,
    docs_url="/api/docs",
    openapi_url="/api/openapi.json",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(LLMError)
async def llm_error_handler(_: Request, exc: LLMError):
    return JSONResponse(status_code=502, content={"detail": str(exc)})


app.include_router(admin.router)
app.include_router(auth.router)
app.include_router(catalogue.router)
app.include_router(materials.router)
app.include_router(exams.router)
app.include_router(attempts.router)


@app.get("/api/health")
async def health():
    return {"status": "ok", "app": "Tamridiano"}


@app.get("/source/{token}", include_in_schema=False)
async def download_source(token: str):
    """Hand the project archive to the owner without going through GitHub.

    Temporary: exists so the code survives a container reset while hosting is
    being set up. Disabled unless DOWNLOAD_TOKEN is set, so a default deploy
    exposes nothing.
    """
    if not DOWNLOAD_TOKEN or not secrets.compare_digest(token, DOWNLOAD_TOKEN):
        return JSONResponse(status_code=404, content={"detail": "Not found"})
    if not SOURCE_ZIP.exists():
        return JSONResponse(status_code=404, content={"detail": "Archive not built yet"})
    return FileResponse(
        SOURCE_ZIP,
        media_type="application/zip",
        filename="tamridiano-code.zip",
    )


app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/", include_in_schema=False)
async def index():
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/{path:path}", include_in_schema=False)
async def spa_fallback(path: str):
    if path.startswith("api/"):
        return JSONResponse(status_code=404, content={"detail": "Not found"})
    return FileResponse(STATIC_DIR / "index.html")
