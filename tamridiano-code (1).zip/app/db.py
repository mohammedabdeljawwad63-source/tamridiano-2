import logging
from collections.abc import AsyncGenerator
from datetime import datetime, timezone

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase

from .config import (
    DATABASE_URL,
    DATA_DIR,
    DB_BACKUP_KEEP,
    DB_MAX_OVERFLOW,
    DB_POOL_RECYCLE,
    DB_POOL_SIZE,
    DEFAULT_YEARS,
    SEED_DEFAULT_YEARS,
)

log = logging.getLogger("tamridiano.db")


class Base(DeclarativeBase):
    pass


_is_sqlite = DATABASE_URL.startswith("sqlite")

# SQLite is used for local/dev runs; PostgreSQL is the target for a real
# deployment. Pool sizing only applies to PostgreSQL — SQLite uses a single file
# and ignores it, so passing pool args there would raise.
_engine_kwargs: dict = {"echo": False, "future": True}
if _is_sqlite:
    _engine_kwargs["connect_args"] = {"timeout": 30}
else:
    _engine_kwargs.update(
        pool_size=DB_POOL_SIZE,
        max_overflow=DB_MAX_OVERFLOW,
        pool_recycle=DB_POOL_RECYCLE,
        pool_pre_ping=True,
    )

engine = create_async_engine(DATABASE_URL, **_engine_kwargs)

SessionLocal = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async with SessionLocal() as session:
        yield session


# Columns added after the first release. `create_all` only creates missing
# *tables*, so existing databases need these applied explicitly.
_ADDED_COLUMNS = {
    "sections": {
        "order_index": "INTEGER DEFAULT 0",
        "icon": "VARCHAR(40)",
        "is_active": "BOOLEAN DEFAULT 1" if _is_sqlite else "BOOLEAN DEFAULT TRUE",
    },
    "attempts": {
        "student_email": "VARCHAR(320)",
        "student_account_id": "INTEGER REFERENCES students(id) ON DELETE SET NULL",
    },
}


async def _migrate(conn) -> None:
    for table, columns in _ADDED_COLUMNS.items():
        if _is_sqlite:
            rows = (await conn.execute(text(f"PRAGMA table_info({table})"))).all()
            existing = {r[1] for r in rows}
        else:
            rows = (
                await conn.execute(
                    text(
                        "SELECT column_name FROM information_schema.columns "
                        "WHERE table_name = :t"
                    ),
                    {"t": table},
                )
            ).all()
            existing = {r[0] for r in rows}
        for name, ddl in columns.items():
            if name not in existing:
                await conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {name} {ddl}"))


async def _seed_years(conn) -> None:
    """Ensure the default academic years exist.

    Runs when none of the configured years are present yet, which covers both a
    fresh database and one created before years existed. Once any default year is
    found we assume the admin owns the list and stop touching it, so a
    deliberately deleted year does not come back on the next restart.
    """
    if not SEED_DEFAULT_YEARS or not DEFAULT_YEARS:
        return

    rows = (await conn.execute(text("SELECT name FROM sections"))).all()
    existing = {r[0] for r in rows}
    if any(name in existing for name in DEFAULT_YEARS):
        return

    # Pre-existing sections (created before years existed) keep their content but
    # are pushed after the years so the year order the admin set stays intact.
    await conn.execute(text("UPDATE sections SET order_index = order_index + 100"))

    for i, name in enumerate(DEFAULT_YEARS):
        if name in existing:
            continue
        await conn.execute(
            text(
                "INSERT INTO sections (name, description, order_index, is_active, created_at) "
                "VALUES (:n, :d, :o, :a, :c)"
            ),
            # Pass a datetime, not an ISO string: SQLite tolerates strings in a
            # timestamp column but asyncpg rejects them, so a string here breaks
            # startup on PostgreSQL only.
            #
            # is_active is spelled out because the model's `default=True` is a
            # Python-side default. Raw SQL bypasses it, and PostgreSQL has no
            # column default to fall back on (SQLite's DDL path does).
            {"n": name, "d": None, "o": i, "a": True, "c": datetime.now(timezone.utc)},
        )


def _snapshot_sqlite() -> None:
    """Keep rolling copies of the SQLite file so a bad delete stays recoverable.

    Runs once per start, before any schema work, and never raises: a failed
    snapshot must not stop the app from booting.
    """
    if not _is_sqlite or DB_BACKUP_KEEP <= 0:
        return
    db_path = DATA_DIR / "tamridiano.db"
    if not db_path.exists():
        return

    backup_dir = DATA_DIR / "backups"
    try:
        backup_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
        dest = backup_dir / f"tamridiano-{stamp}.db"
        if dest.exists():
            return

        import sqlite3

        src = sqlite3.connect(str(db_path), timeout=30)
        try:
            dst = sqlite3.connect(str(dest))
            try:
                src.backup(dst)
            finally:
                dst.close()
        finally:
            src.close()

        for old in sorted(backup_dir.glob("tamridiano-*.db"))[:-DB_BACKUP_KEEP]:
            old.unlink(missing_ok=True)
        log.info("database snapshot written to %s", dest.name)
    except Exception as exc:  # noqa: BLE001 - never block startup
        log.warning("database snapshot skipped: %s", exc)


async def init_db() -> None:
    from . import models  # noqa: F401  (register mappers)

    # Several uvicorn workers start at once; serialise schema creation with a file lock.
    lock_path = DATA_DIR / ".schema.lock"
    with open(lock_path, "w") as lock_file:
        try:
            import fcntl

            fcntl.flock(lock_file, fcntl.LOCK_EX)
        except (ImportError, OSError):
            pass
        try:
            _snapshot_sqlite()
            async with engine.begin() as conn:
                if _is_sqlite:
                    await conn.execute(text("PRAGMA journal_mode=WAL"))
                    await conn.execute(text("PRAGMA foreign_keys=ON"))
                    await conn.execute(text("PRAGMA busy_timeout=30000"))
                await conn.run_sync(lambda sync_conn: Base.metadata.create_all(sync_conn, checkfirst=True))
                await _migrate(conn)
                await _seed_years(conn)
        finally:
            try:
                import fcntl

                fcntl.flock(lock_file, fcntl.LOCK_UN)
            except (ImportError, OSError):
                pass

    await _purge_dead_login_codes()


async def _purge_dead_login_codes() -> None:
    """Drop sign-in codes that expired long ago.

    Runs on every start so the table stays small without needing a scheduler.
    """
    from .otp import purge_expired

    try:
        async with SessionLocal() as session:
            removed = await purge_expired(session)
        if removed:
            log.info("purged %s expired login codes", removed)
    except Exception as exc:  # noqa: BLE001 - housekeeping must never block startup
        log.warning("login-code purge skipped: %s", exc)
