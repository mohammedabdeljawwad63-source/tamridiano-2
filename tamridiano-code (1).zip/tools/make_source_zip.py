#!/usr/bin/env python3
"""Build data/tamridiano-code.zip — the project source, minus secrets and state.

Used to hand the code to its owner through GET /source/<DOWNLOAD_TOKEN> when a
GitHub push is not available. Excludes .env, data/ (student records, uploads,
backups) and .git, so the archive is safe to hand over as-is.
"""

import pathlib
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
DEST = ROOT / "data" / "tamridiano-code.zip"

SKIP_TOP = {".git", "data", "__pycache__", ".venv", "venv", "deploy/certs", ".pytest_cache", ".mypy_cache", ".ruff_cache"}
SKIP_NAMES = {".env"}
SKIP_SUFFIX = {".pyc", ".db", ".db-wal", ".db-shm"}


def included(path: pathlib.Path) -> bool:
    rel = path.relative_to(ROOT)
    if rel.parts and rel.parts[0] in SKIP_TOP:
        return False
    if any(part in SKIP_TOP for part in rel.parts):
        return False
    return rel.name not in SKIP_NAMES and rel.suffix not in SKIP_SUFFIX


def main() -> None:
    DEST.parent.mkdir(parents=True, exist_ok=True)
    files = [p for p in sorted(ROOT.rglob("*")) if p.is_file() and included(p)]
    with zipfile.ZipFile(DEST, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            archive.write(path, path.relative_to(ROOT))
    print(f"{DEST.relative_to(ROOT)}: {len(files)} files, {DEST.stat().st_size / 1024:.1f} KB")


if __name__ == "__main__":
    main()
