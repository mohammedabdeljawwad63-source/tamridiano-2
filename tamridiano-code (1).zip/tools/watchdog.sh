#!/usr/bin/env bash
# Tamridiano — restart the server if it has stopped.
#
#   ./tools/watchdog.sh              # check once, restart if needed
#   ./tools/watchdog.sh --loop 60    # check every 60 seconds, forever
#
# dev.sh already restarts the server when the process *exits*, but it cannot
# help when the whole container is reset: the supervisor dies with everything
# else, and the site stays down until someone notices. This script is the
# outside check for that case. Run it from cron, or with --loop, so a reset
# becomes a short outage instead of an indefinite one.
#
# Exits 0 when the site is healthy (whether or not a restart was needed).

set -uo pipefail
cd "$(dirname "$0")/.."

PORT="${PORT:-12000}"
URL="http://127.0.0.1:${PORT}/api/health"
LOG="$(pwd)/data/tamridiano.log"

log() { printf '%s %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$*"; }

check() {
  curl -fsS -m 10 "$URL" >/dev/null 2>&1
}

restart() {
  # A stale supervisor that survived while uvicorn died would block a fresh
  # start, so clear both before handing over to dev.sh.
  pkill -f "bash ./dev.sh" 2>/dev/null
  pkill -f "uvicorn app.main:app" 2>/dev/null
  sleep 2
  nohup ./dev.sh --daemon >>"$LOG" 2>&1 &
  disown 2>/dev/null || true
  log "watchdog: restart requested"
}

run_once() {
  if check; then
    return 0
  fi
  log "watchdog: $URL is not responding — restarting"
  restart
  # dev.sh reinstalls dependencies and starts uvicorn; give it time.
  for _ in $(seq 1 30); do
    sleep 5
    if check; then
      log "watchdog: back up"
      return 0
    fi
  done
  log "watchdog: still down after restart — check $LOG"
  return 1
}

if [ "${1:-}" = "--loop" ]; then
  interval="${2:-60}"
  log "watchdog: checking every ${interval}s"
  while true; do
    run_once
    sleep "$interval"
  done
else
  run_once
fi
