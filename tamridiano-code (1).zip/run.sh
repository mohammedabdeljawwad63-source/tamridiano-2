#!/usr/bin/env bash
# Tamridiano launcher - local and production.
set -a
[ -f .env ] && . ./.env
set +a

# Workers default to (2 x cores) + 1, capped at 8. The app is async and I/O
# bound, so a handful of workers already serves a few hundred concurrent
# students; more than that just multiplies database connections.
if [ -z "${WORKERS}" ]; then
  cores=$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 2)
  WORKERS=$(( cores * 2 + 1 ))
  [ "${WORKERS}" -gt 8 ] && WORKERS=8
fi

exec python3 -m uvicorn app.main:app \
  --host 0.0.0.0 \
  --port "${PORT:-12000}" \
  --workers "${WORKERS}" \
  --proxy-headers \
  --forwarded-allow-ips='*' \
  --no-server-header \
  --timeout-keep-alive 30 \
  --log-level info
