# Deploying Tamridiano

This guide gets the platform onto a real server so it stays up on its own and can
serve 2500+ students at once. Everything in the repo is ready; the steps that need
*your* accounts are marked.

## What you need to provide

| Item | Where to get it | Used for |
| --- | --- | --- |
| `GOOGLE_CLIENT_ID` | Google Cloud Console → APIs & Services → Credentials → Create OAuth client ID → **Web application** | Google sign-in |
| Hosting account | Render, Fly.io, Railway, or your own VPS | Running the server |
| `LLM_API_KEY` | codecraftapi.com | Question generation and grading |
| `SESSION_SECRET` | Generate: `python3 -c "import secrets; print(secrets.token_urlsafe(48))"` | Signing login cookies |
| `ADMIN_PASSCODE` | Choose a strong value | Admin backup login |

## 1. Google Sign-In setup (5 minutes, free)

1. Open <https://console.cloud.google.com/apis/credentials>.
2. **Create credentials → OAuth client ID → Web application**.
3. Under **Authorized JavaScript origins** add every origin you will serve from,
   for example:
   - `https://tamridiano.com`
   - `https://www.tamridiano.com`
   - `http://localhost:12000` (for local testing)
4. Copy the **Client ID** (looks like `1234567890-abc.apps.googleusercontent.com`).
   No client secret is needed — the browser receives a signed ID token and the
   server verifies it against Google's public keys.
5. Set `GOOGLE_CLIENT_ID` in the environment. Optionally set:
   - `ADMIN_EMAILS=you@example.com` — these accounts become admins automatically.
   - `GOOGLE_ALLOWED_DOMAIN=school.edu` — restrict sign-in to one domain.

Until `GOOGLE_CLIENT_ID` is set, the sign-in screen shows a notice and offers the
admin passcode instead, so the site is never locked out.

## 2. Deploy

### Option A — Render (easiest, managed Postgres)

1. Push the repo to GitHub.
2. Render → **New → Blueprint** → select the repo. It reads `deploy/render.yaml`.
3. Fill the `sync: false` variables in the dashboard (`LLM_API_KEY`,
   `ADMIN_PASSCODE`, `GOOGLE_CLIENT_ID`, `ADMIN_EMAILS`). `SESSION_SECRET` is
   generated for you and `DATABASE_URL` is injected from the managed database.
4. Deploy, then add your Render URL to the Google origins list from step 1.

### Option B — Fly.io (persistent upload volume)

```bash
fly launch --no-deploy
fly postgres create
fly postgres attach <db-name>
fly secrets set LLM_API_KEY=... ADMIN_PASSCODE=... SESSION_SECRET=... GOOGLE_CLIENT_ID=...
fly deploy
fly scale count 4          # more instances for exam season
```

`deploy/fly.toml` already pins `min_machines_running = 2` and disables
auto-stop, so an exam never starts against a cold machine.

### Option C — Your own VPS with Docker

```bash
git clone <your-repo> && cd tamridiano
cp .env.example .env
# edit .env: LLM_API_KEY, SESSION_SECRET, ADMIN_PASSCODE, POSTGRES_PASSWORD, GOOGLE_CLIENT_ID
docker compose up -d --build
```

This starts PostgreSQL, the app, and nginx (TLS termination). Put certificates in
`deploy/certs/` and uncomment the `listen 443 ssl` block in `deploy/nginx.conf`.

### Option D — Running it with no budget

The platform is a normal Docker app, so anything that runs a container will host
it. Costs here are current as of October 2026 and change often — check before
relying on them.

For a step-by-step walkthrough aimed at a non-programmer, see
[`DEPLOY-FREE-AR.md`](DEPLOY-FREE-AR.md) (Arabic). The short version:

1. **Database — Neon** (neon.com, free, no card). Render's own free Postgres is
   deleted 30 days after creation, so it cannot hold student data. Neon keeps a
   small database indefinitely and suspends it when idle instead of deleting it.
2. **Code host — GitHub.** Render clones the app from a repository, so the code
   must live in one. Uploading the source archive through the GitHub web UI needs
   no Git knowledge.
3. **App — Render free web service**, created from the `render.yaml` blueprint in
   this repository. `plan: free` costs nothing and needs no card, but the service
   is suspended after 15 minutes without traffic. `KEEP_ALIVE=true` (already set
   in the blueprint) pings the service's own `/api/health` every 10 minutes so it
   does not go idle.

Two limits of the free tier are worth knowing before choosing it:

- **The filesystem is wiped** on every deploy, restart and spin-down. Uploaded
  PDFs and any SQLite file disappear, which is why `DATABASE_URL` must point at
  an external database. Uploaded curriculum files still live on that ephemeral
  disk, so they must be re-uploaded after a redeploy.
- **Outbound SMTP is blocked** (ports 25, 465, 587). `EMAIL_PROVIDER=gmail`
  therefore cannot send sign-in codes on Render; use `resend` or `brevo`, which
  send over HTTPS, or `console` to read the code from the deploy log.

Other routes, for comparison:

| Route | Cost | Always on? | Catch |
| --- | --- | --- | --- |
| Oracle Cloud Always Free | $0 forever | Yes | Needs a card for identity; ARM capacity is often full; the free ARM allowance was halved to 2 OCPU / 12 GB in June 2026 |
| GitHub Student Developer Pack | $0 | Yes, via Azure | Student status required; Azure gives $100 credit, renewable yearly |
| Render free tier | $0 | No — sleeps after 15 min idle | 512 MB RAM; ephemeral disk; free Postgres is deleted after 30 days |
| Hugging Face Spaces | — | — | No longer an option: creating a Docker or Gradio Space now requires a paid plan |
| Cloudflare Tunnel + a home PC | $0 | Only while the PC is on | Home power and internet become single points of failure |

For a free *domain*, the GitHub Student Developer Pack includes one year of a
`.me` domain from Namecheap. A paid `.com` is roughly $10–15/year.

Two hard constraints shape the free options:

- **Always-on matters more than raw specs.** A free tier that sleeps after 15
  minutes will drop a student mid-exam and take up to a minute to wake. Prefer a
  small always-on VM over a larger tier that idles down.
- **A free database that expires is worse than no database.** Render's free
  Postgres is deleted 30 days after creation. Neon, Supabase and Aiven keep a
  small free Postgres indefinitely, so pair a free app host with one of those
  rather than with an expiring database.

## 3. Capacity: serving 2500+ concurrent students

The platform is I/O bound — students wait on the database and the LLM, not on CPU
— so a small number of async workers handles a large number of students.

| Setting | Value | Why |
| --- | --- | --- |
| `WORKERS` | 4–8 per instance | Each async worker multiplexes hundreds of requests |
| `DATABASE_URL` | PostgreSQL | SQLite serialises writes; Postgres does not |
| `DB_POOL_SIZE` | 20 | Per worker; keep `workers × pool < Postgres max_connections` |
| `numInstances` | 2 to start, 4+ for exam day | Stateless, so scale horizontally |
| Proxy timeouts | 1800s on `/generate-stream` | Generation streams for minutes |

Sizing guide: one 2-vCPU instance with 4 workers comfortably holds ~600–800
concurrent students. Four instances covers 2500+ with headroom. Because sessions
are signed cookies and uploads sit on a shared volume, you can add instances at
any time without draining.

Two things to watch on exam day:

- **Postgres connections.** `instances × workers × DB_POOL_SIZE` must stay under
  `max_connections`. Four instances × 4 workers × 20 = 320, which is why
  `docker-compose.yml` sets `max_connections=400`.
- **LLM rate limits.** Generation is the slowest path. If the provider throttles,
  students see a clear Arabic error rather than a hang, and the streaming progress
  indicator keeps the page responsive.

## 4. Verify the deployment

```bash
curl -fsS https://your-domain/api/health
curl -fsS https://your-domain/api/admin/config   # google_ready should be true
```

Then open the site: you should see the 3D Tamridiano logo, the sign-in screen,
and after signing in the academic years. Upload a curriculum PDF from **إدارة →
ملفات المنهج** and generate an exam to confirm the LLM path works.

## 5. Backups

- **Database**: `pg_dump` on a schedule (Render and Fly both offer managed
  backups — enable them).
- **Uploads**: back up the `uploads` volume. Curriculum files are not
  reproducible.

## Troubleshooting

| Symptom | Cause | Fix |
| --- | --- | --- |
| "تسجيل الدخول بجوجل غير مُهيّأ" | `GOOGLE_CLIENT_ID` unset | Set it and restart |
| Google button missing | Origin not in the authorized list | Add the exact origin in Google Console |
| `400: origin_mismatch` | Scheme/host mismatch (`www` vs not) | Add both origins |
| Sign-in works, then logged out | `SESSION_SECRET` changed | Keep it stable across deploys |
| Generation times out | Proxy read timeout | Use the nginx config's `/generate-stream` block |
